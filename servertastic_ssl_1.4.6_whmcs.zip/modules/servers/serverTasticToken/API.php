<?php
namespace ServerTasticToken;

class API
{
    private $useTest;
    private $apiKey;

    private $apiUrl = 'https://api2.servertastic.com';
    private $testApiUrl = 'https://test-api2.servertastic.com';

    public $errorNo;
    public $error;
    public $httpCode;
    public $apiError;

    function __construct($apiKey, $useTest)
    {
        $this->apiKey = $apiKey;
        $this->useTest = $useTest;
    }

    public function getProducts($productGroup = 'All')
    {
        return $this->request('product/listproducts',
            array(
                'product_group' => $productGroup
        ));
    }

    public function generateToken($productCode, $uniqueReference, $endCustomerEmail, $serverCount, $sanCount,$sanWildcard)
    {
        $data = array(
            'st_product_code' => $productCode,
            'reseller_unique_reference' => $uniqueReference,
            'end_customer_email' => $endCustomerEmail,
        );
        if($serverCount !== null) {
            $data['server_count'] = (int)$serverCount;
        }
        if($sanCount !== null) {
            $data['san_count'] = (int)$sanCount;
        }
        if($sanWildcard !== null) {
            $data['wildcard_san_count'] = (int)$sanWildcard;
        }
        //return $this->request('account/addtestpoints', array('points' => 1000));
        return $this->request('order/generatetoken', $data);
    }

    public function tokenInfo($order_token)
    {
        return $this->request('order/review', array(
            'order_token' => $order_token
        ));
    }

    private function request($req, $options)
    {
        $ch = curl_init();
        $options['api_key'] = $this->apiKey;
        $url = ($this->useTest?$this->testApiUrl:$this->apiUrl) . '/' . $req . '.json';
        $url .= '?' . http_build_query($options);

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = json_decode(curl_exec($ch));
        if(!empty($response->error)){
            $this->apiError = $response->error->message;
        }

        $this->httpCode = curl_getinfo($ch,CURLINFO_HTTP_CODE);
        $this->errorNo = curl_errno($ch);
        $this->error = curl_error($ch);

        curl_close($ch);
        return $response;
    }
}