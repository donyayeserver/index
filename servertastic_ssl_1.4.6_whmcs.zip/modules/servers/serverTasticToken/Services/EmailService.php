<?php

namespace ServerTasticToken\Services;

class EmailService
{

    public static function sendEmail($messageName, $serviceID, $fieldsToMerge = array())
    {
        $command       = 'SendEmail';
        $postData      = array(
            'messagename' => $messageName,
            'id'          => $serviceID,
            'customvars' => $fieldsToMerge,
        );
        
        return localAPI($command, $postData);
    }
}
