<?php
namespace ServerTasticToken;

use WHMCS\Database\Capsule;

class Helper
{
    public static function customFieldExists($relid, $name)
    {
        $name = (strpos($name, '|') ? $name . '|%' : $name . '%');
        return Capsule::table('tblcustomfields')->where('relid', $relid)->where('type', 'product')->whereRaw('fieldname LIKE \'' . $name . '\'')->exists();
    }

    public static function createTokenCustomField($relid)
    {
        Capsule::table('tblcustomfields')->insert(array(
            'type' => 'product',
            'relid' => $relid,
            'fieldname' => 'token|Order Token',
            'fieldtype' => 'text',
            'adminonly' => 'on',
            'sortorder' => 0,
        ));
    }

    public static function addCustomFieldValue($fieldname, $relid, $serviceid, $value)
    {
        $like = strpos($fieldname, '|') ? $fieldname . '|%' : $fieldname . '%';
        $field = Capsule::table('tblcustomfields')->where('type', 'Product')->where('relid', $relid)->whereRaw('fieldname LIKE \'' . $like . '\'')->first()->id;
        Capsule::table('tblcustomfieldsvalues')->where('fieldid', $field)->where('relid', $serviceid)->delete();
        Capsule::table('tblcustomfieldsvalues')->insert(array(
            'fieldid' => $field,
            'relid' => $serviceid,
            'value' => $value,
        ));
    }

    const TEMPLATE_NAME = 'Certificate Activation Token';

    public static function emailTemplateExists()
    {
        return Capsule::table('tblemailtemplates')->where('name', self::TEMPLATE_NAME)->exists();
    }

    public static function createEmailTemplate()
    {
        Capsule::table('tblemailtemplates')->insert(array(
            'type' => 'product',
            'name' => self::TEMPLATE_NAME,
            'subject' => 'Your Certificate Token',
            'message' => "<p>You have successfully ordered Certificate Token</p><p>Your Token: {\$token}</p>",
        ));
    }
}