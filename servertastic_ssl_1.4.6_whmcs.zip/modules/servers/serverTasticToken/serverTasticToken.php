<?php
use \WHMCS\Product\Product;
use WHMCS\User\Client;
use WHMCS\Database\Capsule;
use ServerTasticToken\API;
use ServerTasticToken\Helper;

require_once 'API.php';
require_once 'Helper.php';

function serverTasticToken_MetaData()
{
    return [
        "DisplayName" => "ServertasticToken"
    ];
}

function serverTasticToken_ConfigOptions($params)
{
    $product = Product::find($_REQUEST['id']);
    $productList = array();
    if(!empty($product->configoption1)) {
        $api = new API($product->configoption1, isset($product->configoption3)?($product->configoption3 == 'on'?true:false):false);
        $products = $api->getProducts();
        foreach ($products->products as $product) {
            $productList[$product->st_product_code] = $product->product_name;
        }

        if($api->httpCode != 200)
        {
            $error = "<thead><tr><th colspan='4'><div class='alert alert-warning'><strong>API ERROR: </strong>".$api->apiError."</div></th></tr></thead>";
        }
    }

    $javascript = <<<HTML
        <style type="text/css">
            .custom_button_ps {
                background: #2d6abb;
                border: none;
                color: #f1f1f1;
                padding: 5px 10px;
                border-radius: 5px;
            }
            
            .custom_button_ps:hover {
                background: #317bd4;
            }
        </style>
        <script type="text/javascript" id="autodestroy">
            function generateCustomTokenFields()
            {
                jQuery.post(window.location.href, {"action":"serverTasticToken_setup_configurable_options", "productid": {$_REQUEST['id']}}, function(res){
                    alert(res.result);
                    window.location.href = "configproducts.php?action=edit&id={$_REQUEST['id']}&tab=4";
                }, "json");
                return false;
            }
            
            function generateEmailTemplate()
            {
                jQuery.post(window.location.href, {"action":"serverTasticToken_setup_email_template"}, function(res){
                    alert(res.result);
                    window.location.href = "configemailtemplates.php";
                }, "json");
                return false;
            }
            
            $(document).ready(function() {
                $("#tblModuleSettings").prepend("{$error}");
                $("#tblModuleSettings").prepend("<tr><td></td><td><button class='custom_button_ps' type='button' onclick='generateCustomTokenFields()'>Generate Custom Field</button></td><td></td><td><button class='custom_button_ps' type='button' onclick='generateEmailTemplate()'>Generate Email Template</button></td></tr>")
            })
            
            
        </script>
HTML;

    return array(
        'token' => array(
            'FriendlyName' => 'API Key',
            'Type' => 'text',
        ),
        'product' => array(
            'FriendlyName' => 'Certificate Type',
            'Type' => 'dropdown',
            'Options' => $productList,
            'Description' => $javascript,
        ),
        'testAPI' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
        ),
        'scount' => array(
            'FriendlyName' => 'Server Count',
            'Type' => 'text',
			'Description' => '(if applicable)',
            'Size' => 6

        ),
        'sanval' => array(
            'FriendlyName' => 'SAN Values ',
            'Type' => 'text',
			'Description' => '(if applicable)',
            'Size' => 6,

        ),
        'mgmtLink' => array(
            'FriendlyName' => 'Management Page Link',
            'Type' => 'text',
            'Default' => 'https://order.manage.cm/token/[order_token]',
            'Description' => '<br />"[order_token]" will be replaced with client token',
        ),
        'showMgmt' => array(
            'FriendlyName' => 'Show Order Management Page Link',
            'Type' => 'yesno',
        ),
        'sanvalwildcard' => array(
            'FriendlyName' => 'Wildcard San Count',
            'Type' => 'text',
            'Description' => '(if applicable)',
            'Size' => 6,
        ),
    );
}

function serverTasticToken_CreateAccount($params)
{
    $api = new API($params['configoption1'], $params['configoption3'] == 'on');

    $uniqueReference = md5($params['userid'] . '-' . $params['serviceid'] . '-' . time());

    $client = Client::find($params['userid']);

    $token = $api->generateToken($params['configoption2'], $uniqueReference, $client->email,
                        !empty($params['configoption4'])?$params['configoption4']:null,
                        !empty($params['configoption5'])?$params['configoption5']:null,
                     !empty($params['configoption8'])?$params['configoption8']:null);

    if($token !== false) {
        if(isset($token->success)) {
            $generatedToken = $token->order_token;

            Helper::addCustomFieldValue('token', $params['pid'], $params['serviceid'], $generatedToken);
            localAPI('SendEmail', array(
                'messagename' => Helper::TEMPLATE_NAME,
                'id' => $params['serviceid'],
                'customvars' => array(
                    'token' => $generatedToken,
                )
            ));
            return 'success';
        } else {
            return $token->error->message;
        }
    } else {
        return 'Error connecting to API';
    }
}

function serverTasticToken_ClientArea($params)
{
    $api = new API($params['configoption1'], $params['configoption3'] == 'on');

    $info = $api->tokenInfo($params['customfields']['token']);

    $token = $params['customfields']['token'];
    $link = str_replace('[order_token]', $token, $params['configoption6']);
    $showLink = $params['configoption7'] == 'on'?true:false;

    $status = $info->order_status;
    if(!empty($info->order_state_further_info)) {
        $status .= ' - ' . $info->order_state_further_info;
    }

    return array(
        'templatefile' => 'clientarea',
        'vars' => array(
            'token' => $token,
            'status' => $status,
            'link' => $link,
            'showLink' => $showLink,
        )
    );
}
