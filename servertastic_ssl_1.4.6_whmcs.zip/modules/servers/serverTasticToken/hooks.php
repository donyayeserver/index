<?php

if (isset($_SESSION['adminid']) && isset($_REQUEST['id']) && basename($_SERVER["SCRIPT_FILENAME"], '.php') == 'configproducts') {
    require_once 'Helper.php';
    ob_clean();

    if($_POST['action'] == 'serverTasticToken_setup_configurable_options') {
        if (\ServerTasticToken\Helper::customFieldExists($_REQUEST['id'], 'token')) {
            die(json_encode(array('success' => 0, 'result' => 'Product has already required custom field.')));
        } else {
            \ServerTasticToken\Helper::createTokenCustomField($_REQUEST['id']);
            die(json_encode(array('success' => 1, 'result' => 'Generated custom field for product')));
        }
    } elseif($_POST['action'] == 'serverTasticToken_setup_email_template') {
        if(!\ServerTasticToken\Helper::emailTemplateExists()) {
            \ServerTasticToken\Helper::createEmailTemplate();
            die(json_encode(array('success' => 1, 'result' => 'Generated Email Template')));
        } else {
            die(json_encode(array('success' => 0, 'result' => 'Email Template already exists')));
        }
    }
}