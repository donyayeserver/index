<?php

use Illuminate\Database\Capsule\Manager as Capsule;

class DatabaseHelper
{
        public static function getRemoteIdForServiceId($serviceid)
        {
            return Capsule::table('tblsslorders')
                ->where('serviceid', $serviceid)
                ->where('status', '!=', 'Cancelled')
                ->select('remoteid')
                ->get();
        }

        public static function countServiceOrders($serviceid)
        {
            return array(Capsule::table('tblsslorders')
                ->where('serviceid', $serviceid)
                ->count('*'));
        }

        public static function countCancelledServiceOrders($serviceid)
        {
            return array(Capsule::table('tblsslorders')
                ->where('serviceid', $serviceid)
                ->where('status', 'Cancelled')
                ->count('*'));
        }

        public static function getSingleHosting($serviceid)
        {
            return (array)Capsule::table('tblhosting')->where('id', $serviceid)->first();
        }

        public static function insertOrder($params)
        {
            return Capsule::table('tblsslorders')->insertGetId($params);
        }

        public static function updateOrder($params, $where)
        {
            $table = Capsule::table('tblsslorders');

            foreach ($where as $name => $value) {
                $table->where($name, $value);
            }

            $table->update($params);
        }

        public static function deleteOrder($orderid)
        {
            Capsule::table('tblsslorders')
                ->where('serviceid', $orderid)
                ->delete();
        }

        public static function getNotCancelledSingleOrder($serviceid)
        {
            return (array)Capsule::table('tblsslorders')
                ->where('serviceid', $serviceid)
                ->where('status', '!=', 'Cancelled')
                ->first();
        }

        public static function getNotCancelledOrders($serviceid)
        {
            return Capsule::table('tblsslorders')
                ->where('serviceid', $serviceid)
                ->where('status', '!=', 'Cancelled')
                ->select('remoteid')->get();
        }

        public static function getOrder($serviceid)
        {
            $order = (array)Capsule::table('tblsslorders')
                ->where('serviceid', $serviceid)
                ->first();
            //missing provisiondate in WHMCS 6 fix
            $order['provisiondate'] = '0000-00-00';
            return $order;
        }

        public static function getFirstOrderForHostingByDescId($serviceid)
        {
            return (array)Capsule::table('tblsslorders')
                ->where('serviceid', $serviceid)
                ->orderBy('id', 'desc')
                ->first();
        }

        public static function getHostingDomainStatus($serviceid)
        {
            return Capsule::table('tblhosting')
                ->where('id', $serviceid)
                ->select('domainstatus')
                ->first()->domainstatus;
        }

        public static function getHostingRegdate($serviceid)
        {
            return Capsule::table('tblhosting')
                ->where('id', $serviceid)
                ->select('regdate')
                ->first()->regdate;
        }

        public static function getTemplateMessage($templateName)
        {
            return Capsule::table('tblemailtemplates')->where('name', $templateName)->select('message')->get();
        }

        public static function getConfigOptionsOneAndThree($serviceid)
        {
            return Capsule::table('tblproducts as tbp')
                ->leftJoin('tblhosting as tbh', 'tbp.id', '=', 'tbh.packageid')
                ->where('tbh.id', $serviceid)
                ->select('tbp.configoption1', 'tbp.configoption3')->get();
        }

        public static function getError()
        {
            return 'Database error';
        }

        public static function getConfigByKey($key)
        {
            return (array)Capsule::table('tblconfiguration')->where('setting', $key)->select('value')->first();
        }

        public static function updateConfig($key, $value)
        {
            Capsule::table('tblconfiguration')->where('setting', $key)->update(array('value' => $value));
        }

        public static function insertConfig($key, $value)
        {
            Capsule::table('tblconfiguration')->insert(array(
                'setting' => $key,
                'value' => $value
            ));
        }

        public static function getProductsForServertype($servertype)
        {
            return Capsule::table('tblproducts')->where('servertype', $servertype)->get();
        }

        public static function getActiveHostingsByPackageId($packageid)
        {
            return Capsule::table('tblhosting as h')
                ->leftJoin('tblsslorders as sso', 'h.id', '=', 'sso.serviceid')
                ->where('h.domainstatus', 'Active')
                ->where('h.packageid', $packageid)
                ->select('h.*', 'sso.remoteid')->get();
        }

        public static function updateHosting($serviceid, $params)
        {
            Capsule::table('tblhosting')->where('id', $serviceid)->update($params);
        }
}
