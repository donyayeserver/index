<?php

class DatabaseHelper {
    
    public static function getRemoteIdForServiceId($serviceid)
    {
        $result = mysql_query('SELECT remoteid FROM tblsslorders WHERE serviceid = "' . $serviceid . '" AND status != "Cancelled"');
        return mysql_fetch_array($result);
    }

    public static function countServiceOrders($serviceid)
    {
        $result = select_query("tblsslorders", "COUNT(*)", array("serviceid" => $serviceid));
        return mysql_fetch_array($result);
    }

    public static function countCancelledServiceOrders($serviceid)
    {
        $result = select_query("tblsslorders", "COUNT(*)", array("serviceid" => $serviceid, "status" => "Cancelled"));
        return mysql_fetch_array($result);
    }

    public static function getSingleHosting($serviceid)
    {
        return mysql_get_row("SELECT * FROM tblhosting  WHERE id=?", array($serviceid));
    }

    public static function insertOrder($params)
    {
        return insert_query("tblsslorders", $params);
    }

    public static function updateOrder($params, $where)
    {
        return update_query('tblsslorders', $params, $where);
    }

    public static function deleteOrder($orderid)
    {
        mysql_safequery("delete from  `tblsslorders`  WHERE serviceid=?", array($orderid));
    }

    public static function getNotCancelledSingleOrder($serviceid)
    {
        return mysql_get_row("select * from tblsslorders where serviceid=? AND `status`!=?", array($serviceid, "Cancelled"));
    }

    public static function getNotCancelledOrders($serviceid)
    {
        $result = mysql_query('SELECT remoteid FROM tblsslorders WHERE serviceid=' . $serviceid . ' AND status <> "Cancelled"');
        return mysql_fetch_array($result);
    }

    public static function getOrder($serviceid)
    {
        return mysql_get_row("select * from tblsslorders where serviceid=?", array($serviceid));
    }

    public static function getFirstOrderForHostingByDescId($serviceid)
    {
        return mysql_get_row("select * from tblsslorders where serviceid=? ORDER BY `id` DESC LIMIT 1", array($serviceid));
    }

    public static function getHostingDomainStatus($serviceid)
    {
        return get_query_val("tblhosting", "domainstatus", array("id" => $serviceid));
    }

    public static function getHostingRegdate($serviceid)
    {
        return get_query_val("tblhosting", "regdate", array("id" => $serviceid));
    }

    public static function getTemplateMessage($templateName)
    {
        $result = mysql_query('SELECT message FROM tblemailtemplates WHERE name="' . $templateName . '"');
        return mysql_fetch_array($result);
    }

    public static function getConfigOptionsOneAndThree($serviceid)
    {
        $result = mysql_query('
            SELECT tblproducts.configoption1, tblproducts.configoption3
            FROM tblproducts
            LEFT JOIN tblhosting ON tblproducts.id=tblhosting.packageid
            WHERE tblhosting.id=' . $serviceid
        );
        return mysql_fetch_array($result);
    }

    public static function getError()
    {
        return mysql_error();
    }

    public static function getConfigByKey($key)
    {
        return mysql_fetch_array(self::mysql_safequery("SELECT value FROM tblconfiguration WHERE setting = ?", array($key)));
    }

    public static function updateConfig($key, $value)
    {
        self::mysql_safequery("UPDATE tblconfiguration SET value = ? WHERE setting = ?", array($value, $key));
    }

    public static function insertConfig($key, $value)
    {
        self::mysql_safequery("INSERT INTO tblconfiguration  (setting,value) VALUES (?,?)", array($key, $value));
    }

    public static function getProductsForServertype($servertype)
    {
        return mysql_get_array("SELECT * FROM `tblproducts` where servertype=?", array($servertype));
    }

    public static function getActiveHostingsByPackageId($packageid)
    {
        return mysql_get_array("SELECT h.*, sso.remoteid FROM `tblhosting` h 
                                          LEFT JOIN tblsslorders sso ON (h.id =sso.serviceid )
                                          WHERE h.`domainstatus`=? AND h.`packageid`=?
                                          ", array("Active", $packageid));
    }

    public static function updateHosting($serviceid, $params)
    {
        return update_query('tblhosting', $params, array('id' => $serviceid));
    }

    static function mysql_safequery($query, $params = false)
    {
        if ($params) {
            foreach ($params as &$v) {
                $v = mysql_real_escape_string($v);
            }
            $sql_query = vsprintf(str_replace("?", "'%s'", $query), $params);
            $sql_query = mysql_query($sql_query);
        } else {
            $sql_query = mysql_query($query);
        }

        return ($sql_query);
    }
}
