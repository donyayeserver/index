<?php
/**********************************************************************
 * CloudLinux Licenses Product developed. (2014-06-04)
 * *
 *
 *  CREATED BY MODULESGARDEN       ->       http://modulesgarden.com
 *  CONTACT                        ->       contact@modulesgarden.com
 *
 *
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 *
 **********************************************************************/
/**
 * @author Pawel Kopec <pawelk@modulesgarden.com>
 */

global $CONFIG;

if (version_compare($CONFIG['Version'], '6.0.0', '<')) {

    if (!function_exists('mysql_safequery')) {

        /**
         * FUNCTION mysql_safequery
         * Connect mysql safety
         * @param string $query
         * @param array $params
         * @return mysql_query $sql_query
         */
        function mysql_safequery($query, $params = false)
        {
            if ($params) {
                foreach ($params as &$value) {
                    $value = mysql_real_escape_string($value);
                }
                $sql_query = vsprintf(str_replace("?", "'%s'", $query), $params);
                $sql_query = mysql_query($sql_query);
            } else {
                $sql_query = mysql_query($query);
            }
            return ($sql_query);
        }

    }

    if (!function_exists('mysql_query_safe')) {

        /**
         * FUNCTION mysql_query_safe
         * Better version of mysql_safequery
         * @param string $query
         * @param array $params
         * @return mysql_query $sql_query
         * @throws Exception
         */
        function mysql_query_safe($query, array $params = array())
        {
            if (!empty($params)) {
                // there is possibility to use % sign in query - this line escapes it!
                $query = str_replace('%', '%%', $query);

                foreach ($params as $k => $p) {
                    if ($p === null) {
                        $query = preg_replace('/\?/', 'NULL', $query, 1);
                        unset($params[$k]);
                    } elseif (is_int($p) || is_float($p)) {
                        $query = preg_replace('/\?/', $p, $query, 1);
                        unset($params[$k]);
                    } else {
                        $query = preg_replace('/\?/', "'%s'", $query, 1);
                    }
                }
                foreach ($params as &$v)
                    $v = mysql_real_escape_string($v);

                $sql_query = vsprintf(str_replace("?", "'%s'", $query), $params);
                $sql_query = mysql_query($sql_query);
            } else {
                $sql_query = mysql_query($query);
            }

            $err = mysql_error();
            if (!$sql_query && $err) {
                throw new Exception($err);
            }
            return ($sql_query);
        }

    }

    if (!function_exists('mysql_get_array')) {
        /**
         * FUNCTION mysql_get_array
         * mysql get array
         * @param string $query
         * @param array $params
         * @return array
         */
        function mysql_get_array($query, $params = false)
        {
            $safe_query = mysql_safequery($query, $params);
            $arr = array();
            while ($row = mysql_fetch_assoc($safe_query)) {
                $arr[] = $row;
            }

            return $arr;
        }
    }

    if (!function_exists('mysql_get_row')) {
        function mysql_get_row($query, $params = false)
        {
            $safe_query = mysql_safequery($query, $params);
            $row = mysql_fetch_assoc($safe_query);
            return $row;
        }
    }
}


if (function_exists('dump') == false) {
    function dump($row = '#############################################')
    {
        echo "<pre>";
        print_r($row);
        echo "</pre>";
    }
}
if (function_exists('dump_xml') == false) {
    function dump_xml($row = '#############################################')
    {
        echo "<pre>";
        echo htmlentities(print_r($row, true));
        echo "</pre>";
    }
}

if (!function_exists('getFullAdmin')) {
    /**
     * FUNCTION getFullAdmin
     * Returns array with admin data (for api calls)
     * @return string $row
     */
    function getFullAdmin()
    {
        $query_admin = mysql_query('SELECT id, username, password, email FROM tbladmins WHERE roleid = 1 LIMIT 1');
        while ($row = mysql_fetch_assoc($query_admin))
            return $row;
        return false;
    }
}

if (!function_exists('servertasticssl_getLang')) {
    function servertasticssl_getLang($params)
    {
        global $CONFIG;
        
        if (!empty($_SESSION['Language']))
        {
            $language = strtolower($_SESSION['Language']);
        }
        else if (strtolower($params['clientsdetails']['language']) != '')
        {
            $language = strtolower($params['clientsdetails']['language']);
        }
        else
        {
            $language = $CONFIG['Language'];
        }

        require_once(dirname(__FILE__) . DS . 'lang' . DS . 'english.php');

        $langfilename = dirname(__FILE__) . DS . 'lang' . DS . $language . '.php';
        if (file_exists($langfilename)) 
        {
            require_once($langfilename);
        }

        return isset($lang) ? $lang : array();
    }
}