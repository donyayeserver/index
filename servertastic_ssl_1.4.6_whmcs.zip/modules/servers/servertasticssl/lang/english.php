<?php
/**********************************************************************
 *Product developed. (2014-09-04)
 * *
 *
 *  CREATED BY MODULESGARDEN       ->       http://modulesgarden.com
 *  CONTACT                        ->       contact@modulesgarden.com
 *
 *
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 *
 **********************************************************************/


/**
 * @author Pawel Kopec <pawelk@modulesgarden.com>
 */


$lang['general']['back'] = 'Back To Service';
$lang['general']['pleasewait'] = 'Please Wait...';
$lang['general']['no_access'] = 'Access denied';
$lang['general']['save'] = 'Save Changes';

$lang['index']['provisioning_date'] = 'SSL Provisioning Date';
$lang['index']['sslstatus'] = 'Configuration Status';
$lang['index']['update_approveremail'] = 'Update Approver Email';
$lang['index']['conf_now'] = 'Configure Now';

$lang['index']['app_changed'] = "Approver Email has been changed";
$lang['index']['valid_to'] = "Certificate Valid Until";
$lang['index']['valid_from'] = "Certificate Valid Since";
$lang['index']['certificate'] = "Certificate";
$lang['index']['download'] = "Download";   