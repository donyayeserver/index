<?php

namespace ModulesGarden\ServerTasticSSL\core\AjaxRequests;

use \ModulesGarden\ServerTasticSSL\core\Ajax;
use \ModulesGarden\ServerTasticSSL\repositories\CustomField;

class GenerateCustomFields extends Ajax
{
    public function __construct($params = [])
    {
        parent::__construct($params);
    }
    
    public function action($parameters)
    {   
        $customFieldRepository = new CustomField();
        
        $customField = $customFieldRepository->getByProperties(["relid" => $parameters['pid'], "type" => "product", "fieldname" => "Review URL"])->first();
        
        if(!$customField->id)
        {
            $customFieldRepository->create(["type" => "product", "relid" => $parameters['pid'], "fieldname" => "Review URL", 
                "fieldtype" => "text", "adminonly" => "on"]);
        }
        else
        {
            return ["result" => "success", "message" => "Custom Fields already exist"];
        }
        
        return ["result" => "success", "message" => "Custom Fields have been created successfully"];
    }
}