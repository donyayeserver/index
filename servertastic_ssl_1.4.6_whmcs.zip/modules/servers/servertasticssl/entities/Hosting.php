<?php

namespace ModulesGarden\ServerTasticSSL\entities;

use Illuminate\Database\Eloquent\Model;

class Hosting extends Model
{
    public $table = 'tblhosting';
    public $timestamps = false;
}
