<?php

namespace ModulesGarden\ServerTasticSSL\entities;
 
use Illuminate\Database\Eloquent\Model;

class CustomField extends Model
{
    public $table = 'tblcustomfields';
    public $timestamps = false;
    
    public function values($serviceid)
    {
        return $this->hasMany("\\ModulesGarden\\ServerTasticSSL\\entities\\CustomFieldValue", "fieldid")->where("relid", "=", $serviceid)->first();
    }
}
