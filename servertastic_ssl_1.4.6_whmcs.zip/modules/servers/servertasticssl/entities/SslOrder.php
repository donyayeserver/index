<?php

namespace ModulesGarden\ServerTasticSSL\entities;

use Illuminate\Database\Eloquent\Model;

class SslOrder extends Model
{
    public $table = 'tblsslorders';
    public $timestamps = false;
}
