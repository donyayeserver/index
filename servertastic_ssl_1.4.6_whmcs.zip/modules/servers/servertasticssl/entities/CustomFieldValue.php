<?php

namespace ModulesGarden\ServerTasticSSL\entities;

use Illuminate\Database\Eloquent\Model;

class CustomFieldValue extends Model
{
    public $table = 'tblcustomfieldsvalues';
    public $timestamps = false;
    protected $fillable = ['fieldid', "relid", "value"];
}
