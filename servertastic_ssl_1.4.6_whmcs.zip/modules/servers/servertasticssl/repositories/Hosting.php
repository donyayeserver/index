<?php

namespace ModulesGarden\ServerTasticSSL\repositories;

use \ModulesGarden\ServerTasticSSL\repositories\Repository;

class Hosting extends Repository
{
    public function getModel()
    {
        return "\\Hosting";
    }
}
