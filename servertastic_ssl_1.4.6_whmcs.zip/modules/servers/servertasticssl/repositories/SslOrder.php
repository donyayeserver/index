<?php

namespace ModulesGarden\ServerTasticSSL\repositories;

use \ModulesGarden\ServerTasticSSL\repositories\Repository;

class SslOrder extends Repository
{
    public function getModel()
    {
        return "\\SslOrder";
    }
}
