<?php

namespace ModulesGarden\ServerTasticSSL\repositories;

use \ModulesGarden\ServerTasticSSL\repositories\Repository;

class CustomField extends Repository
{
    public function getModel()
    {
        return "\\CustomField";
    }
}
