<?php

namespace ModulesGarden\ServerTasticSSL\repositories;

use \ModulesGarden\ServerTasticSSL\repositories\Repository;

class CustomFieldValue extends Repository
{
    public function getModel()
    {
        return "\\CustomFieldValue";
    }
}
