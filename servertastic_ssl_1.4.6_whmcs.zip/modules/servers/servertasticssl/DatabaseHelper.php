<?php

global $CONFIG;

$pathDB = __DIR__."/db/";

if (version_compare($CONFIG['Version'], '6.0.0', '>=')) {
    require_once $pathDB.'DBCapsule.php';
} else {
    require_once $pathDB.'DBLegacy.php';
}
