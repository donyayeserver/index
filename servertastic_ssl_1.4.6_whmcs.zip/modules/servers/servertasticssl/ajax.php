<?php

require_once dirname(dirname(dirname(__DIR__))).DIRECTORY_SEPARATOR."init.php";
require_once "servertasticssl_Loader.php";

$requestName = $_POST['request'];
$requestParams = $_POST['parameters'];

$ajaxRequestsNamespace = '\\ModulesGarden\\ServerTasticSSL\\core\\AjaxRequests\\';
$request = $ajaxRequestsNamespace.$requestName;

$ajaxRequest = new $request($requestParams);
$response = $ajaxRequest->execute();

echo $response;
