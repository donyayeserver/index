<?php

/* * ********************************************************************
 * CloudLinux Licenses Product developed. (2014-06-04)
 * *
 *
 *  CREATED BY MODULESGARDEN       ->       http://modulesgarden.com
 *  CONTACT                        ->       contact@modulesgarden.com
 *
 *
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 *
 * ******************************************************************** */
use \ModulesGarden\ServerTasticSSL\repositories\CustomField;

class Servertasticssl_Clientarea extends MG_Clientarea
{

    /**
     *
     * @var array
     */
    protected $_lang;

    private $serviceMainUrl;

    public static $run = false;

    public function init($act, $params, $lang)
    {
        $this->_lang = $lang;
        $this->serviceMainUrl = 'clientarea.php?action=productdetails&id=' . $params['serviceid'];
    }

    // === errors and infos ===
    public function addError($error)
    {
        $errors = isset($_SESSION[get_class($this)]['errors']) ? $_SESSION[get_class($this)]['errors'] : array();
        if (!in_array($error, $errors))
            $_SESSION[get_class($this)]['errors'][] = $error;
    }

    public function addInfo($info)
    {
        $infos = isset($_SESSION[get_class($this)]['infos']) ? $_SESSION[get_class($this)]['infos'] : array();
        if (!in_array($info, $infos))
            $_SESSION[get_class($this)]['infos'][] = $info;
    }

    public function getErrors($delimiter = ' ')
    {
        $errors = isset($_SESSION[get_class($this)]['errors']) ? $_SESSION[get_class($this)]['errors'] : array();
        $_SESSION[get_class($this)]['errors'] = null;
        return implode($delimiter, $errors);
    }

    public function getInfos($delimiter = ' ')
    {
        $infos = isset($_SESSION[get_class($this)]['infos']) ? $_SESSION[get_class($this)]['infos'] : array();
        $_SESSION[get_class($this)]['infos'] = null;
        return implode($delimiter, $infos);
    }

    public function isErrors()
    {
        $errors = isset($_SESSION[get_class($this)]['errors']) ? $_SESSION[get_class($this)]['errors'] : array();
        return empty($errors) ? false : true;
    }

    public function indexAction($params)
    {
        $sslOrder = DatabaseHelper::getOrder($params['serviceid']);
        $id = $sslOrder['id'];
        $remoteid = $sslOrder["remoteid"];
        $provisiondate = $sslOrder["provisiondate"];

        try {
            if ($id) 
            {
                if ($_POST["newapproveremail"] && $params['serviceid']) 
                {
                    $postfields["order_token"] = $remoteid;
                    $postfields["email"] = $_POST["newapproveremail"];
                    
                    $result = servertasticssl_SendCommand("Client Area", "order", "changeapproveremail", $postfields, $params);

                    if ($result["response"]["status"] == "ERROR")
                    {
                        $this->addError($result["response"]["message"]);
                    }
                    else
                    {
                        $this->addInfo($this->_lang['index']['app_changed']);
                    }
                }
           
                $result = servertasticssl_SendCommand("Client Area", "order", "review", ["order_token" => $remoteid], $params);

                if ($result["response"]["status"] == "ERROR")
                {
                    $this->addError($result["response"]["message"]);
                }

                $approver_email_address = is_array($result["response"]['approver_email_address']) ? "" : $result["response"]['approver_email_address'];
                $remotestatus = $result["response"]["order_status"];

                if ($result['response']['modifications']['modification']['0']['timestamp']) 
                {
                    $provisiondate = date('Y-m-d', strtotime($result['response']['modifications']['modification']['0']['timestamp']));
                }
                
                $expiry_date = $result["response"]['expiry_date'] == "0000-00-00 00:00:00" ? null : fromMySQLDate($result["response"]['expiry_date']);
                
                $customFieldRepository = new CustomField();
                $reviewUrlCustomField = $customFieldRepository->getByProperties(["type" => "product", "fieldname" => "Review URL", "relid" => $params['pid']])->first();
                $reviewUrlCustomField = $customFieldRepository->hydrate(array($reviewUrlCustomField))[0];

                $inviteurl = $reviewUrlCustomField->values($params['serviceid'])['value'];

                if($inviteurl == null || empty($inviteurl) || $inviteurl == '') {
                    $inviteurl = null;
                }

                if ($provisiondate == "0000-00-00") {
                    $provisiondate = DatabaseHelper::getHostingRegdate($params['serviceid']);
                    $hosting = DatabaseHelper::getSingleHosting($params['serviceid']);
                    $provisiondate = $hosting['regdate'];
                }
                $provisiondate = fromMySQLDate($provisiondate);
            }
        } catch (Exception $ex) {
            $this->addError($ex->getMessage());
        }
        if ($provisiondate == '//') {
            $provisiondate = '-';
        }
        return array(
            "error_msg" => $this->getErrors(),
            "success_msg" => $this->getInfos(),
            "remoteid" => $remoteid,
            "provisiondate" => $provisiondate,
            "remotestatus" => $remotestatus,
            "inviteurl" => $inviteurl,
            "approver_email_address" => $approver_email_address,
            "expiry_date" => $expiry_date,
            "isCsr" => (boolean)($result['response']['certificate'] && $remotestatus == "Completed"),
        );
    }

    /**
     * GetCrt
     * @param array $params
     * @throws Exception
     */
    public function getCrtAction($params)
    {
        $sslOrder = DatabaseHelper::getOrder($params['serviceid']);

        $result = servertasticssl_SendCommand("Admin Area", "order", "review", ["order_token" => $sslOrder['remoteid']], $params);
        
        if ($result["response"]["status"] == "ERROR") 
        {
            $this->addError($result["response"]["message"]);
            header("Location: " . $this->serviceMainUrl);
            die();
        }

        $fileName = "{$params['serviceid']}.pem";
        ob_clean();
        header($_SERVER["SERVER_PROTOCOL"] . " 200 OK");
        header("Cache-Control: public");
        header("Content-Type: application/x-pem-file");
        header("Content-Transfer-Encoding: Binary");
        header("Content-Length:" . strlen($result['response']['certificate']));
        header("Content-Disposition: attachment; filename=" . $fileName);
        echo $result['response']['certificate'];
        die();
    }
}
