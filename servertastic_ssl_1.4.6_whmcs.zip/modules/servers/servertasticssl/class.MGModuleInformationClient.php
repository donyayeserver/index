<?php

/**
 * @author Mariusz Miodowski <mariusz@modulesgarden.com>
 */

if (!class_exists('MGModuleInformationClient')) {
    class MGModuleInformationClient
    {
        /**
         *  Cache life time.
         */
        protected $cache = array
        (
            'getLatestModuleVersion' => 43200,  /* 12 hours */
            'registerModuleInstance' => 43200,  /* 12 hours */
            'getAvailableProducts' => 3600,   /* 1 hour */
            'getActivePromotions' => 3600,   /* 1 hour */
        );

        //Server Location
        protected $url = 'https://modulesgarden.com/manage/modules/addons/ModuleInformation/server.php';

        //This name will be send to modulesgarden.com
        protected $module = '';

        //Module Name
        protected $moduleName = '';

        //Encryption Key
        protected $accessHash = '';

        //Error?
        protected $error = '';

        public function __construct($moduleName, $accessHash, $url = '')
        {
            $this->module = $moduleName;
            $this->moduleName = strtolower(str_replace(' ', '', $moduleName));
            $this->accessHash = trim($accessHash);
            if ($url) {
                $this->url = $url;
            }
        }

        public function setModule($moduleName, $accessHash)
        {
            $this->module = $moduleName;
            $this->moduleName = strtolower(str_replace(' ', '', $moduleName));
            $this->accessHash = trim($accessHash);
        }

        public function setURL($url)
        {
            $this->url = $url;
        }

        /**
         * @param type $currentVersion
         */
        public function getLatestModuleVersion()
        {
            $request = array
            (
                'action' => 'getLatestModuleVersion',
            );

            return $this->send($request);
        }

        public function getActivePromotions()
        {
            $request = array
            (
                'action' => 'getActivePromotions'
            );

            return $this->send($request);
        }

        /**
         * Register new module instance
         * @param $moduleVersion
         * @param $serverIP
         * @param $serverName
         * @return
         */
        public function registerModuleInstance($moduleVersion, $serverIP, $serverName)
        {
            $request = array
            (
                'action' => 'registerModuleInstance',
                'data' => array
                (
                    'moduleVersion' => $moduleVersion,
                    'serverIP' => $serverIP,
                    'serverName' => $serverName,
                )
            );

            return $this->send($request);
        }

        /**
         * Get all available products
         * @return type
         */
        public function getAvailableProducts($platform = null)
        {
            $requst = array
            (
                'action' => 'getAvailableProducts',
                'data' => array
                (
                    'platform' => $platform
                )
            );

            return $this->send($requst);
        }


        private function send($data = array())
        {
            if (!$data || empty($data['action'])) {
                return false;
            }

            //Add module name and access hash
            $data['hash'] = $this->accessHash;
            $data['module'] = $this->module;

            //Are we have ane cache?
            $action = $data['action'];
            if (!empty($this->cache[$action])) {
                $value = self::getWHMCSconfig($this->moduleName . '_' . $action . '_time');
                if ($value && $value + $this->cache[$action] > time()) {
                    $lastResponse = self::getWHMCSconfig($this->moduleName . '_' . $action . '_response');
                    if ($lastResponse) {
                        return unserialize($lastResponse);
                    }
                }
            }

            //Encode data
            $data = json_encode($data);

            //Prepare Curl
            $ch = curl_init($this->url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_POSTREDIR, 3);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: text/xml'));

            $ret = curl_exec($ch);

            if (!$ret) {
                $this->error = 'Did not receive any data. ' . curl_error($ch);
                return false;
            }

            $json = json_decode($ret);
            if (!$json) {
                $this->error = 'Invalid Format';
                return false;
            }

            if (!$json->status) {
                $this->error = $json->message;
                return false;
            }

            self::saveWHMCSconfig($this->moduleName . '_' . $action . '_time', time());
            self::saveWHMCSconfig($this->moduleName . '_' . $action . '_response', serialize($json));

            return $json;
        }

        public function getError()
        {
            return $this->error;
        }

        protected function setError($error)
        {
            $this->error = $error;
        }

        /********************************************       STATICS     ***************************************/

        /**
         * Get local version of already installed module
         * @param type $module_name
         * @return mixed|boolean
         */
        static function getLocalVersion($module_name)
        {
            $row = self::getWHMCSconfig(strtolower(str_replace(' ', '', $module_name)) . '_version');
            if ($row) {
                return $row;
            }

            return false;
        }

        /**
         * Save local version to WHMCS database
         * @param type $module_name
         * @param type $module_version
         */
        static function setLocalVersion($module_name, $module_version)
        {
            self::saveWHMCSconfig(strtolower(str_replace(' ', '', $module_name)) . '_version', $module_version);
        }

        /**
         * Use this function if you want to delete cache
         * @param type $module_name
         * @param type $function_name
         */
        static function clearCache($module_name, $function_name)
        {
            self::saveWHMCSconfig(strtolower(str_replace(' ', '', $module_name)) . '_' . $function_name, '');
        }

        static function getWHMCSconfig($key)
        {
            $ret = DatabaseHelper::getConfigByKey($key);

            if ($ret['value']) {
                return $ret['value'];
            }
        }

        static function saveWHMCSconfig($key, $value)
        {
            $ret = DatabaseHelper::getConfigByKey($key);

            if (isset($ret['value'])) {
                return DatabaseHelper::updateConfig($key, $value);
            } else {
                return DatabaseHelper::insertConfig($key, $value);
            }
        }
    }
}