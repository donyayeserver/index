var ProductConfiguration =
{
    init: function()
    {
        ProductConfiguration.addHandlers();
    },
    
    addHandlers: function()
    {
        $('#generate_custom_fields').on("click", function(event) {
            event.preventDefault();
            ProductConfiguration.sendRequest("GenerateCustomFields", {pid: $(this).attr("data-productid")});
        });
    },
    
    sendRequest: function (action, params)
    {
        $.ajax({
            url: "../modules/servers/servertasticssl/ajax.php",
            type: 'POST',
            async: true,
            dataType: 'json',
            data: {request: action, parameters: params},
            error: function (response) {
                console.log(response);
            },
            success: function (response) {
                ProductConfiguration.handleResponse(action, response, params);
            }
        });
    },

    handleResponse: function (action, response, params)
    {
        switch (action)
        {
            case 'GenerateCustomFields':
                ProductConfiguration.handleGenerateCustomFieldsResponse(response, params);
        }
    },
    
    handleGenerateCustomFieldsResponse: function(response, params)
    {
        $('#create-custom-fields-result').hide();
        var div = div = $("<div />", {id: "create-custom-fields-result", style: "margin-top:20px;", text: response.message});
        
        if(response.result == "success")
        {
            $(div).addClass("alert alert-success");
        }
        else
        {
            $(div).addClass("alert alert-danger");
        }

        $(div).insertBefore($("#tblModuleSettings"));
    }
}
$(document).ready(function() {
    ProductConfiguration.init();
});

