<?php

/* * ********************************************************************
 * Product developed. (2014-08-22)
 * *
 *
 *  CREATED BY MODULESGARDEN       ->       http://modulesgarden.com
 *  CONTACT                        ->       contact@modulesgarden.com
 *
 *
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 *
 * ******************************************************************** */

/**
 * The hook is used to run automatic actions daily along with the WHMCS standard cron actions.
 *
 * @author Pawel Kopec <pawelk@modulesgarden.com>
 * @param array $vars
 */
function hook_servertasticssl_DailyCronJob($vars)
{
    try {
        include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'functions.php';
        if (!function_exists("servertasticssl_SendCommand"))
            include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'servertasticssl.php';

        $products = DatabaseHelper::getProductsForServertype('servertasticssl');
        
        foreach ($products as $product) 
        {
            if ($product->configoption4 != "on") 
            {
                continue;
            }
            
            $hostings = DatabaseHelper::getActiveHostingsByPackageId($product->id);
            foreach ($hostings as $h) 
            {
                $res = servertasticssl_SendCommand("cron", "order", "review", ["order_token" => $h->remoteid], (array)$product);

                $expiryDate = $res['response']['expiry_date'];
                
                if (!$expiryDate || $expiryDate == "0000-00-00 00:00:00")
                {
                    continue;
                }

                $expiryDate = date('Y-m-d', strtotime($expiryDate));
                if (strtotime($h->nextduedate) != strtotime($expiryDate))
                {
                    DatabaseHelper::updateHosting($h->id, array('nextduedate' => $expiryDate, 'nextinvoicedate' => $expiryDate));
                }   
            }
        }
    } catch (Exception $e) {
        logModuleCall(
            "servertasticssl", "DailyCronJob", "", '', $e->getMessage()
        );
        return $e->getMessage();
    }
}

add_hook("DailyCronJob", 1, "hook_servertasticssl_DailyCronJob");
