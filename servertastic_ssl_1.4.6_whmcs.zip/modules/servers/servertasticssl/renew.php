<?php
/* * ********************************************************************
 * Product developed. (2014-08-11)
 * *
 *
 *  CREATED BY MODULESGARDEN       ->       http://modulesgarden.com
 *  CONTACT                        ->       contact@modulesgarden.com
 *
 *
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 *
 * ******************************************************************** */

/**
 * @author Pawel Kopec <pawelk@modulesgarden.com>
 */

use \ModulesGarden\ServerTasticSSL\repositories\CustomField;
use \ModulesGarden\ServerTasticSSL\repositories\CustomFieldValue;

include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'functions.php';

/**
 * FUNCTION servertasticssl_Renew
 * Renew Account
 *
 * @params array $params
 * @return string
 */
function servertasticssl_Renew($params)
{
    try {
        $postfields = getPostFields($params);
        $certtype = ($params["configoptions"]["Certificate Type"]) ? $params["configoptions"]["Certificate Type"] : $params["configoption2"];
        $orderid = null;
        
        $result = servertasticssl_SendCommand("System", "order", "generatetoken", $postfields, $params);
        
        logModuleCall(
            "servertasticssl", "renew", print_r($postfields, true), '', print_r($result, true)
        );

        if ($result["response"]["status"] == "ERROR")
        {
            return $result["response"]["message"];
        }

        if ($result["response"]["success"] == "Order placed" || $result["response"]["success"] == "Invite sent") 
        {
            $orderid = $result["response"]["order_token"];

            if (!$orderid)
            {
                return "Unable to obtain Order-ID";
            }

            $sslOrder = DatabaseHelper::getOrder($params['serviceid']);
            if ($sslOrder['id']) 
            {
                DatabaseHelper::updateOrder(array('status' => 'Cancelled'), array('id' => $sslOrder['id']));
            }
            
            $inviteurl = $result["response"]["review_url"];
            $update = array("userid" => $params["clientsdetails"]["userid"], "remoteid" => $orderid, "module" => "servertasticssl", "certtype" => $certtype, "status" => "Awaiting Configuration");
            $where = array("serviceid" => $params["serviceid"]);
            DatabaseHelper::updateOrder($update, $where);
            
            $customFieldRepository = new CustomField();
            $reviewUrlCustomField = $customFieldRepository->getByProperties(["type" => "product", "fieldname" => "Review URL", "relid" => $params['pid']])->first();

            $customFieldValueRepository = new CustomFieldValue();
            $customFieldValueRepository->updateOrCreate(["fieldid" => $reviewUrlCustomField->id, "relid" => $params['serviceid']], ["value" => $inviteurl]);
        
            sendMessage("SSL Certificate Configuration Required", $params["serviceid"], array("ssl_configuration_link" => "<a href=\"$inviteurl\">$inviteurl</a>"));
            return "success";
        }

        if (!$orderid)
        {
            return "Unable to obtain Order-ID";
        }
    } 
    catch (\Exception $e) 
    {
        logModuleCall(
            "servertasticssl", "renew", "", '', $e->getMessage()
        );
        
        return $e->getMessage();
    }
}
