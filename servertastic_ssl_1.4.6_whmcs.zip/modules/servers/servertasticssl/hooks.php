<?php
            
use \ModulesGarden\ServerTasticSSL\repositories\CustomField;
use \ModulesGarden\ServerTasticSSL\repositories\Hosting;

require_once 'servertasticssl_Loader.php';

function hook_servertasticssl_pre_send_email($vars)
{
    if (!class_exists('DatabaseHelper')) {
        require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . "DatabaseHelper.php";
    }
    /*
     * PLEASE CONFIGURE VARIABLES BELOW
     * 
     *
     * Choose what this hook has to do after failed attempt of getting the SSL Configuration Link.
     */
    $_THE_ACTION = 2;
    /*
     *  Possible options:
     *   1: Hook will stop email sending.
     *   2: Hook will display error message in place of the link.
     *      Set the error message below.
     */
    $_THE_ERROR_MESSAGE = '<span style="font-weight:bold;color:#F00">There was a problem while getting the link.</span>';
    /*
     * Please note that this hook will do nothing when template of current email message doesn't include {$ssl_configuration_link} variable.
     * 
     */

    $merge_fields = array();
    $email_template_name = $vars['messagename'];
    $data = DatabaseHelper::getTemplateMessage($email_template_name);

    if (!strpos($data[0]->message, '{$ssl_configuration_link}'))
    {
        # stop the hook when {$ssl_configuration_link} is not used in current email.
        return $merge_fields;
    }
    
    $relid = $vars['relid'];
    $data = DatabaseHelper::getNotCancelledOrders($relid);
    $reference = $data[0];
    if (!$reference) {
        switch ($_THE_ACTION) {
            case 1:
                $merge_fields['abortsend'] = true;
                return $merge_fields;
                break;
            case 2:
                $merge_fields['ssl_configuration_link'] = $_THE_ERROR_MESSAGE;
                return $merge_fields;
                break;
        }
    }
    
    $hostingRepository = new Hosting();
    $hosting = $hostingRepository->getById($vars['relid']);

    $customFieldRepository = new CustomField();
    $reviewUrlCustomField = $customFieldRepository->getByProperties(["type" => "product", "fieldname" => "Review URL", "relid" => $hosting->packageid])->first();
    $reviewUrlCustomField = $customFieldRepository->hydrate(array($reviewUrlCustomField))[0];

    $configLink = $reviewUrlCustomField->values($vars['relid'])['value'];
    
    if(!$reviewUrlCustomField || !$configLink)
    {
        switch ($_THE_ACTION) {
            case 1:
                $merge_fields['abortsend'] = true;
                return $merge_fields;
            case 2:
                $merge_fields['ssl_configuration_link'] = $_THE_ERROR_MESSAGE;
                return $merge_fields;
        }
    }
    
    $merge_fields['ssl_configuration_link'] = "<a href=\"$configLink\" target=\"_blank\">$configLink</a>";
    return $merge_fields;
}

add_hook("EmailPreSend", 1, "hook_servertasticssl_pre_send_email");

include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'cron.php';
