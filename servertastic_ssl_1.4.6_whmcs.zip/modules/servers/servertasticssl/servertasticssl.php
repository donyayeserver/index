<?php
/* * **********************************************************************************************
  ServerTastic WHMCS module
  Module developed for WHMCS that enables the ServerTastic Reseller functionality
  to be integrated into the WHMCS software. Use of this code is at your own risk
  and can be modified to suit your needs but please leave this block in place.

  In order to use the module you must be a registered ServerTastic Reseller and purchase points,
  to regsiter, receive your API key and to purchase points please register at
  https://reseller.servertastic.com.

  It is recommend that you consult the latest ServerTastic API docs prior to set-up of
  configurable options https://support.servertastic.com/entries/21194461-reseller-api-documentation

  CHANGELOG: https://servertastic.codebasehq.com/changelog/whmcs/ssl
  LATEST VERSION: https://servertastic.codebasehq.com/whmcs/ssl.svn

 * ********************************************************************************************** */
if (!defined('DS'))
    define('DS', DIRECTORY_SEPARATOR);

include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'functions.php';
include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'servertasticssl_Loader.php';

use ModulesGarden\ServerTasticSSL\repositories\CustomField;
use ModulesGarden\ServerTasticSSL\repositories\CustomFieldValue;

/**
 * Define module related meta data.
 *
 * Values returned here are used to determine module related abilities and
 * settings.
 *
 * @see http://docs.whmcs.com/Provisioning_Module_Meta_Data_Parameters
 *
 * @return array
 */
function servertasticssl_MetaData()
{
    return array(
        'DisplayName' => 'Servertastic SSL',
    );
}
/****************** MODULE INFORMATION ************************/

//Register instance
ServerTasticForWHMCS_registerInstance();
function ServerTasticForWHMCS_registerInstance()
{
    /****************************************************
     *              EDIT ME
     ***************************************************/
    //Set up name for your module.
    $moduleName = "ServerTastic For WHMCS";
    //Set up module version. You should change module version every time after updating source code.
    $moduleVersion = "1.1.0";
    //Encryption key
    $moduleKey = "RbyaMgfcLUDZCPUv3WAnDeTCceWosv7axrdbsGn27d35cNFeZEtkOscxtASnqvMT";


    /***************************************************
     *                      DO NOT TOUCH!
     ***************************************************/

    if (!class_exists('DatabaseHelper')) {
        require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . "DatabaseHelper.php";
    }

    if (!class_exists('MGModuleInformationClient')) {
        //Load API Class
        require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . "class.MGModuleInformationClient.php";
    }

    //Create Client Class
    $client = new MGModuleInformationClient($moduleName, $moduleKey);

    //Register current instance
    /*$ret = */
    $client->registerModuleInstance($moduleVersion, $_SERVER["SERVER_ADDR"], $_SERVER["SERVER_NAME"]);
}

/**
 * Config options are the module settings defined on a per product basis.
 *
 * @return array
 * @version 1.0.0 open
 */
function servertasticssl_ConfigOptions()
{
    $ex = explode(DS, $_SERVER['SCRIPT_FILENAME']);
    if ($_REQUEST['action'] != 'save' && end($ex) == 'configproducts.php' && isset($_GET['id']) && $_GET['id']) {
        $file = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'moduleVersion.php';
        if (file_exists($file)) {
            include $file;
        } else {
            $moduleVersion = '1.1.0';
            $moduleWikiUrl = 'http://www.docs.modulesgarden.com/ServerTastic_For_WHMCS';
        }
        $moduleLogoSrc = '../modules/servers/servertasticssl/assets/img/mg-logo.png';

        echo str_replace(array(':moduleLogoSrc', ':moduleWikiUrl', ':moduleVersion'), array($moduleLogoSrc, $moduleWikiUrl, $moduleVersion), file_get_contents('../modules/servers/servertasticssl/assets/module_config.phtml'));
    }

    global $CONFIG;

    if (version_compare($CONFIG['Version'], '6.0.0', '>='))
    {
        $help_gif = '../assets/img/help.gif';
    }
    else
    {
        $help_gif = '../images/help.gif';
    }

    $products   = [
        'RapidSSL|1',
        'RapidSSL|2',
        'RapidSSL|3',
        'RapidSSLWildcard|1',
        'RapidSSLWildcard|2',
        'RapidSSLWildcard|3',
        'PositiveSSL|1',
        'PositiveSSL|2',
        'PositiveSSL|3',
        'PositiveSSLWildcard|1',
        'PositiveSSLWildcard|2',
        'QuickSSLPremium|1',
        'QuickSSLPremium|2',
        'QuickSSLPremium|3',
        'QuickSSLPremiumMD|1',
        'QuickSSLPremiumMD|2',
        'QuickSSLPremiumMD|3',
        'TrueBizID|1',
        'TrueBizID|2',
        'TrueBizID|3',
        'TrueBizIDWildcard|1',
        'TrueBizIDWildcard|2',
        'TrueBizIDWildcard|3',
        'TrueBizIDEV|1',
        'TrueBizIDEV|2',
        'TrueBizIDEV|3',
        'TrueBizIDMD|1',
        'TrueBizIDMD|2',
        'TrueBizIDMD|3',
        'TrueBizIDEVMD|1',
        'TrueBizIDEVMD|2',
        'TrueBizIDEVMD|3',
        'SecureSite|1',
        'SecureSite|2',
        'SecureSite|3',
        'SecureSiteEV|1',
        'SecureSiteEV|2',
        'SecureSiteEV|3',
        'SecureSitePro|1',
        'SecureSitePro|2',
        'SecureSitePro|3',
        'SecureSiteProEV|1',
        'SecureSiteProEV|2',
        'SSLWebServer|1',
        'SSLWebServer|2',
        'SSLWebServer|3',
        'SSLWebServerWildcard|1',
        'SSLWebServerWildcard|2',
        'SSLWebServerEV|1',
        'SSLWebServerEV|2',
        'SSL123|1',
        'SSL123|2',
        'SSL123|3',
        'AntiMalwareBasic|1',
        'AntiMalwareBasic|2',
        'AntiMalwareBasic|3',
        'AntiMalware|1',
        'AntiMalware|2',
        'AntiMalware|3'
    ];

    $configarray = [

        "API Key"           => [
            "Type"        => "text", "Size" => "20",
            "Description" => "<img src=\"$help_gif\" title=\"Servertastic Reseller API Key.\nFor more information on becoming a reseller please contact resellers@servertastic.com.\"/>",],
        "Certificate Type"  => ["Type" => "dropdown", "Options" => implode(',', $products),],
        "Test Mode"         => ["Type" => "yesno",],
        "updateNextDueDate" => [
            'FriendlyName' => 'Update Next Due Date',
            "Type"         => "yesno",
            "Description"  => "<img src=\"$help_gif\" title=\"Used to synchronize Expiry Date of the certificate with product's Next Due Date.\nTurned ON is recommended to be used only with recurring billing cycle products.\">",
        ],
        ""                  => ["Description" => "<a id='generate_custom_fields' class='btn btn-primary' data-productid='{$_REQUEST['id']}'>Generate Custom Fields</a><script type='text/javascript' src='../modules/servers/servertasticssl/assets/js/product_configuration.js'></script>"]
    ];
    return $configarray;
}

/**
 * This function is checking if a configuration of CSR is created or not.
 *
 * @param array $params
 * @return boolean
 */
function servertasticssl_IsRecorded($params)
{
    $serviceid = $params['serviceid'];

    $data = DatabaseHelper::getRemoteIdForServiceId($serviceid);
    if ($data[0]) {
        return true;
    }
    return false;
}

/**
 * This function is returning a  reference for CSR
 *
 * @param array $params
 * @return int
 */
function servertasticssl_CreateReference($params)
{
    $serviceid = $params['serviceid'];
    $data = DatabaseHelper::countServiceOrders($serviceid);
    if (!$data[0]) {
        return $serviceid;
    }
    $data = DatabaseHelper::getRemoteIdForServiceId($serviceid);
    if ($data[0]) {
        return $data[0];
    }

    $data = DatabaseHelper::countCancelledServiceOrders($serviceid);
    return $serviceid . ($data[0] + 1);
}

/**
 * This function is called when a new product is due to be provisioned.
 * @param array $params
 * @return string [optional]
 */
function servertasticssl_CreateAccount($params)
{
    if (servertasticssl_IsRecorded($params)) {
        return "An SSL Order already exists for this order";
    }
    $postfields = getPostFields($params);
    $certtype = ($params["configoptions"]["Certificate Type"]) ? $params["configoptions"]["Certificate Type"] : $params["configoption2"];
    $orderid = null;

    $customFieldRepository = new CustomField();
    $reviewUrlCustomField = $customFieldRepository->getByProperties(["type" => "product", "fieldname" => "Review URL", "relid" => $params['pid']])->first();

    if(!$reviewUrlCustomField->id)
    {
        return "'Review URL' custom field does not exists for this product";
    }

    $result = servertasticssl_SendCommand("System", "order", "generatetoken", $postfields, $params);

    if ($result["response"]["status"] == "ERROR")
    {
        return $result["response"]["message"];
    }

    $result["response"]["success"] = strtolower(trim($result["response"]["success"]));

    if ($result["response"]["success"] === "order placed" || $result["response"]["success"] === "invite sent")
    {
        $orderid = $result["response"]["order_token"];
        if (!$orderid)
        {
            return "Unable to obtain Order-ID";
        }

        $inviteurl = $result["response"]["review_url"];

        DatabaseHelper::insertOrder(array("userid" => $params["clientsdetails"]["userid"], "serviceid" => $params["serviceid"], "remoteid" => $orderid, "module" => "servertasticssl", "certtype" => $certtype, "status" => "Awaiting Configuration"));

        $customFieldValueRepository = new CustomFieldValue();
        $customFieldValueRepository->updateOrCreate(["fieldid" => $reviewUrlCustomField->id, "relid" => $params['serviceid']], ["value" => $inviteurl]);

        sendMessage("SSL Certificate Configuration Required", $params["serviceid"], array("ssl_configuration_link" => "<a href=\"$inviteurl\">$inviteurl</a>"));
        return "success";
    }

    if (!$orderid)
    {
        return "Unable to obtain Order-ID";
    }
}

function getPostFields($params)
{
    $maxservercountarr = array();
    $maxservercountarr["SecureSiteProEV"] = 499;
    $maxservercountarr["SecureSite"] = $maxservercountarr["SecureSiteEV"] = $maxservercountarr["SecureSitePro"] = $maxservercountarr["SGCSuperCerts"] = $maxservercountarr["SSLWebServer"] = $maxservercountarr["SSLWebServerWildcard"] = $maxservercountarr["SSLWebServerEV"] = $maxservercountarr["SSL123"] = 500;
    $certtype = ($params["configoptions"]["Certificate Type"]) ? $params["configoptions"]["Certificate Type"] : $params["configoption2"];
    $certproduct = current(explode("|", $certtype, 2));

    $maxyears = end(explode("|", $certtype, 2));
    $productcode = null;
    $certyears = getCertYears($maxyears, $params);

    if (!$params["configoptions"]["Servers Count"]) {
        $params["configoptions"]["Servers Count"] = 1;
    }
    $servercount = ($maxservercountarr[$certproduct]) ? ($params["configoptions"]["Servers Count"] <= $maxservercountarr[$certproduct]) ? $params["configoptions"]["Servers Count"] : $maxservercountarr[$certproduct] : '1';
    $period = ($certyears * 12);
    if ($period > 0)
        $productcode = $certproduct . '-' . $period;

    //Deal with the SAN counts (min|max)
    $sancountarr = array();
    $sancountarr["SecureSite"] = $sancountarr["SecureSiteEV"] = $sancountarr["SecureSitePro"] = $sancountarr["SecureSiteProEV"] = '0|24';
    $sancountarr["TrueBizIDMD"] = $sancountarr["TrueBizIDEVMD"] = '4|24';
    if (array_key_exists($certproduct, $sancountarr)) {
        $min_san_count = current(explode("|", $sancountarr[$certproduct], 2));
        $max_san_count = end(explode("|", $sancountarr[$certproduct], 2));
        if (!isset($params["configoptions"]["SAN Count"])) {
            return "A SAN count value is required for this product";
        } else {
            $san_count = $params["configoptions"]["SAN Count"];
            if (($san_count < $min_san_count) || ($san_count > $max_san_count)) {
                return "The SAN count falls outside the specified range";
            }
        }
    } else {
        $san_count = 0;
    }
    $postfields = array();
    $postfields["st_product_code"] = $productcode;
    $postfields["api_key"] = $params["configoption1"];
    $postfields["end_customer_email"] = $params["clientsdetails"]["email"];
    $postfields["san_count"] = $san_count;
    //WHMCS integration source id is '3'
    $postfields["integration_source_id"] = 3;
    if ($servercount)
        $postfields["server_count"] = $servercount;
    $postfields["reseller_unique_reference"] = uniqid();

    return $postfields;
}

function getCertYears($maxyears, $params)
{
    $certyears = ($params["configoptions"]["Years"]) ? ($params["configoptions"]["Years"] <= $maxyears) ? $params["configoptions"]["Years"] : $maxyears : 1;
    if (!isset($params["configoptions"]["Years"])) {
        $hosting = DatabaseHelper::getSingleHosting($params['serviceid']);
        switch ($hosting['billingcycle']) {
            case 'Annually':
                $certyears = 1;
                break;
            case 'Biennially':
                $certyears = 2;
                break;
            case 'Triennially':
                $certyears = 3;
                break;
            default:
                $certyears = 1;
        }
        if ($certyears > $maxyears)
            $certyears = $maxyears;
    }
    return $certyears;
}

/**
 * This function is called when a termination is requested.
 *
 * @param array $params
 * @return string
 */
function servertasticssl_TerminateAccount($params)
{
    try
    {
        $sslOrder = DatabaseHelper::getNotCancelledSingleOrder($params['serviceid']);

        $result = servertasticssl_SendCommand("System", "order", "cancel", ["order_token" => $sslOrder['remoteid']], $params);

        if ($result["response"]["status"] == "ERROR")
        {
            return $result["response"]["message"];
        }

        DatabaseHelper::deleteOrder($params['serviceid']);

        return "success";
    }
    catch(\Exception $e)
    {
        return $e->getMessage();
    }
}

/**
 * This function can be used to define custom functions.
 *
 * @return array
 */
function servertasticssl_AdminCustomButtonArray($params)
{
    $buttonarray = array(
        "Resend Configuration Email" => "resend",
    );

    if(version_compare( '7.2.0', $params['whmcsVersion'], '>' ))
    {
        $buttonarray['Renew'] = 'Renew';
    }

    return $buttonarray;
}

/**
 * This function can be used to resend DVC
 *
 * @param array $params
 * @return string
 */
function servertasticssl_resend($params)
{
    try
    {
        $sslOrder = DatabaseHelper::getNotCancelledSingleOrder($params['serviceid']);
        $id = $sslOrder['id'];

        if (!$id)
        {
            return "No SSL Order exists for this product";
        }

        $customFieldRepository = new CustomField();
        $reviewUrlCustomField = $customFieldRepository->getByProperties(["type" => "product", "fieldname" => "Review URL", "relid" => $params['pid']])->first();
        $reviewUrlCustomField = $customFieldRepository->hydrate(array($reviewUrlCustomField))[0];

        $configLink = $reviewUrlCustomField->values($params['serviceid'])['value'];

        sendMessage("SSL Certificate Configuration Required", $params["serviceid"], array("ssl_configuration_link" => "<a href=\"$configLink\">$configLink</a>"));

        return "success";
    }
    catch(\Exception $e)
    {
        return $e->getMessage();
    }
}

/**
 * This function is used to define module specific client area output.
 *
 * @global array $_LANG
 * @param array $params
 * @return string
 */
function servertasticssl_ClientArea($params)
{
    global $smarty;
    $vars = servertasticssl_ca($params);
    if ($vars === false)
        return '';
    foreach ($vars as $k => $v)
        $smarty->assign($k, $v);
    return $smarty->fetch(dirname(__FILE__) . DS . $vars['templateFilePath'] . '.tpl');
}

/**
 * This function is used to define client area output
 *
 * @param array $params
 * @return array|bool
 */
function servertasticssl_ca($params)
{

    require_once dirname(__FILE__) . DS . 'classes' . DS . 'class.MG_Clientarea.php';
    require_once dirname(__FILE__) . DS . 'class.Servertasticssl_Clientarea.php';

    if (Servertasticssl_Clientarea::$run)
    {
        return false;
    }

    try {

        $lang = servertasticssl_getLang($params);
        $act = isset($_GET['act']) && strpos($_GET['act'], '/') === false ? $_GET['act'] : 'index';
        Servertasticssl_Clientarea::$run = true;
        $clientarea = new Servertasticssl_Clientarea();
        $clientarea->init($act, $params, $lang);
        $vars = $clientarea->run($act, $params);
        $vars['serviceMainUrl'] = 'clientarea.php?action=productdetails&id=' . $params['serviceid'];
        $vars['servicePageUrl'] = 'clientarea.php?action=productdetails&id=' . $params['serviceid'] . '&modop=custom&a=management&';
        $vars['assetsUrl'] = 'modules/servers/servertasticssl/assets';
        $vars['lang'] = $lang;
        $vars['templateFilePath'] = 'templates' . DS . $act;
        return $vars;
    } catch (Exception $e) {
        return array("modulecustombuttonresult" => $e->getMessage());
    }
}


/**
 * This function is used to save module specific admin area output.
 *
 * @param array $params
 */
function servertasticssl_AdminServicesTabFieldsSave($params)
{
    $sslOrder = DatabaseHelper::getFirstOrderForHostingByDescId($params['serviceid']);
    if ($_POST["newapproveremail"] && $params['serviceid']) {
        $sslOrder = DatabaseHelper::getNotCancelledSingleOrder($params['serviceid']);

        $postfields = array();
        $postfields['order_token'] = $sslOrder['remoteid'];
        $postfields["email"] = $_POST["newapproveremail"];
        $result = servertasticssl_SendCommand("Admin Area", "order", "changeapproveremail", $postfields, $params);
        if ($result['response']['status'] == "ERROR") {
            ob_clean();
            header("Location: clientsservices.php?userid={$_GET['userid']}&id={$_GET['id']}&approveremailmsg=" . urlencode($result['response']['error']['message']));
            die();
        }
    }

    if ($_POST['newremoteid'] && $_POST['newremoteid'] != '-' && $_POST['newremoteid'] != $sslOrder['remoteid']) {

        $postfields = array();
        $postfields["api_key"] = $params["configoption1"];
        $postfields["reseller_order_id"] = $_POST['newremoteid'];

        $result = servertasticssl_SendCommand("Admin Area", "order", "review", $postfields, $params);
        if ($result["response"]["status"] == "ERROR") {
            ob_clean();
            header("Location: clientsservices.php?userid={$_GET['userid']}&id={$_GET['id']}&remoteidmsg=" . urlencode($result["response"]["message"]));
            die();
        } elseif (empty($sslOrder)) {
            $result = DatabaseHelper::insertOrder(array('userid' => $params['userid'], 'serviceid' => $params['serviceid'],
                                                        'remoteid' => $_POST['newremoteid'], 'module' => "servertasticssl", 'certtype' => $params['configoption2'],
                                                        'configdata' => "", 'status' => $result["response"]["order_status"] ?? ''));
        } else {
            $result = DatabaseHelper::updateOrder(array('remoteid' => $_POST['newremoteid']), array('id' => $sslOrder['id']));
        }

        if (!$result) {
            ob_clean();
            header("Location: clientsservices.php?userid={$_GET['userid']}&id={$_GET['id']}&remoteidmsg=" . urlencode(DatabaseHelper::getError()));
            die();
        }
    }

}

/**
 * This function is used to define module specific admin area output.
 *
 * @param array $params
 * @return string
 */
function servertasticssl_AdminServicesTabFields($params)
{
    $sslOrder = DatabaseHelper::getFirstOrderForHostingByDescId($params['serviceid']);

    $id = $sslOrder["id"];
    //$orderid = $data["orderid"];
    //$serviceid = $sslOrder["serviceid"];
    $remoteid = $sslOrder["remoteid"];
    //$module = $sslOrder["module"];
    //$certtype = $sslOrder["certtype"];
    //$domain = $data["domain"];
    //$provisiondate = $sslOrder["provisiondate"];
    //$completiondate = $sslOrder["completiondate"];
    $status = $sslOrder["status"];

    if (!$id) {
        $remoteid = '-';
        $status = 'Not Yet Provisioned';
    } else {

        $awaitingsslconfiguration = false;
        $remotestatus = '';
        $inviteurl = '';
        if (DatabaseHelper::getHostingDomainStatus($params['serviceid']) == "Active") {

            $result = servertasticssl_SendCommand("Admin Area", "order", "review", ["order_token" => $sslOrder['remoteid']], $params);

            if ($result["response"]["status"] == "ERROR") {
                return $result["response"]["message"];
            } else {
                $remotestatus = $result["response"]["order_status"];

                $customFieldRepository = new CustomField();
                $reviewUrlCustomField = $customFieldRepository->getByProperties(["type" => "product", "fieldname" => "Review URL", "relid" => $params['pid']])->first();
                $reviewUrlCustomField = $customFieldRepository->hydrate(array($reviewUrlCustomField))[0];

                $inviteurl = $reviewUrlCustomField->values($params['serviceid'])['value'];

                if ($remotestatus == "Order Placed" || $remotestatus == "Invite Available") {
                    $awaitingsslconfiguration = true;
                } elseif (($status != "Awaiting Configuration" && $remotestatus == "Order placed") || ($status != "Awaiting Configuration" && $remotestatus == "Invite Available")) {
                    DatabaseHelper::updateOrder(array("status" => "Awaiting Configuration"), array("remoteid" => $remoteid));
                } elseif (($status != "Completed" && $remotestatus == "Awaiting Customer Verification") || ($status != "Completed" && $remotestatus == "Awaiting Provider Approval") || ($status != "Completed" && $remotestatus == "Queued") || ($status != "Completed" && $remotestatus == "Completed") || ($status != "Completed" && $remotestatus == "ServerTastic Review")) {
                    DatabaseHelper::updateOrder(array("status" => "Completed"), array("remoteid" => $remoteid));
                } elseif (($status != "Cancelled" && $remotestatus == "Cancelled") || ($status != "Cancelled" && $remotestatus == "Roll Back")) {
                    DatabaseHelper::updateOrder(array("status" => "Cancelled"), array("remoteid" => $remoteid));
                }
            }
        }
        if ($awaitingsslconfiguration) {
            $remotestatus .= ' - <a href="' . $inviteurl . '" target="_blank">Configure Now</a>';
        }
    }
    $err = $_GET['approveremailmsg'] ? "<span style=\"color:red\"> " . urldecode($_GET['approveremailmsg']) . "</span>" : "";
    $err1 = $_GET['remoteidmsg'] ? "<span style=\"color:red\"> " . urldecode($_GET['remoteidmsg']) . "</span>" : "";

    $approverEmail = is_string($result['response']['approver_email_address'])?$result['response']['approver_email_address']:"";
    $fieldsarray = array(
        'Servertastic Token' => '<input type="text" name="newremoteid" value=' . $remoteid . ' />' . $err1,
        'SSL Configuration Status' => $remotestatus ? $remotestatus : $status,
        'Approver Email' => is_array($result["response"]['approver_email_address']) ? "" : $result["response"]['approver_email_address'],
        'Change Approver Email' => $remotestatus == 'Awaiting Customer Verification'?('<input type="text" name="newapproveremail" value="'.$approverEmail.'" />' . $err):"Not available for this order status",
    );
    return $fieldsarray;
}

/**
 * This function used to send API request
 *
 * @param string $interface
 * @param string $type
 * @param string $action
 * @param array $postfields
 * @param array $params
 * @return string
 */
function servertasticssl_SendCommand($interface, $type, $action, $postfields, $params)
{
    if ($params['configoption3']) {
        $url = "https://test-api2.servertastic.com/$type/$action";
    } else {
        $url = "https://api2.servertastic.com/$type/$action";
    }
    $ch = curl_init();
    $url .= "?";
    foreach ($postfields as $field => $data) {
        $url .= "$field=" . rawurlencode($data) . "&";
    }
    $url = substr($url, 0, -1);

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);

    if (curl_errno($ch)) {
        $result["response"]["status"] = "ERROR";
        $result["response"]["message"] = "CURL Error: " . curl_errno($ch) . " - " . curl_error($ch);
    } else {
        $result = servertasticssl_xml2array($data);
        if ($result["response"]["error"]) {
            $result["response"]["status"] = "ERROR";
            $result["response"]["message"] = "API Error: " . $result["response"]["error"]["code"] . ' - ' . $result["response"]["error"]["message"];
        }
    }
    curl_close($ch);

    logModuleCall('servertasticssl', $interface . ' ' . str_replace(".xml", '', $type) . ' ' . $action, $postfields, $data, $result, array($params["configoption1"]));

    return $result;
}

/**
 * Parsing xml to array
 *
 * @param string $contents
 * @param int $get_attributes
 * @param string $priority
 * @return array
 */
function servertasticssl_xml2array($contents, $get_attributes = 1, $priority = 'tag')
{
    $parser = xml_parser_create('');
    xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8");
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
    xml_parse_into_struct($parser, trim($contents), $xml_values);
    xml_parser_free($parser);
    if (!$xml_values)
        return array(); //Hmm...
    $xml_array = array();
    //$parents = array();
    //$opened_tags = array();
    //$arr = array();
    $current = &$xml_array;
    $repeated_tag_index = array();
    foreach ($xml_values as $data) {
        unset($attributes, $value);
        $type = null;
        $tag = null;
        $level = null;
        extract($data);
        $result = array();
        $attributes_data = array();
        if (isset($value)) {
            if ($priority == 'tag')
                $result = $value;
            else
                $result['value'] = $value;
        }
        if (isset($attributes) and $get_attributes) {
            foreach ($attributes as $attr => $val) {
                if ($priority == 'tag')
                    $attributes_data[$attr] = $val;
                else
                    $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
            }
        }
        if ($type == "open") {
            $parent[$level - 1] = &$current;
            if (!is_array($current) or (!in_array($tag, array_keys($current)))) {
                $current[$tag] = $result;
                if ($attributes_data)
                    $current[$tag . '_attr'] = $attributes_data;
                $repeated_tag_index[$tag . '_' . $level] = 1;
                $current = &$current[$tag];
            } else {
                if (isset($current[$tag][0])) {
                    $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                    $repeated_tag_index[$tag . '_' . $level]++;
                } else {
                    $current[$tag] = array(
                        $current[$tag],
                        $result
                    );
                    $repeated_tag_index[$tag . '_' . $level] = 2;
                    if (isset($current[$tag . '_attr'])) {
                        $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                        unset($current[$tag . '_attr']);
                    }
                }
                $last_item_index = $repeated_tag_index[$tag . '_' . $level] - 1;
                $current = &$current[$tag][$last_item_index];
            }
        } elseif ($type == "complete") {
            if (!isset($current[$tag])) {
                $current[$tag] = $result;
                $repeated_tag_index[$tag . '_' . $level] = 1;
                if ($priority == 'tag' and $attributes_data)
                    $current[$tag . '_attr'] = $attributes_data;
            } else {
                if (isset($current[$tag][0]) and is_array($current[$tag])) {
                    $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                    if ($priority == 'tag' and $get_attributes and $attributes_data) {
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                    }
                    $repeated_tag_index[$tag . '_' . $level]++;
                } else {
                    $current[$tag] = array(
                        $current[$tag],
                        $result
                    );
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    if ($priority == 'tag' and $get_attributes) {
                        if (isset($current[$tag . '_attr'])) {
                            $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                            unset($current[$tag . '_attr']);
                        }
                        if ($attributes_data) {
                            $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                        }
                    }
                    $repeated_tag_index[$tag . '_' . $level]++; //0 and 1 index is already taken
                }
            }
        } elseif ($type == 'close') {
            $current = &$parent[$level - 1];
        }
    }
    return ($xml_array);
}

/**
 * Servertasticssl renew function
 * This file will load proper renew function for servertasticssl
 */
$filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'renew.php';
if (file_exists($filename))
{
    include($filename);
}
else
{
    die('Can not include renew.php. Error in file: ' . dirname(__FILE__) . DIRECTORY_SEPARATOR . "servertasticssl.php");
}
