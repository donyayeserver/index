<?php

class CPanelMainController extends AbstractControler
{
    public $clientUsername;


    public function __construct($parent, $options = array())
    {
        parent::__construct($parent, $options);
    }

    public function MainHTMLAction($input, $vars = array())
    {
        $account = new ServerTasticSSLAccount($this->clientUsername);
        $account->nameID = $this->clientUsername;

        $vars['certs'] = $account->getCerts();

        $form = new FormCreator('cert', $this);

        $form->addField('CheckBox', array(
            'name' => 'free'
        , 'value' => 1
        ));

        $form->addField('Text', array(
            'name' => 'order_token'
        , 'require' => true
        ));

        $domainList = array();

        foreach ($account->getDomains() as $domain) {
            $domainList[$domain->domain] = $domain->domain;
        }

        $form->addField('Select', array(
            'name' => 'domain'
        , 'options' => $domainList
        ));

        $form->addField('Submit', array(
            'name' => 'action'
        , 'value' => 'addCertificate'
        ));

        $vars['addForm'] = $form->getHTML();

        $cancelForm = new FormCreator('certCancel', $this);
        $form->addField('Hidden', array(
            'name' => 'order_token'
        , 'require' => true
        ));

        return array(
            'template' => 'Main'
        , 'vars' => $vars
        );
    }

    public function addTokenCertificateHTMLAction($input, $vars = array())
    {
        $form = new FormCreator('cert', $this, array('cancel' => true));

        $form->addField('Text', array(
            'name' => 'domain',
            'value' => isset($input['modal_domain'])?$input['modal_domain']:$input['cert_domain'],
            'readonly' => true
        ));

        $form->addField('Text', array(
            'name' => 'order_token',
            'require' => true,
        ));

        $form->addField('Submit', array(
            'name' => 'action',
            'value' => 'addTokenCertificateWithFields',
            'disableFinishContainer' => true,
            'sumWithNext' => true,
            'onclick' => "$(this).attr('disabled',true).attr('value','Loading...');"
        ));

        $form->addField('Submit', array(
            'name' => 'action',
            'value' => 'Main',
            'skipLabel' => true,
            'disableStartContainer' => true,
            'lang' => 'cancel'
        ));

        $vars['form'] = $form->getHTML();
        return array(
            'template' => 'TemplateCert',
            'vars' => $vars
        );
    }

    public function addTokenCertificateWithFieldsHTMLAction($input, $vars = array())
    {
        $token = $input['cert_order_token'];

        $fields = array();
        $contactFields = array('tech' => array(), 'admin' => array());
        $orgFields = array();
        $infoFields = array();
        $certificate = new ServerTasticSSLCertificate();
        $certificate->domain = $input['cert_domain'];
        try {
            if (empty($token)) {
                throw new Exception(MGLang::T('empty_token'));
            } else {
                if(!$certificate->getProductFields($token, $fields, $contactFields, $orgFields, $infoFields)) {
                    throw new Exception(MGLang::T('required_fields_empty'));
                }
            }

            $fieldErorrs = isset($vars['fieldErrors']) ? $vars['fieldErrors'] : array();
            $form = new FormCreator('cert', $this, array('cancel' => true));

            $form->addField('Legend', array(
                'name' => 'General',
            ));
            $form->addField('Text', array(
                'name' => 'domain',
                'value' => isset($input['cert_domain']) ? $input['cert_domain'] : null,
                'readonly' => true
            ));
            $form->addField('Text', array(
                'name' => 'info',
                'value' => implode(', ', $infoFields),
                'readonly' => true
            ));

            if(!isset($fields['order_token'])) {
                $fields['order_token'] = (object) array(
                    'required' => true,
                );
            }

            foreach ($fields as $name => $field) {
                $base = array(
                    'name' => $name,
                    'require' => $field->required ? true : false,
                    'value' => isset($input['cert_' . $name]) ? $input['cert_' . $name] : null,
                    'error' => (!empty($fieldErorrs['cert_' . $name]))
                );
                $fieldType = 'Text';

                $transformOptions = function ($options) {
                    $value = array();
                    foreach ($options as $option) {
                        $value[$option] = $option;
                    }
                    return $value;
                };

                $draw = true;
                switch ($name) {
                    case 'hashing_algorithm':
                        $fieldType = 'Select';
                        $base['options'] = $transformOptions($field->options);
                        break;
                    case 'order_token':
                        $base['readonly'] = true;
                        break;
                    case 'competitive_upgrade':
                        $fieldType = 'CheckBox';
                        break;
                    case 'approver_email_address':
                        $approvers = $certificate->getApproverEmailList();
                        $fieldType = 'Select';
                        $base['options'] = $transformOptions($approvers);
                        break;
                    case 'web_server_type':
                        $fieldType = 'Select';
                        $base['options'] = $transformOptions($field->options);
                        break;
                    case 'san_domains':
                        $fieldType = 'TextArea';
                        break;
                    default:
                        $draw = false;
                }

                if ($draw) {
                    $form->addField($fieldType, $base);
                }
            }

            foreach ($contactFields as $legend => $fieldBlock) {
                if(!empty($fieldBlock)) {
                    $form->addField('Legend', array(
                        'name' => $legend
                    ));
                }
                foreach ($fieldBlock as $name => $field) {
                    $isCountry = strpos($name, 'country') !== false;
                    $form->addField($isCountry?'Select':'Text', array(
                        'name' => $name,
                        'require' => $field->required ? true : false,
                        'value' => isset($input['cert_' . $name]) ? $input['cert_' . $name] : null,
                        'error' => (!empty($fieldErorrs['cert_' . $name])),
                        'options' => $isCountry?ServerTasticSSLCertificate::getCountries():null,
                    ));
                }
            }

            $form->addField('Legend', array(
                'name' => 'Organisation'
            ));
            
            $form->addField('Text', array(
                'name' => 'org_name',
                'value' => isset($input['cert_org_name']) ? $input['cert_org_name'] : null,
                'error' => (!empty($fieldErorrs['cert_org_name'])),
                'require' => true
            ));

            $form->addField('Text', array(
                'name' => 'org_address_city',
                'value' => isset($input['cert_org_address_city']) ? $input['cert_org_address_city'] : null,
                'error' => (!empty($fieldErorrs['cert_org_address_city'])),
                'require' => true
            ));

            $form->addField('Text', array(
                'name' => 'org_address_region',
                'value' => isset($input['cert_org_address_region']) ? $input['cert_org_address_region'] : null,
                'error' => (!empty($fieldErorrs['cert_org_address_region'])),
                'require' => true
            ));

            $form->addField('Select', array(
                'name' => 'org_address_country',
                'value' => isset($input['cert_org_address_country']) ? $input['cert_org_address_country'] : null,
                'options' => ServerTasticSSLCertificate::getCountries(),
                'require' => true
            ));

            $form->addField('Text', array(
                'name' => 'org_address_line1',
                'value' => isset($input['cert_org_address_line1']) ? $input['cert_org_address_line1'] : null,
                'error' => (!empty($fieldErorrs['cert_org_address_line1'])),
                'require' => true
            ));
            
            $form->addField('Text', array(
                'name' => 'org_address_line2',
                'value' => isset($input['cert_org_address_line2']) ? $input['cert_org_address_line2'] : null,
                'error' => (!empty($fieldErorrs['cert_org_address_line2'])),
                'require' => true
            ));
            
            $form->addField('Text', array(
                'name' => 'org_address_postal_code',
                'value' => isset($input['cert_org_address_postal_code']) ? $input['cert_org_address_postal_code'] : null,
                'error' => (!empty($fieldErorrs['cert_org_address_postal_code'])),
                'require' => true
            ));
            
            $form->addField('Text', array(
                'name' => 'org_address_phone',
                'value' => isset($input['cert_org_address_phone']) ? $input['cert_org_address_phone'] : null,
                'error' => (!empty($fieldErorrs['cert_org_address_phone'])),
                'require' => true
            ));

            $form->addField('Submit', array(
                'name' => 'action',
                'value' => 'finalizeTokenCertificate',
                'disableFinishContainer' => true,
                'sumWithNext' => true
            ));

            $form->addField('Submit', array(
                'name' => 'action',
                'value' => 'Main',
                'skipLabel' => true,
                'disableStartContainer' => true,
                'lang' => 'cancel'
            ));

            $vars['form'] = $form->getHTML();
            return array(
                'template' => 'Template2Cert',
                'vars' => $vars
            );
        } catch (Exception $e) {
            $vars['error'] = $e->getMessage();
            return $this->addTokenCertificateHTMLAction($input, $vars);
        }
    }

    public function finalizeTokenCertificateHTMLAction($input, $vars = array())
    {
        $token = $input['cert_order_token'];
        $fields = array();
        $contactFields = array('tech' => array(), 'admin' => array());
        $orgFields = array();
        $infoFields = array();
        $certificate = new ServerTasticSSLCertificate();
        $certificate->domain = $input['cert_domain'];

        try {
            if (empty($token)) {
                throw new Exception(MGLang::T('empty_token'));
            } else {
                $certificate->getProductFields($token, $fields, $contactFields, $orgFields, $infoFields);
            }

            $data = array();

            foreach($fields as $name => $field) {
                if(isset($input['cert_' . $name])) {
                    switch ($name) {
                        case 'san_domains':
                            if(!empty($input['cert_' . $name])) {
                                $sans = str_replace(',', '.', $input['cert_' . $name]);
                                $data[$name] = str_replace(PHP_EOL, ',', $sans);
                                $data['san_count'] = count(explode(',', $sans));
                            } else {
                                $data[$name] = '';
                                $data['san_count'] = 0;
                            }
                            break;
                        default:
                            $data[$name] = $input['cert_' . $name];
                    }
                }
            }

            foreach ($contactFields as $cat => $values) {
                foreach ($values as $name => $field) {
                    if(isset($input['cert_' . $name])) {
                        $data[$name] = $input['cert_' . $name];
                    }
                }
            }

            foreach ($orgFields as $cat => $values) {
                if(isset($input['cert_' . $cat])) {
                    $data[$cat] = $input['cert_' . $cat];
                }
            }

            $data['renewal'] = 0;

            $certificate = new ServerTasticSSLCertificate();
            $certificate->account = $this->clientUsername;
            $certificate->userId = $this->clientUsername;
            $certificate->domain = $input['cert_domain'];

            $certificate->certAdminContacts = array(
                'admin_contact_email' => $input['cert_admin_contact_email'],
                'admin_contact_organisation_name' => $input['cert_org_name'],
                'admin_contact_address_city' => $input['cert_org_address_city'],
                'admin_contact_address_region' => $input['cert_org_address_region'],
                'admin_contact_address_country' => $input['cert_org_address_country'],
            );

            $certificate->generateCSR();

            //create dns
            //$certificate->proceed('generate');

            //install dns
            //$certificate->proceed('install');

            //create order
            $certificate->placeTokenCertRequest($data);

            $message  = 'Domain: '.$certificate->domain."\n";
            $message .= 'User: '.$certificate->userId."\n";

            $notification = new MGNotification();
            $notification->adminSummary('Certificate has been queued for verification', $message);

            $vars['success'] = MGLang::T('orderAddedSuccessfull');
            return $this->MainHTMLAction($input, $vars);
        } catch (Exception $e) {
            $vars['error'] = $e->getMessage();
            return $this->addTokenCertificateWithFieldsHTMLAction($input, $vars);
        }
    }

    public function addCertificateHTMLAction($input, $vars = array())
    {
        if (isset($input['cert_free']) && $input['cert_free']) {
            return $this->addFreeCertificateHTMLAction($input, $vars);
        }


        $certificate = new ServerTasticSSLCertificate();
        $certificate->account = $this->clientUsername;
        $certificate->domain = $input['cert_domain'];
        $certificate->domainId = $input['cert_domain'];
        $certificate->orderToken = $input['cert_order_token'];
        $aprroverList = true;

        $fieldErorrs = isset($vars['fieldErrors']) ? $vars['fieldErrors'] : array();

        //Check Voucher if exist and if is redeemed

        switch ($certificate->checkVoucher()) {
            case 'available':
                break;
            case 'redeemed' :
                $vars['error'] = MGLang::T('redeemedError');
                return $this->MainHTMLAction($input, $vars);
                break;
            case 'notexist' :
                $vars['error'] = MGLang::T('notexistError');
                return $this->MainHTMLAction($input, $vars);
                break;
            case 'emptytoken' :
                $vars['error'] = MGLang::T('emptytokenError');
                return $this->MainHTMLAction($input, $vars);
                break;
            case 'orderexist' :
                $vars['error'] = MGLang::T('orderexistError');
                return $this->MainHTMLAction($input, $vars);
                break;
            case 'errorauth' :
                $vars['error'] = MGLang::T('errorAuth');
                return $this->MainHTMLAction($input, $vars);
                break;
            default:
                $vars['error'] = MGLang::T('nonevoucherError');
                return $this->MainHTMLAction($input, $vars);
        }

        $voucherdvMethods = $certificate->getVoucherDVMethod();
        foreach ($voucherdvMethods as $voucherdvMethod) {
            if ($voucherdvMethod == 'DV' || $voucherdvMethod == 'OV' || $voucherdvMethod == 'EV') {
                $aprroverList = false;
            }
        }

        $form = new FormCreator('cert', $this, array('cancel' => true));

        $form->addField('Text', array(
            'name' => 'order_token'
        , 'value' => $certificate->orderToken
        , 'readonly' => true
        ));

        $form->addField('Text', array(
            'name' => 'domain'
        , 'value' => $input['cert_domain']
        , 'readonly' => true
        ));

        $options = array();

        if ($aprroverList) {
            foreach ($certificate->getApproverList() as $email) {
                $options[$email] = $email;
            }
            $form->addField('Select', array(
                'name' => 'approver_email'
            , 'options' => $options
            ));
        }

        $form->addField('Legend', array(
            'name' => 'tech_contact'
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_title'
        , 'value' => isset($input['cert_tech_contact_title']) ? $input['cert_tech_contact_title'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_title']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_first_name'
        , 'value' => isset($input['cert_tech_contact_first_name']) ? $input['cert_tech_contact_first_name'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_first_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_last_name'
        , 'value' => isset($input['cert_tech_contact_last_name']) ? $input['cert_tech_contact_last_name'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_last_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_phone'
        , 'value' => isset($input['cert_tech_contact_phone']) ? $input['cert_tech_contact_phone'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_phone']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_email'
        , 'value' => isset($input['cert_tech_contact_email']) ? $input['cert_tech_contact_email'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_email']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_fax'
        , 'value' => isset($input['cert_tech_contact_fax']) ? $input['cert_tech_contact_fax'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_fax']))
        , 'require' => true
        ));

        $form->addField('Legend', array(
            'name' => 'admin_contact'
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_title'
        , 'value' => isset($input['cert_admin_contact_title']) ? $input['cert_admin_contact_title'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_title']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_first_name'
        , 'value' => isset($input['cert_admin_contact_first_name']) ? $input['cert_admin_contact_first_name'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_first_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_last_name'
        , 'value' => isset($input['cert_admin_contact_last_name']) ? $input['cert_admin_contact_last_name'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_last_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_phone'
        , 'value' => isset($input['cert_admin_contact_phone']) ? $input['cert_admin_contact_phone'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_phone']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_email'
        , 'value' => isset($input['cert_admin_contact_email']) ? $input['cert_admin_contact_email'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_email']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_fax'
        , 'value' => isset($input['cert_admin_contact_fax']) ? $input['cert_admin_contact_fax'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_fax']))
        , 'require' => true
        ));

        $form->addField('Legend', array(
            'name' => 'org'
        ));

        $form->addField('Text', array(
            'name' => 'org_name'
        , 'value' => isset($input['cert_org_name']) ? $input['cert_org_name'] : null
        , 'error' => (!empty($fieldErorrs['cert_org_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'org_postalcode'
        , 'value' => isset($input['cert_org_postalcode']) ? $input['cert_org_postalcode'] : null,
            'error' => (!empty($fieldErorrs['cert_org_postalcode']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'org_address_city'
        , 'value' => isset($input['cert_org_address_city']) ? $input['cert_org_address_city'] : null
        , 'error' => (!empty($fieldErorrs['cert_org_address_city']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'org_address_region'
        , 'value' => isset($input['cert_org_address_region']) ? $input['cert_org_address_region'] : null
        , 'error' => (!empty($fieldErorrs['cert_org_address_region']))
        , 'require' => true
        ));

        $form->addField('Select', array(
            'name' => 'org_address_country'
        , 'value' => isset($input['cert_org_address_country']) ? $input['cert_org_address_country'] : null
        , 'options' => CertCenterSSLCertificate::getCountries()
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'org_address_email'
        , 'value' => isset($input['cert_org_address_email']) ? $input['cert_org_address_email'] : null
        , 'error' => (!empty($fieldErorrs['cert_org_address_email']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'org_address_line1'
        , 'value' => isset($input['cert_org_address_line1']) ? $input['cert_org_address_line1'] : null
        , 'error' => (!empty($fieldErorrs['cert_org_address_line1']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'org_address_line2'
        , 'value' => isset($input['cert_org_address_line2']) ? $input['cert_org_address_line2'] : null
        , 'error' => (!empty($fieldErorrs['cert_org_address_line2']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'org_address_phone'
        , 'value' => isset($input['cert_org_address_phone']) ? $input['cert_org_address_phone'] : null
        , 'error' => (!empty($fieldErorrs['cert_org_address_phone']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'org_address_fax'
        , 'value' => isset($input['cert_org_address_fax']) ? $input['cert_org_address_fax'] : null
        , 'error' => (!empty($fieldErorrs['cert_org_address_fax']))
        , 'require' => true
        ));

        $form->addField('Submit', array(
            'name' => 'action'
        , 'value' => 'submitCertificate'
        , 'cancel' => true
        ));

        $vars['addForm'] = $form->getHTML();

        return array(
            'template' => 'AddCert'
        , 'vars' => $vars
        );
    }

    public function addFreeCertificateHTMLAction($input, $vars = array())
    {

        $fieldErorrs = isset($vars['fieldErrors']) ? $vars['fieldErrors'] : array();

        $form = new FormCreator('cert', $this, array('cancel' => true));

        $form->addField('Text', array(
            'name' => 'domain'
        , 'value' => isset($input['modal_domain'])?$input['modal_domain']:$input['cert_domain']
        , 'readonly' => true
        ));

        $form->addField('Legend', array(
            'name' => 'admin'
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_first_name'
        , 'value' => isset($input['cert_admin_contact_first_name']) ? $input['cert_admin_contact_first_name'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_first_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_last_name'
        , 'value' => isset($input['cert_admin_contact_last_name']) ? $input['cert_admin_contact_last_name'] : null,
            'error' => (!empty($fieldErorrs['cert_admin_contact_last_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_phone'
        , 'value' => isset($input['cert_admin_contact_phone']) ? $input['cert_admin_contact_phone'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_phone']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_email'
        , 'value' => isset($input['cert_admin_contact_email']) ? $input['cert_admin_contact_email'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_email']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_title'
        , 'value' => isset($input['cert_admin_contact_title']) ? $input['cert_admin_contact_title'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_title']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_organisation_name'
        , 'value' => isset($input['cert_admin_contact_organisation_name']) ? $input['cert_admin_contact_organisation_name'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_organisation_name']))
        , 'require' => false
        ));


        $form->addField('Text', array(
            'name' => 'admin_contact_address_city'
        , 'value' => isset($input['cert_admin_contact_address_city']) ? $input['cert_admin_contact_address_city'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_address_city']))
        , 'require' => false
        ));

        $form->addField('Text', array(
            'name' => 'admin_contact_address_region'
        , 'value' => isset($input['cert_admin_contact_address_region']) ? $input['cert_admin_contact_address_region'] : null
        , 'error' => (!empty($fieldErorrs['cert_admin_contact_address_region']))
        , 'require' => false
        ));

        $form->addField('Select', array(
            'name' => 'admin_contact_address_country'
        , 'value' => isset($input['cert_admin_contact_address_country']) ? $input['cert_admin_contact_address_country'] : null
        , 'options' => ServerTasticSSLCertificate::getCountries()
        , 'require' => false
        ));


        $form->addField('Legend', array(
            'name' => 'tech'
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_first_name'
        , 'value' => isset($input['cert_tech_contact_first_name']) ? $input['cert_tech_contact_first_name'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_first_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_last_name'
        , 'value' => isset($input['cert_tech_contact_last_name']) ? $input['cert_tech_contact_last_name'] : null,
            'error' => (!empty($fieldErorrs['cert_tech_contact_last_name']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_phone'
        , 'value' => isset($input['cert_tech_contact_phone']) ? $input['cert_tech_contact_phone'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_phone']))
        , 'require' => true
        ));

        $form->addField('Text', array(
            'name' => 'tech_contact_email'
        , 'value' => isset($input['cert_tech_contact_email']) ? $input['cert_tech_contact_email'] : null
        , 'error' => (!empty($fieldErorrs['cert_tech_contact_email']))
        , 'require' => true
        ));

        $form->addField('Submit', array(
            'name' => 'action'
        , 'value' => 'submitFreeCertificate'
        , 'disableFinishContainer' => true,
                    'sumWithNext' => true
        ));

        $form->addField('Submit', array(
            'name' => 'action'
        , 'value' => 'Main'
        , 'skipLabel' => true
        , 'disableStartContainer' => true
        , 'lang' => 'cancel'
        ));

        $vars['addForm'] = $form->getHTML();

        return array(
            'template' => 'AddFreeCert'
        , 'vars' => $vars
        );
    }

    public function submitFreeCertificateHTMLAction($input, $vars = array())
    {
       
        try {
            $certificate = new ServerTasticSSLCertificate();
            $certificate->account = $this->clientUsername;
            $certificate->userId = $this->clientUsername;
            $certificate->domain = $input['cert_domain'];


            $certificate->st_product_code = 'EESecureSiteStarter-12';
            $certificate->end_customer_email = 'none';
            $certificate->reseller_unique_reference = $input['cert_domain'];
            $certificate->csr = $input['cert_domain'];


            $certificate->certAdminContacts = array(
                'admin_contact_first_name' => $input['cert_admin_contact_first_name'],
                'admin_contact_last_name' => $input['cert_admin_contact_last_name'],
                'admin_contact_phone' => $input['cert_admin_contact_phone'],
                'admin_contact_email' => $input['cert_admin_contact_email'],
                'admin_contact_title' => $input['cert_admin_contact_title'],
                'admin_contact_organisation_name' => $input['cert_admin_contact_organisation_name'],
                'admin_contact_address_city' => $input['cert_admin_contact_address_city'],
                'admin_contact_address_region' => $input['cert_admin_contact_address_region'],
                'admin_contact_address_country' => $input['cert_admin_contact_address_country'],
            );

            $certificate->certTechContacts = array(
                'tech_contact_first_name' => $input['cert_tech_contact_first_name'],
                'tech_contact_last_name' => $input['cert_tech_contact_last_name'],
                'tech_contact_phone' => $input['cert_tech_contact_phone'],
                'tech_contact_email' => $input['cert_tech_contact_email'],
            );

            if ($errors = $certificate->parseContacts()) {
                $vars['fieldErrors'] = $errors;
                 
                return $this->addFreeCertificateHTMLAction($input, $vars);
            } else {

               $certificate->generateCSR();
                
                //create dns
                $certificate->proceed('generate');

                //install dns
                $certificate->proceed('install');

                //create order
                $certificate->placeFreeCertRequest();


                //send notification
                $message  = 'Domain: '.$this->domain."\n";
                $message .= 'User: '.$this->userId."\n";
                $message .= 'Certificate: '.$certificate->st_product_code;
                
                $notification = new MGNotification();
                $notification->adminSummary('Certificat has been installed', $message);

                $vars['success'] = MGLang::T('orderAddedSuccessfull');
                return $this->MainHTMLAction($input, $vars);
            }

        } catch (SystemException $ex) {
            MGExceptionLogger::addLog($ex, $ex->getRequest(), $ex->getResponse(), $input['cert_domain']);
            $vars['error'] = 'ERROR: ' . $ex->getMessage();
            $vars['success'] = '<div>Possible problems:</div>'
            .'<div>*Entered information is wrong, please check and resubmit data</div>'
            .'<div>*Authentication DNS entry is not reachable, order will be automatically provisioned by cron</div>';


            return $this->addFreeCertificateHTMLAction($input, $vars);
        }
    }

    public function getInfoJSONAction($input,$vars = array())
    {
        if(isset($input['data']['domainName']) && isset($input['data']['voucherCode'])){
            $certificate                    = new ServerTasticSSLCertificate();
            $certificate->account           = $this->clientUsername;
            $certificate->domain            = $input['data']['domainName'];
            $certificate->reseller_order_id = $input['data']['order_id'];
            $certificate->orderToken        = $input['data']['voucherCode'];
            $vars                           = $certificate->getOrderInformation();
        }

        return $vars;
    }

    public function renewCertHTMLAction($input, $vars = array())
    {
        $certOrder = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders'));
        $vouchersList = $certOrder->domainId = $input['cert_domain'];
        $vouchersList = $certOrder->getDomain();

        if(empty($vouchersList)){
            $vars['error'] = 'Error with certificate renewal';
        }
        try{
            $certificate = new ServerTasticSSLCertificate();
            $certificate->reseller_order_id = $vouchersList[0]['reseller_order_id'];
            $certificate->orderToken        = $input['order_token'];
            $certificate->csr               = $vouchersList[0]['csr'];
            $certificate->userId            = $vouchersList[0]['userId'];
            $certificate->key               = $vouchersList[0]['key'];
            $certificate->domain            = $certOrder->domainId;
            if(isset($vouchersList[0]['filename']) && ($data = json_decode($vouchersList[0]['filename']))) {
                if(empty($input['cert_order_token'])) {
                    $form = new FormCreator('cert', $this, array('cancel' => true));

                    $form->addField('Text', array(
                        'name' => 'domain',
                        'value' => isset($input['cert_domain'])?$input['cert_domain']:'',
                        'readonly' => true
                    ));

                    $form->addField('Text', array(
                        'name' => 'order_token',
                        'require' => true,
                    ));

                    $form->addField('Submit', array(
                        'name' => 'action',
                        'value' => 'renewCert',
                        'disableFinishContainer' => true,
                        'sumWithNext' => true
                    ));

                    $form->addField('Submit', array(
                        'name' => 'action',
                        'value' => 'Main',
                        'skipLabel' => true,
                        'disableStartContainer' => true,
                        'lang' => 'cancel'
                    ));

                    $vars['form'] = $form->getHTML();
                    return array(
                        'template' => 'TemplateCert',
                        'vars' => $vars
                    );
                } else {
                    $data->order_token = $input['cert_order_token'];
                    $renewMessage = $certificate->renewTokenCert($data);
                }
            } else {
                $certificate->orderToken = $input['cert_order_token'];
                $renewMessage = $certificate->renewCert($vouchersList[0]['reseller_order_id']);
            }
            
            $vars['success'] = $renewMessage;
        }
        catch (Exception $ex) {
            $vars['error'] = $ex->getMessage();
        }

        return $this->MainHTMLAction($input, $vars);
    }

    public function removeCertHTMLAction($input, $vars = array())
    {
        $certificate = new ServerTasticSSLCertificate();

        try{
            $certificate->domainId = $input['cert_domain'];
            $certificate->domain   = $input['cert_domain'];
            $ret = $certificate->removeCert($this->clientUsername);

            $certOrder = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders'));
            $certOrder->reseller_order_id = $input['order_id'];
            $certOrder->delete();
            
            $taskOrder = new MGCronTask(array('_tableName' => 'ServerTasticSSL_cron_tasks'));
            $taskOrder->domainId = $certificate->domain;
            $taskOrder->deleteByDomainID();
            
            $vars['success'] = $ret['messages'];
        }
        catch (Exception $ex) {
            $vars['error'] = $ex->getMessage();
        }

        return $this->MainHTMLAction($input, $vars);
    }

    public function cancelCertHTMLAction($input, $vars = array()){

        try{
            $certOrder = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders'));
            $vouchersList = $certOrder->domainId = $input['cert_domain'];
            $vouchersList = $certOrder->getDomain();

            $certificate = new ServerTasticSSLCertificate();
            $certificate->reseller_order_id = $input['order_id'];
            $certificate->domain = $input['cert_domain'];
            if(isset($vouchersList[0]['filename']) && ($data = json_decode($vouchersList[0]['filename']))) {
                $certificate->cancelTokenCert();
            } else {
                $certificate->cancelCert();
            }

            $vars['success'] = 'success';
        }
        catch (Exception $ex) {
            $vars['error'] = $ex->getMessage();
        }

        return $this->MainHTMLAction($input, $vars);
    }
}


