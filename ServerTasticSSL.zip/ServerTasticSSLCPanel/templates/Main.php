
<link rel="stylesheet" type="text/css" href="./assets/css/jquery.dataTables.css" />
<script type="text/javascript" src="./assets/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="./assets/js/dataTables.bootstrap.js"></script>
<script type="text/javascript" src="./assets/js/jquery.dataTables.bootstrap.js"></script>
<?php if(!empty($error)): ?>
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true" >&times;</span><span class="sr-only"><?php echo MGLang::T('close'); ?></span></button>
        <?php echo $error; ?>
    </div>
<?php endif; ?>
<?php if(!empty($success)): ?>
    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true" >&times;</span><span class="sr-only"><?php echo MGLang::T('close'); ?></span></button>
        <?php echo $success; ?>
    </div>
<?php endif; ?>
    <p><?php echo MGLang::T('description'); ?></p>
    <legend><?php echo MGLang::T('certDetails','domains'); ?></legend>
    <table class="table table-hover" id="domainsTable">
        <thead>
        <tr>
            <th><?php echo MGLang::T('thead','domain'); ?></th>
          <!--  <th><?php echo MGLang::T('thead','created'); ?></th>
            <th><?php echo MGLang::T('thead','activated'); ?></th>-->
            <th><?php echo MGLang::T('thead','expired'); ?></th>
            <th><?php echo MGLang::T('thead','status'); ?></th>
            <th><?php echo MGLang::T('thead','actions'); ?></th>
        </tr>
        </thead>
        <tbody>

        <?php if(!empty($certs)): ?>
            <?php foreach($certs as $cert): ?>
                <tr>
                    <td><?php echo $cert['domainId']; ?></td>
                    <td><?php echo strstr($cert['expiry_date'],' ', true); ?></td>
                    <td><?php echo $cert['status']; ?></td>
                    <td>
                <?php if(empty($cert['actions']) || $cert['actions'] != 'sslTastic'): ?>
                         <form method="post" style="float: left;margin-right:3px;">
                             <input type="hidden" name="modal_domain" value="<?php echo $cert['domainId']; ?>" />
                            <!--<button style="margin-bottom:3px;float:left;margin-right: 3px;" type="submit" class="btn btn-success btn-xs" <?php /*// data-toggle="modal" data-target="#installMenu" * */?> name="action" value="addFreeCertificate"  data-order_id="<?php /*echo $cert['reseller_order_id']; */?>"><?php /*echo MGLang::T('actions','installMenu'); */?></button>-->
                             <button style="margin-bottom:3px;float:left;margin-right: 3px;" type="submit" class="btn btn-info btn-xs" <?php // data-toggle="modal" data-target="#installMenu" * ?> name="action" value="addTokenCertificate"  data-order_id="<?php echo $cert['reseller_order_id']; ?>"><?php echo MGLang::T('actions','tokenMenu'); ?></button>
                    </form>
                <?php else: ?>
                       
                    <button style="margin-bottom:3px;float:left;margin-right: 3px;" type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#certDetails" data-action="certInfo" data-domain="<?php echo $cert['domainId']; ?>" data-order_id="<?php echo $cert['reseller_order_id']; ?>" data-order_token="<?php echo $cert['orderVoucher'];?>"><?php echo MGLang::T('actions','details'); ?></button>
                    <form method="post" style="float: left;margin-right:3px;">
                        <input type="hidden" name="order_id" value="<?php echo $cert['reseller_order_id']; ?>">
                        <input type="hidden" name="order_token" value="<?php echo $cert['orderVoucher']; ?>">
                        <input type="hidden" name="cert_domain" value="<?php echo $cert['domainId']; ?>">
                        <button style="margin-bottom:3px;float:left;margin-right: 3px;" type="submit" class="btn btn-info btn-xs confirm" name="action" value="renewCert"  ><?php echo MGLang::T('actions','renew'); ?></button>
                        <button style="margin-bottom:3px;float:left;margin-right: 3px;" type="submit" class="btn btn-info btn-xs confirm" name="action" value="removeCert" ><?php echo MGLang::T('actions','remove'); ?></button>
                    </form>
                <?php endif; ?>

                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
<?php if(!empty($certs)): ?>
    <div class="modal fade" id="certDetails" data-target-on-load="getInfo" tabindex="-1" role="dialog" aria-labelledby="certDetailsLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" >&times;</span></button>
                    <h4 class="modal-title" id="certDetailsLabel"><?php echo MGLang::T('certDetails','title'); ?></h4>
                </div>
                <div class="modal-loader"></div>
                <div class="modal-body">
                    <div class="op_info_content" id="order_information">
                        <div class="op_info_head" style="font-weight: bold"><?php echo MGLang::T('certDetails','order_information'); ?></div>
                        <div class="op_row">
                            <?php echo MGLang::T('certDetails','order_id'); ?> <span id="op_provider_order_id"></span>
                        </div>
                        <div class="op_row">
                            <?php echo MGLang::T('certDetails','product_type'); ?> <span id="op_st_product_code"></span>
                        </div>
                        <div class="op_row">
                            <?php echo MGLang::T('certDetails','domain_name'); ?> <span id="op_domain_name"></span>
                        </div>
                    </div>
                    <div>&nbsp;</div>
                    <div class="op_info_content" id="tech_contact">
                        <div class="op_info_head" style="font-weight: bold"><?php echo MGLang::T('certDetails','tech_contact'); ?></div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','first_name'); ?> <span id="op_tech_contact_first_name"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','last_name'); ?> <span id="op_tech_contact_last_name"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','fax'); ?> <span id="op_tech_contact_fax"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','phone'); ?> <span id="op_tech_contact_phone"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','email'); ?> <span id="op_tech_contact_email"></span>
                        </div>
                    </div>
                    <div>&nbsp;</div>
                    <div class="op_info_content" id="admin_contact">
                        <div class="op_info_head" style="font-weight: bold"><?php echo MGLang::T('certDetails','admin_contact'); ?></div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','cert_title'); ?> <span id="op_admin_contact_title"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','first_name'); ?> <span id="op_admin_contact_first_name"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','last_name'); ?> <span id="op_admin_contact_last_name"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','fax'); ?> <span id="op_admin_contact_fax"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','phone'); ?> <span id="op_admin_contact_phone"></span>
                        </div>
                        <div class="op_row op_single_param">
                            <?php echo MGLang::T('certDetails','email'); ?> <span id="op_admin_contact_email"></span>
                        </div>
                    </div>
                    <div>&nbsp;</div>
                    <div class="op_info_content" id="certificate">
                        <div class="op_info_head" style="font-weight: bold"><?php echo MGLang::T('certDetails','certificate'); ?></div>
                        <div class="op_row op_single_param">
                            <textarea id="op_cert" style="width:100%;height:200px;"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo MGLang::T('certDetails','cancel'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="op_loader hide">
        <div class="windows8">
            <div class="modal-loader"></div>
        </div>
    </div>
    <script type="text/javascript">

        $(document).ready(function(){
            $('body').css('position','relative');
            $('#certDetails').on('show.bs.modal', function (e) {
                var id = $(e.relatedTarget).attr('data-target-id');
                var action = $(e.currentTarget).attr('data-target-on-load');
                $(e.currentTarget).find('.modal-loader').show();
                $(e.currentTarget).find('.modal-body').hide();

                ajaxParser.request(
                    action
                    ,{
                        id: id
                    }
                    ,function(result){

                        for(x in result.cert)
                        {
                            $(e.currentTarget).find('textarea[data-text="'+x+'"]').text(result.cert[x]);
                            $(e.currentTarget).find('input[data-value="'+x+'"]').val(result.cert[x]);
                        }

                        $(e.currentTarget).find('.modal-body').show();
                        $(e.currentTarget).find('.modal-loader').hide();
                    }
                );
            });

            $('.btn').click(function(){
                var certAction = $(this).data('action');

                if($(this).hasClass('confirm')){
                    return confirm("<?php echo MGLang::T('certDetails','confirmation'); ?>");
                }

                if(certAction == 'certInfo'){
                    var domain = $(this).data('domain');
                    var order_id = $(this).data('order_id');
                    var order_token = $(this).data('order_token');
                    var action = 'getInfo';
                    $("#cpanel_body").css("position","static");
                    //$(e.currentTarget).find('.modal-loader').show();
                    //$(e.currentTarget).find('.modal-body').hide();
                    $("#order_information").hide();
                    $(".op_single_param").hide();
                    $("#organization_information").hide();
                    $("#tech_contact").hide();
                    $("#admin_contact").hide();
                    $("#certificate").hide();
                    ajaxParser.request(
                        action,
                        {domainName: domain,voucherCode: order_token, order_id: order_id },
                        function(result){
                            $.each( result, function( infoHead , infoParams ) {
                               // console.log(infoHead+" "+infoParams);
                                $("#"+infoHead).show();
                                    
                                if( $.isPlainObject(infoParams))
                                {
                                    $.each( infoParams, function( inputName , inputValue ) {                                        
                                        $('#op_'+infoHead+"_"+inputName).text(inputValue);
                                        $('#op_'+infoHead+"_"+inputName).parent().show();
                                    });
                                }else if(infoHead == "certificate")
                                {
                                    $("#op_cert").val(infoParams);
                                    $("#op_cert").parent().show();
                                    $("#certificate").show();
                                }                         
                                else
                                {
                                    $("#op_"+infoHead).text(infoParams);
                                }
                            });
                            $("#order_information").show();
                            //$(e.currentTarget).find('.modal-loader').hide();
                            //$(e.currentTarget).find('.modal-body').show();
                            $('.modal-backdrop.fade.in').remove();
                        }
                    );
                }
            });
        });
    </script>
<?php endif; ?>

<!-- Install New Certificate -->
<div class="modal fade" id="installMenu"  tabindex="-1" role="dialog" aria-labelledby="installMenuLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" >&times;</span></button>
                <h4 class="modal-title" id="installMenuLabel"><?php echo MGLang::T('installMenu','title'); ?></h4>
            </div>
            <div class="modal-body">
                <form method="post" style="float: left;margin-right:3px;">
                    <input type="hidden" name="modal_domain" value="">

                    <?php /*
    <div>
        <button style="margin-bottom:3px;" type="submit" class="btn btn-info btn-xs" name="action" value="activateOrder"><?php echo MGLang::T('actions','activateOrder'); ?></button>
    </div>
*/?>
                    <div>
                        <button style="margin-bottom:3px;" type="submit" class="btn btn-info btn-xs" name="action" value="addFreeCertificate"><?php echo MGLang::T('actions','activateFreeCertificate'); ?></button>
                    </div>
                    <?php /*
    <div>
        <button style="margin-bottom:3px;" type="submit" class="btn btn-info btn-xs" name="action" value="purchaseCertificate"><?php echo MGLang::T('actions','purchase'); ?></button>
    </div>
*/?>
                </form>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo MGLang::T('certDetails','cancel'); ?></button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

    $(document).ready(function(){
        $('#installMenu').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var domain = button.data('domain');
            var modal = $(this);
            modal.find('.modal-body input[name=modal_domain]').val(domain);
        });
    });
</script>


<script type="text/javascript">
    $(document).ready(function(){
        $('input[name=cert_free]').change(function(){
            if($(this).is(':checked')){
                $('input[name=cert_order_token]').parent().parent().hide();
            }
            else{
                $('input[name=cert_order_token]').parent().parent().show();
            }
        });


        $('#domainsTable').DataTable();



    });
</script>
