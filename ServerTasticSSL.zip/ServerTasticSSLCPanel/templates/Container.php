<link rel="stylesheet" type="text/css" href="./assets/css/MGBootstrap.css" />
<link rel="stylesheet" type="text/css" href="./assets/css/slider.css" />
<link rel="stylesheet" type="text/css" href="./assets/css/style.css" />
<script type="text/javascript" src="./assets/js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="./assets/js/ajaxParser.js"></script>
<script type="text/javascript" src="./assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="./assets/js/bootstrap-slider.js"></script>
<script type="text/javascript">
    ajaxParser.create('<?php echo $currenAjax; ?>');
</script>
<div id="MGContent" class="MGBootstrap">
    <div class="row" id="MGErrors">
        <div class="col-lg-12">
            <?php if(!empty($error)): ?>
                <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true" >&times;</span><span class="sr-only"><?php echo MGLang::T('close'); ?></span></button>
                    <?php echo $error; ?>
                    <?php if(!empty($errorID)): ?>
                        <strong>#<?php echo $errorID; ?></strong>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if(!empty($success)): ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            <div class="alertContainer">
                <div class="alertPrototype" style="display:none;">
                    <div class="alert alert-danger">
                        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true" >&times;</span><span class="sr-only"><?php echo MGLang::T('close'); ?></span></button>
                        <strong></strong>
                        <p style="text-weight:bold;" class="errorID"></p>
                    </div>
                </div>
                <div class="alertPrototype" style="display:none;">
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true" >&times;</span><span class="sr-only"><?php echo MGLang::T('close'); ?></span></button>
                        <strong></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <?php echo $content; ?>
        </div>
    </div>
    <div class="clearfix"></div>
</div>

