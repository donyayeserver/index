<?php if($enableLabel): ?>
    <label for="<?php echo $formName.'_'.$name; ?>" class="col-sm-2 control-label"><?php echo MGLang::T('label'); ?></label>
<?php endif; ?>
<div class="col-sm-4">
  <select name="<?php echo $formName.'_'.$name; ?>" class="form-control" id="<?php echo $formName.'_'.$name; ?>">
  <?php echo $value; ?>
      <?php foreach($options as $opKey => $opValue): ?>
      <option value="<?php echo $opKey; ?>" <?php if($opKey == $value): ?>selected="selected"<?php endif;?> ><?php echo $opValue; ?></option>
      <?php endforeach; ?>
  </select>
  <?php if($enableDescription): ?>
    <span class="help-block"><?php echo MGLang::T('label'); ?></span>
  <?php endif;?>
</div>