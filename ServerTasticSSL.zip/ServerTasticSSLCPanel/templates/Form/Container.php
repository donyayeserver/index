<div class="col-lg-12">
    <form class="form-horizontal" action="<?php echo $url; ?>" method="post">
        <?php foreach($htmlHiddenFields as $field):?>
                  <?php echo $field; ?>
        <?php endforeach; ?>
        <?php foreach($htmlFields as $field):?>
              <div class="form-group">
                  <?php echo $field; ?>
              </div>
        <?php endforeach; ?>
    </form>
</div>
