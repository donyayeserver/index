<input name="<?php echo $formName.'_'.$name; ?>" type="hidden" value="<?php echo $value; ?>">
