<?php if(!empty($error)): ?>
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true" >&times;</span><span class="sr-only"><?php echo MGLang::T('close'); ?></span></button>
        <?php echo $error; ?>
    </div>
<?php endif; ?>
<?php echo $form;?>

<script type="text/javascript">
    $("form button[type=submit]").click(function (event) {
        $(this).parents("form").append("<input type='hidden' name='action' id='temp_action'>");
        $("#temp_action").val($(this).val());
        $(this).parents("form").submit();
        $(this).parents("form").find("button[type=submit]").prop("disabled", true );
        $(this).parent().prepend("<span class='report_spinner'>&nbsp</span>");
        $("#temp_action").remove();
        event.preventDefault();
    });
</script>
