<?php if(!empty($error)): ?>
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true" >&times;</span><span class="sr-only"><?php echo MGLang::T('close'); ?></span></button>
        <?php echo $error; ?>
    </div>
<?php endif; ?>
<?php echo $addForm; ?>
<script type="text/javascript">
    $(document).ready(function(){
       $('input[name=cert_tech_contact_title]').change(function(){
            var copy = $('input[name=cert_admin_contact_title]');
            console.log($(this).val());
            console.log($.trim($(this).val()));
            
            var test = $.trim($(this).val());
            
            if(!copy.val())
            {
                copy.val($.trim($(this).val()));
                copy.change();
            }
       });
       $('input[name=cert_tech_contact_first_name]').change(function(){
            if($.trim($(this).val()) != '' && $(this).next().is('span')){
                $(this).parent().removeClass('has-error');
                $(this).next().remove();
            }
            var copy = $('input[name=cert_admin_contact_first_name]');
            if(!copy.val())
            {
                copy.val($.trim($(this).val()));
                copy.change();
            }
       });
       $('input[name=cert_tech_contact_last_name]').change(function(){
            if($.trim($(this).val()) != '' && $(this).next().is('span')){
                $(this).parent().removeClass('has-error');
                $(this).next().remove();
            }
            var copy = $('input[name=cert_admin_contact_last_name]');
            if(!copy.val())
            {
                copy.val($.trim($(this).val()));
                copy.change();
            }
       });
       $('input[name=cert_tech_contact_phone]').change(function(){
            if($.trim($(this).val()) != '' && $(this).next().is('span')){
                $(this).parent().removeClass('has-error');
                $(this).next().remove();
            }
            var copy = $('input[name=cert_admin_contact_phone]');
            if(!copy.val())
            {
                copy.val($.trim($(this).val()));
                copy.change();
            }
       });
       $('input[name=cert_tech_contact_email]').change(function(){
            if($.trim($(this).val()) != '' && $(this).next().is('span')){
                $(this).parent().removeClass('has-error');
                $(this).next().remove();
            }
            var copy = $('input[name=cert_admin_contact_email]');
            if(!copy.val())
            {
                copy.val($.trim($(this).val()));
                copy.change();
            }
       });
        $('input[name=cert_tech_contact_fax]').change(function(){
            if($.trim($(this).val()) != '' && $(this).next().is('span')){
                $(this).parent().removeClass('has-error');
                $(this).next().remove();
            }
            var copy = $('input[name=cert_admin_contact_fax]');
            if(!copy.val())
            {
                copy.val($.trim($(this).val()));
                copy.change();
            }
       });
       
        $('input').change(function(){
            if($.trim($(this).val()) != '' && $(this).next().is('span')){
                $(this).parent().removeClass('has-error');
                $(this).next().remove();
            }
        });
       
    });
</script>