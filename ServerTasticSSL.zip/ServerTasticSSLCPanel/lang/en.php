<?php

$_LANG['Container']['close'] = 'Close';
$_LANG['Main']['description'] = "The HTTPS Installer allows you to obtain HTTPS certificates for your domains. The ability to install HTTPS certificate on your website is essential for its fundamental protection. It provides privacy, strict security and data integrity for both your website and your users' sensitive information.";

$_LANG['Main']['errorMessages']['general'] = 'Something went wrong. Please contact admin';

//General Errors
$_LANG['errorMessages']['general'] = 'Something went wrong. Please contact admin';
$_LANG['errorMessages']['errorID'] = ' Error ID:';
$_LANG['errorMessages']['actionNotExits'] = 'Action does not exist';
$_LANG['Main']['errorMessages']['general'] = 'Something went wrong. Please contact admin';
$_LANG['errorMessages']['errorID'] = ' Error ID:';
$_LANG['Main']['add']['description'] = "Please fill in the form below to receive a free HTTPS certificate. Once you submit the request, the system will automatically generate a required certificate signing request (CSR) for your domain. Please note that the domain verification process may take some time.";


$_LANG['Main']['close']  = 'Close';
$_LANG['Main']['wrongToken'] = 'Wrong Token';
$_LANG['Main']['alreadyExistsToken'] = 'Token already exists';

$_LANG['Main']['cert']['header']  = 'Add Certificate';
$_LANG['Main']['cert']['free']['label'] = 'Free Certificate';
$_LANG['Main']['cert']['order_token']['label'] = 'Token';
$_LANG['Main']['cert']['domain']['label'] = 'Install On';
$_LANG['Main']['cert']['action']['label'] = 'Add Certificate';
$_LANG['Main']['cert']['action']['cancel'] = 'Cancel';

$_LANG['Main']['thead']['domain']                                       = 'Domain';
$_LANG['Main']['thead']['issuer']                                       = 'Issuer';
$_LANG['Main']['thead']['created']                                      = 'Token Created';
$_LANG['Main']['thead']['activated']                                    = 'Token Activated';
$_LANG['Main']['thead']['expired']                                   	= 'Expiration';
$_LANG['Main']['thead']['actions']                                      = 'Actions';
$_LANG['Main']['thead']['status']                                       = 'Status';

$_LANG['Main']['certDetails']['title']                                  = 'Certificate Details';
$_LANG['Main']['certDetails']['cancel']                                 = 'Close';

$_LANG['Main']['certDetails']['domain']                                 = 'Domain';
$_LANG['Main']['certDetails']['issuer']                                 = 'Issuer';
$_LANG['Main']['certDetails']['expiration']                             = 'Expiration';
$_LANG['Main']['certDetails']['type']                                   = 'Type';
$_LANG['Main']['certDetails']['cert']                                   = 'Certificate';
$_LANG['Main']['certDetails']['text']                                   = 'Text';
$_LANG['Main']['certDetails']['order_information']                      = 'Order Information';
$_LANG['Main']['certDetails']['order_id']                               = 'Order ID:';
$_LANG['Main']['certDetails']['product_type']                           = 'Product Type:';        
$_LANG['Main']['certDetails']['domain_name']                            = 'Domain Name:';
$_LANG['Main']['certDetails']['tech_contact']                           = 'Technical Contact';
$_LANG['Main']['certDetails']['admin_contact']                           ='Admin Contact';
$_LANG['Main']['certDetails']['first_name']                             = 'First Name:';        
$_LANG['Main']['certDetails']['last_name']                              = 'Last Name:';        
$_LANG['Main']['certDetails']['fax']                                    = 'Fax:';
$_LANG['Main']['certDetails']['phone']                                  = 'Phone:';
$_LANG['Main']['certDetails']['email']                                  = 'Email:';
$_LANG['Main']['certDetails']['cert_title']                             = 'Title:';
$_LANG['Main']['certDetails']['certificate']                            = 'Certificate';
$_LANG['Main']['certDetails']['confirmation']                           = 'Are you sure you want to make this action?';        
        

$_LANG['Main']['actions']['details']                                    = 'Details';
$_LANG['Main']['actions']['reissue']                                    = 'Reissue';
$_LANG['Main']['actions']['revoke']                                     = 'Revoke';
$_LANG['Main']['actions']['delete']                                     = 'Delete';
$_LANG['Main']['actions']['info']                                       = 'Info';
$_LANG['Main']['actions']['cancel']                                     = 'Cancel';

$_LANG['Main']['cert']['org']['label']                                  = 'Organization';
$_LANG['Main']['cert']['org_name']['label']                             = 'Name';
$_LANG['Main']['cert']['org_division']['label']                         = 'Division';
$_LANG['Main']['cert']['org_address_city']['label']                     = 'City';
$_LANG['Main']['cert']['org_address_region']['label']                   = 'Region';
$_LANG['Main']['cert']['org_address_country']['label']                  = 'Country';
$_LANG['Main']['cert']['org_address_email']['label']                    = 'Email';
$_LANG['Main']['cert']['org_address_postal_code']['label']              = 'Postal Code';
$_LANG['Main']['cert']['org_address_phone']['label']                    = 'Phone';
$_LANG['Main']['cert']['org_address_line1']['label']                    = 'Address 1';
$_LANG['Main']['cert']['org_address_line2']['label']                    = 'Address 2';
$_LANG['Main']['cert']['org_address_fax']['label']                      = 'Fax';
$_LANG['Main']['cert']['approver_email']['label']                       = 'Approver Email';


$_LANG['Main']['cert']['admin']['label'] = 'Admin Contact';
$_LANG['Main']['cert']['admin_contact_first_name']['label'] = 'First Name';
$_LANG['Main']['cert']['admin_contact_first_name']['errorLabel'] = 'This is not a valid first name';
$_LANG['Main']['cert']['admin_contact_last_name']['label'] = 'Last Name';
 $_LANG['Main']['cert']['admin_contact_last_name']['errorLabel'] = 'This is not a valid last name';
$_LANG['Main']['cert']['admin_contact_phone']['label'] = 'Phone';
$_LANG['Main']['cert']['admin_contact_phone']['errorLabel'] = 'This is not a valid contact phone';
$_LANG['Main']['cert']['admin_contact_email']['label'] = 'Email';
$_LANG['Main']['cert']['admin_contact_email']['errorLabel'] = 'This is not a valid contact email';
$_LANG['Main']['cert']['admin_contact_title']['label'] = 'Title';
$_LANG['Main']['cert']['admin_contact_title']['errorLabel'] = 'This is not a valid title name';
$_LANG['Main']['cert']['admin_contact_organisation_name']['label'] = 'Organization';
$_LANG['Main']['cert']['admin_contact_organisation_name']['errorLabel'] = 'This is not a valid organization name';
$_LANG['Main']['cert']['admin_contact_address_line1']['label'] = 'Address 1';
$_LANG['Main']['cert']['admin_contact_address_line2']['label'] = 'Address 2';
$_LANG['Main']['cert']['admin_contact_address_city']['label'] = 'City';
$_LANG['Main']['cert']['admin_contact_address_city']['errorLabel'] = 'This is not a valid city name';
$_LANG['Main']['cert']['admin_contact_address_region']['label'] = 'Region';
$_LANG['Main']['cert']['admin_contact_address_region']['errorLabel'] = 'This is not a valid region name';
$_LANG['Main']['cert']['admin_contact_address_post_code']['label'] = 'Postal Code';
$_LANG['Main']['cert']['admin_contact_address_country']['label'] = 'Country';


$_LANG['Main']['cert']['tech']['label'] = 'Technical Contact';
$_LANG['Main']['cert']['tech_contact_first_name']['label'] = 'First Name';
$_LANG['Main']['cert']['tech_contact_first_name']['errorLabel'] = 'This is not a valid first name';
$_LANG['Main']['cert']['tech_contact_last_name']['label'] = 'Last Name';
$_LANG['Main']['cert']['tech_contact_last_name']['errorLabel'] = 'This is not a valid last name';
$_LANG['Main']['cert']['tech_contact_phone']['label'] = 'Phone';
$_LANG['Main']['cert']['tech_contact_phone']['errorLabel'] = 'This is not a valid contact phone';
$_LANG['Main']['cert']['tech_contact_email']['label'] = 'Email';
$_LANG['Main']['cert']['tech_contact_email']['errorLabel'] = 'This is not a valid contact email';
$_LANG['Main']['cert']['tech_contact_title']['label'] = 'Title';
$_LANG['Main']['cert']['tech_contact_title']['errorLabel'] = 'This is not a valid title name';
$_LANG['Main']['cert']['tech_contact_organisation_name']['label'] = 'Organization';
$_LANG['Main']['cert']['tech_contact_organisation_name']['errorLabel'] = 'This is not a valid organization name';
$_LANG['Main']['cert']['tech_contact_address_line1']['label'] = 'Address 1';
$_LANG['Main']['cert']['tech_contact_address_line2']['label'] = 'Address 2';
$_LANG['Main']['cert']['tech_contact_address_city']['label'] = 'City';
$_LANG['Main']['cert']['tech_contact_address_region']['label'] = 'Region';
$_LANG['Main']['cert']['tech_contact_address_post_code']['label'] = 'Postal Code';
$_LANG['Main']['cert']['tech_contact_address_country']['label'] = 'Country';


$_LANG['Main']['token_certificate_form']['token']['label'] = 'Token:';
$_LANG['Main']['token_certificate_form']['action']['label'] = 'Next';
$_LANG['Main']['token_certificate_form']['action']['cancel'] = 'Cancel';


$_LANG['Main']['certDetails']['domains'] = 'Domains';
$_LANG['Main']['actions']['installMenu'] = 'Install New Certificate';
$_LANG['Main']['actions']['tokenMenu'] = 'Use Token';
$_LANG['Main']['actions']['activateFreeCertificate'] = 'Activate Free SSL';
$_LANG['Main']['actions']['upgrade'] = 'Upgrade';
$_LANG['Main']['actions']['renew'] = 'Renew';
$_LANG['Main']['actions']['remove'] = 'Remove';
$_LANG['Main']['token_certificate_form']['domain']['label'] = 'Install On';
$_LANG['Main']['cert']['info']['label'] = 'Certificate';
$_LANG['Main']['cert']['General']['label'] = 'General';
$_LANG['Main']['cert']['Organisation']['label'] = 'Organization';
$_LANG['Main']['cert']['san_domains']['label'] = 'San Domains (each in separate line)';
$_LANG['Main']['cert']['web_server_type']['label'] = 'WebServerType';
$_LANG['Main']['cert']['domain']['label'] = 'Domain';
$_LANG['Main']['cert']['renew']['label'] = 'Renew Certificate';

$_LANG['Main']['cert']['hashing_algorithm']['label'] = 'Hashing Algorithm';
$_LANG['Main']['cert']['competitive_upgrade']['label'] = 'Competitive Upgrade';
$_LANG['Main']['cert']['approver_email_address']['label'] = 'Approver Email';


$_LANG['Main']['empty_token'] = 'Please provide token first';
$_LANG['Main']['required_fields_empty'] = 'This product is not supported';
$_LANG['Main']['invalid_token'] = 'Token is invaild';

$_LANG['Main']['installMenu']['title'] = 'Install New Certificate';
$_LANG['Main']['orderAddedSuccessfull'] = 'Certificate successfuly ordered';
