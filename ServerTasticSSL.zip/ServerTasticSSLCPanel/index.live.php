<?php
define("DS",DIRECTORY_SEPARATOR);

define("ServerTasticSSL_INCLUDES",'/usr/local/cpanel/share/ServerTasticSSL/');

require_once "/usr/local/cpanel/php/cpanel.php";
 $CPANEL = new CPANEL();
require_once ServerTasticSSL_INCLUDES.'ServerTasticSSLLoader.php';

try
{
    $Main = new ServerTasticSSLMainController('CPanel',__DIR__);
    $Main->setClientArea();

    $page   = empty($_REQUEST['page'])?null:$_REQUEST['page'];
    $action = empty($_REQUEST['action'])?null:$_REQUEST['action'];

    echo ServerTasticSSLDriver::localAPI()->getHeader();
    echo $Main->getHTMLPage($page,$action,$_REQUEST);
    echo ServerTasticSSLDriver::localAPI()->getFooter();
}
catch(Exception $ex){
    echo "Something Goes wrong";
}
