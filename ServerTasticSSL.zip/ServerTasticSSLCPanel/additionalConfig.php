<?php

$additionalConfig['baseUrlConfig']['html'] = 'index.live.php';
$additionalConfig['baseUrlConfig']['ajax'] = 'ajax.live.php';