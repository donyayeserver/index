<?php 


define("DS",DIRECTORY_SEPARATOR);

define("ServerTasticSSL_INCLUDES",'/usr/local/cpanel/share/ServerTasticSSL/');

require_once "/usr/local/cpanel/php/cpanel.php";

require_once ServerTasticSSL_INCLUDES.'ServerTasticSSLLoader.php';

try
{
    $CPANEL = new CPANEL();
    
    $exSupport = new ExceptionHandler();
    $exSupport->register();
    
    
    $Main = new ServerTasticSSLMainController('CPanel',__DIR__);
    $Main->setClientArea();
    
    $page   = empty($_REQUEST['page'])?null:$_REQUEST['page'];
    $action = empty($_REQUEST['action'])?null:$_REQUEST['action'];
    
    echo $Main->getJSONResponse($page,$action,$_REQUEST);
}
catch(Exception $ex){
    echo "Something Goes wrong";
}