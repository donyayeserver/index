<?php

class CPanelLocalAPIDriver extends WHMLocalAPIDriver{
    public $clientUsername;
    public $cpanel;
    
    function __construct($params) {
        $this->cpanel = $GLOBALS['CPANEL'];
        parent::__construct($params);
    }
    
    public function _connect($params){
        $content = explode("\n", $this->getAccessHash());

        $this->apiKey = $this->getToken($content);
        if(empty($this->apiKey))
        {
            throw new SystemException("Can't get API Token",404);
        }

        $this->clientUsername = $this->getCurrentUser();
    }
    
    private function _callUAPI($module,$action,$params = array()){
        $ret = $this->cpanel->uapi($module, $action, $params);

        if(!empty($ret['cpanelresult']['result']['errors']))
        {
            throw new SystemException(implode('/',$ret['cpanelresult']['result']['errors']),0);
        }
        
        return $ret['cpanelresult']['result']['data'];
    }
            
    function getDatabaseConfiguration(){
        return $this->_callUAPI('ServerTasticSSL', 'getConfiguration');
    }    
    
    function getAccessHash(){
        return $this->_callUAPI('ServerTasticSSL', 'getAccessHash');
    }
    
    function getCurrentUser(){
        return $this->cpanel->cpanelprint('$user');
    }
    
    function getCurrentLang(){
        return $this->cpanel->cpanelprint('$lang');
    }
    
    function getFooter(){
        if($this->cpanel->cpanelprint('$theme') == 'paper_lantern')
        {
            return $this->cpanel->footer();
        }
    }
    
    function getHeader(){
        if($this->cpanel->cpanelprint('$theme') == 'paper_lantern')
        {
            return $this->cpanel->header("HTTPS Installer");
        }
    }
    
    function getDomainRelPatch($domain)
    {
        $result = $this->_userRequest($this->clientUsername,'DomainLookup', 'getdocroot', array('domain' => $domain));
        return $result['cpanelresult']['data'][0]['reldocroot'];
    }
        
    
    function getDomainFullpath( $domain )
    {
        $result = $this->_userRequest($this->clientUsername,'DomainLookup', 'getdocroot', array('domain' => $domain));
        return $result['cpanelresult']['data'][0]['docroot'];        
    }
    
    function putValidationFile($domain, $filename, $content)
    { 
        $domainPath = $this->getDomainRelPatch($domain);
        $this->_userRequest($this->clientUsername,'Fileman','savefile',array('dir' => $domainPath, 'filename' => $filename, 'content' => $content));
        $result = $this->_userRequest($this->clientUsername,'Fileman','viewfile',array('dir' => $domainPath, 'file' => $filename));
        if(!(isset($result['cpanelresult']['data'][0]['contents']) && $result['cpanelresult']['data'][0]['contents'] == $content))
        {
            throw new SystemException('API ERROR',0,'cpanelError',array('Unable to upload csr hash file for the domain: '.$domain.'.'));
        }
    }

    function generateCsr($params = null)
    {
        $generateKeyResult = $this->_callUAPI('SSL', 'generate_key', array('keysize' => '2048'));

        $generateCrtResult = $this->_callUAPI('SSL', 'generate_cert', array(
                'key_id'                  => $generateKeyResult['id'],
                'domains'                 => $params['domain'],
                'countryName'             => $params['country'],
                'stateOrProvinceName'     => mb_convert_encoding($params['state'], "UTF-8"),
                'localityName'            => mb_convert_encoding($params['city'], "UTF-8"),
                'organizationName'        => mb_convert_encoding($params['company'], "UTF-8"),
                'emailAddress'            => $params['email'],
            )
        );

        $generateCsrResult = $this->_callUAPI('SSL', 'generate_csr', array(
                'key_id'                  => $generateKeyResult['id'],
                'domains'                 => $params['domain'],
                'countryName'             => $params['country'],
                'stateOrProvinceName'     => mb_convert_encoding($params['state'], "UTF-8"),
                'localityName'            => mb_convert_encoding($params['city'], "UTF-8"),
                'organizationName'        => mb_convert_encoding($params['company'], "UTF-8"),
                'emailAddress'            => $params['email'],
            )
        );
    
        return array(
            'csr' => $generateCsrResult['text'],
            'key' => $generateKeyResult['text'],
            'crt' => $generateCrtResult['text']
        );
    }
    
    function getUserDomains($user = null, $main = null) {
        return parent::getUserDomains($this->clientUsername, $main);
    }
    
    function getMainDomain($user = null) {
        return parent::getMainDomain($this->clientUsername);
    }
    
    function getUserCerts($user = null){
        $output = $this->_callUAPI('SSL', 'list_certs');
        return $output;
    }
    
    function getUserCert($user = null, $certID = null){
        $output = $this->_callUAPI('SSL', 'show_cert',array(
            'id'    => $certID
        ));
        return $output;
    }
    
    function getAccounts() {
        return array();
    }

    public function addZoneRecord($domain, $name, $value, $type = 'CNAME', $class = 'IN', $ttl = 86400){
        $ext = array(
            'domain'  => $domain,
            'name'    => $name,
            'class'   => $class,
            'ttl'     => $ttl,
            'type'    => $type,
            'txtdata' => $value
        );

        $output = $this->_request('addzonerecord', $ext);

        return $output;
    }

    public function removeSSL($domain, $user = null){

        $result = $this->_callUAPI('SSL', 'delete_ssl', array(
                'domain'                  => $domain
            )
        );
        
        return $result;
    }
}

 
