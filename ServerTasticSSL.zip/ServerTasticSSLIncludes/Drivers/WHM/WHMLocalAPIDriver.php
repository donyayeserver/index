<?php

class WHMLocalAPIDriver extends AbstractLocalAPIDriver{
    protected $apiKey;
    private $sortCol        = 'domain';
    private $sortVect       = 'ASC';
    public $currentUsername = false;
    public $currentDomain   = false;
    public $lastParams      = array();
    public $typeList        = array('base','addon','parked');
        
    function __construct($params) {
        parent::__construct($params);
    }
 
    public function _connect($params){
        $accesKeyFile = '/root/.ext_tokenapi';

        if(!file_exists($accesKeyFile))
        {
            throw new SystemException("Can't find Token Api File",14041);
        }
        
        $handle = fopen($accesKeyFile,'r');
        $content = explode("\n", fread($handle, 1024));
        $this->apiKey = $this->getToken($content);

        if(empty($this->apiKey))
        {
            throw new SystemException("Can't get API Token",14041);
        }
    }
    
    protected function getToken($fileContent) 
    {
        foreach($fileContent as $line) {
            if(strpos($line, "token") !== false) {
                $token = substr($line, strpos($line, "token") + 7);
                return $token;
            }
        }
        
        return "";
    }

    public function _request($function,array $params = array()){
        $ch = curl_init();
        
        $this->lastParams = $params;
       
        curl_setopt($ch, CURLOPT_URL, "http://127.0.0.1:2086/json-api/".$function.'?'.http_build_query($params));

        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $header[0] = "Authorization: WHM root:" . $this->apiKey;
        # Remove newlines from the hash
        curl_setopt($ch,CURLOPT_HTTPHEADER,$header);

        curl_setopt($ch, CURLOPT_TIMEOUT, 400);
        $data = curl_exec($ch);

        curl_close($ch);
        
        $response = json_decode($data,TRUE);
                        
        return $response;
    }
    
    protected function _userRequest($user,$module,$function,$params = array())
    {
        $params['cpanel_jsonapi_user']     = $user;
        $params['cpanel_jsonapi_module']   = $module;
        $params['cpanel_jsonapi_func']     = $function;
  
        $response = $this->_request('cpanel', $params);
        if(!empty($response['error'])){
            throw new SystemException($response['error'],0,'cpanelError',array('raw'=>$response,'last'=> $this->lastParams));
        }
        
        if(!empty($response['cpanelresult']['error']))
        {
            throw new SystemException($response['cpanelresult']['error'],0,'cpanelError',array('raw'=>$response,'last'=> $this->lastParams));
        }
        
        if(isset($response['cpanelresult']['postevent']))
        {
            if($response['cpanelresult']['postevent']['result'] != 1)
            {
                throw new SystemException('API ERROR',$response['cpanelresult']['postevent']['result'],'cpanelError',array('raw'=>$response,'last'=> $this->lastParams));
            }
        }
        else
        {
            if(isset($response['cpanelresult']['event']['result']) != 1)
            {
                throw new SystemException('API ERROR',$response['cpanelresult']['event']['result'],'cpanelError',array('raw'=>$response,'last'=> $this->lastParams));
            }
        }

        return $response;
    }
    
    function getDomainsList(){
       $myfile = fopen("/etc/userdatadomains.json", "r");
       $data   = fread($myfile,filesize("/etc/userdatadomains.json"));
       fclose($myfile);
       return $data;
    }
    
    function getMainDomain($account){
        $main = $this->_userRequest($account, 'DomainLookup', 'getmaindomain');
        return $main['cpanelresult']['data'][0]['main_domain'];
    }
       
    public function installCrt($account,$params)
    { 
        $result = $this->_userRequest($account,'SSL','installssl',$params); 
        return $result;
    }
    
    public function getAccounts(){
          $accounts = $this->_request('listaccts');
          $output = array();
          foreach ($accounts['acct'] as $account)
          {
              $output[] = array(
                  'name'        => $account['user']
                  ,'locked'     => $account['is_locked']
                  ,'mainDomain' => $account['domain']
                  ,'email'      => $account['email']
              );
          }
          return $output;
    }
    
    function getUserDomains($user = null, $main = null)
    {
        $domainsList = array();

        if($main == null)
        {
            $main = $this->getMainDomain($user);
        }

        $domainsList[] = array(
                    'domain'    => $main
                    ,'user'     => $user
                    ,'type'     => 'base'
                    ,'root'     => $main
        );
        
        
        //get addon domain
        $addons = $this->_userRequest($user, 'AddonDomain', 'listaddondomains');
        if(!empty($addons['cpanelresult']['data']) && is_array($addons['cpanelresult']['data']))
        {
            foreach($addons['cpanelresult']['data'] as $addonDomain)
            {
                $domainsList[] = array(
                                'domain'    => $addonDomain['domain']
                                ,'user'     => $user
                                ,'type'     => 'addon'
                                ,'root'     => $addonDomain['rootdomain']
                );
            }
        }
        
        return $domainsList;
    }
    
    public function getDomainUserData($domain = "")
    {
        $response = $this->_request("domainuserdata", ["domain" => $domain, "version" => "1"]);
        
        if($response['result'][0]['status'])
        {
            return $response['userdata'];
        }
        
        throw new \Exception($response['result'][0]['statusmsg']);
    }
    
    public function getAccountSummary($domain = "")
    {
        $response = $this->_request("accountsummary", ["domain" => $domain, "version" => "1"]);

        if($response['status'])
        {
            return $response['acct'];
        }
        
        throw new \Exception($response['statusmsg']);
    }
    
    public function removeSSL($domain, $user){

        $params['cpanel_jsonapi_user']      = $user;
        $params['cpanel_jsonapi_module']    = 'SSL';
        $params['cpanel_jsonapi_func']      = 'delete_ssl';
        $params['cpanel_jsonapi_apiversion']= '3';
        $params['domain']= $domain;

        $response = $this->_request('cpanel', $params);
        
        if(!empty($response['result']['errors'])){
            throw new Exception($response['result']['errors'][0]);
        }


        return $response['result'];
    }
}