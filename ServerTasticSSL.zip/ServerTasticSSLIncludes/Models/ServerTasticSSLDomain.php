<?php

class ServerTasticSSLDomain extends abstractModel{
    public $domain;
    public $domainId;
    public $type;

    public function __construct($domain,$domainId = null, $data = array()) {
        $this->domain   = $domain;
        $this->domainId = $domainId;
    }
}
