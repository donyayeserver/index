<?php

class ServerTasticSSLProducts extends abstractModel{

    private $products = null;

    public function getProducts(){

        if(!$this->products){
            $ServerTasticSSLApi = new ServerTasticSSLAPI();
            
            $params = array('product_group'=>'SSL');
            $result = $ServerTasticSSLApi->get('/ssl/product/listproducts', $params);
            $this->products = $result;
        }

        return $this->products;
    }

    public function isError(){
        return !($this->products && $this->products->success);
    }
}
