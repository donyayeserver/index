<?php

class ServerTasticSSLCertificate extends abstractModel
{
    public $account;
    public $userId;
    public $domain;
    public $domainId;

    public $st_product_code;
    public $end_customer_email;
    public $reseller_unique_reference;

    public $csr;
    public $key;
    public $crt;

    public $certOrgContacts;
    public $certAdminContacts;
    public $certTechContacts;

    public $reseller_order_id;
    public $orderToken;
    public $approverEmail;
    public $reissueEmail;

    public $errors = array();

    public $dns;
    public $file;

    public $certificate;
    public $ca_certificate;

    public $data;

    public $pkcs7;


    public function __construct($params = null)
    {
        if (!empty($params)) {
            foreach ($params as $propertyName => $propertyValue) {
                if (property_exists($this, $propertyName)) {
                    $this->{$propertyName} = $propertyValue;
                }
            }
        }
    }

    public function getApproverList()
    {
        $result = array();
        $approvalList = ServerTasticSSLDriver::remoteAPI()->get('/order/approverlist', array('domain_name' => 'google.com'));
        if ($approvalList && $approvalList->success && $approvalList->approver_email) {
            foreach ($approvalList->approver_email as $app) {
                $result[$app->email] = $app->email;
            }
        }
        return $result;
    }

    public function generateCSR()
    {
        $params['domain'] = $this->domain;
        $params['country'] = $this->certAdminContacts['admin_contact_address_country'];
        $params['state'] = $this->certAdminContacts['admin_contact_address_region'];
        $params['city'] = $this->certAdminContacts['admin_contact_address_city'];
        $params['company'] = $this->certAdminContacts['admin_contact_organisation_name'];
        $params['email'] = $this->certAdminContacts['admin_contact_email'];

        $genResult = ServerTasticSSLDriver::localAPI()->generateCsr($params);

        $this->csr = $genResult['csr'];
        $this->key = $genResult['key'];
        $this->crt = $genResult['crt'];


    }

    protected function getCertificateVerificationMethod()
    {
        $type = ServerTasticSSLDriver::config()->verification_method;
        if (method_exists($this, 'generate' . strtoupper($type))) {
            return strtoupper($type);
        } elseif (method_exists($this, 'generate' . ucfirst($type))) {
            return ucfirst($type);
        }

        return 'DNS';
    }


    protected function getCertifacateMethod($mehthod, $type)
    {
        return $mehthod . $type;
    }


    public function proceed($action)
    {
        $method = $this->getCertifacateMethod($action, $this->getCertificateVerificationMethod());
        if (method_exists($this, $method)) {
            $this->$method();
        }
    }


    public function generateDNS()
    {

        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->post('/order/generatedns', array('csr' => $this->csr));
        if (isset($request->error)) {
            $errorMessage = 'Error';
            if (isset($request->error->message)) {
                $errorMessage = $request->error->message;
            }

            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Generate DNS - ' . $errorMessage, 0, '', '', null, $requ, $resp);

        }

        return $this->dns = $request;
    }


    #added by Vitalii Aloksa
    public function generateFile()
    {
        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->post('/order/generatefile', array('csr' => $this->csr));

        if (isset($request->error)) {
            $errorMessage = 'Error';
            if (isset($request->error->message)) {
                $errorMessage = $request->error->message;
            }

            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Generate File  - ' . $errorMessage, 0, '', '', null, $requ, $resp);

        }

        return $this->file = $request;
    }

    public function installDNS()
    {
        if (!$this->dns) {
            return false;
        }

        $name = ($this->dns->CNAME) ? $this->dns->CNAME . '.' : 'cert.' . $this->domain;
        $value = ($this->dns->CNAME) ? $this->dns->point_to : $this->dns->dv_auth_dns_string;
        $type = ($this->dns->CNAME) ? 'CNAME' : 'TXT';


        $result = ServerTasticSSLDriver::localAPI()->addZoneRecord(
            $this->domain,
            $name, # em, what should be te name?
            $value,
            $type
        );

        return $result;
    }


    public function createDirectoryIfNotExistis($domain, $direcroty)
    {
        $domainPath = ServerTasticSSLDriver::localAPI()->getDomainFullPath($domain);
        $peaces = explode('/', $direcroty);
        $directoryPath = $domainPath;

        foreach ($peaces as $element) {

            if (!empty($element)) {
                $directoryPath = $directoryPath . DIRECTORY_SEPARATOR . $element;
                if (!is_dir($directoryPath)) {
                    mkdir($directoryPath);
                }
            }
        }

        return $directoryPath;
    }


    public function installFile()
    {
        $filepath = $this->file->dv_auth_file_name;
        $pathinfo = pathinfo($filepath);
        $directoryPath = $this->createDirectoryIfNotExistis($this->domain, $pathinfo['dirname']);
        $result = file_put_contents($directoryPath.'/'.$pathinfo['filename'].'.'.$pathinfo['extension'], $this->file->dv_auth_file_contents);
 
        
        if ($result) {
            #some response
            return "success";
        }
    }

    public function getProductFields($orderToken, &$fields, &$contactFields, &$orgFields, &$infoFields)
    {
        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->get('/order/productfields', array('order_token' => $orderToken));

        if (isset($request->error)) {
            throw new Exception(MGLang::T('invalid_token'));
        }

        $fields = array();
        $contactFields = array('tech' => array(), 'admin' => array());
        $orgFields = array();
        $infoFields = array();

        if(empty($request)) {
            return false;
        }

        foreach ($request as $rawField) {
            if (is_object($rawField)) {
                foreach ($rawField as $fieldName => $field) {
                    $prefix = substr($fieldName, 0, strpos($fieldName, '_'));
                    if (in_array($prefix, array_keys($contactFields))) {
                        $contactFields[$prefix][$fieldName] = $field;
                    } elseif ($prefix == 'org') {
                        $orgFields[$fieldName] = $field;
                    } else {
                        $fields[$fieldName] = $field;
                    }
                }
            } elseif (is_string($rawField)) {
                $infoFields[] = $rawField;
            }
        }

        if(!$fields['approver_email_address']) {
            $fields['approver_email_address'] = (object)array(
                'required' => true,
            );
        }

        return true;
    }

    public function getApproverEmailList()
    {
        $approvers = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->get('/order/approverlist', array('domain_name' => $this->domain));

        if (isset($approvers->error)) {
            throw new Exception(MGLang::T('approver_error'));
        }
        $list = array();
        foreach ($approvers->approver_email as $email) {
            $list[] = $email->email;
        }

        return $list;
    }

    public function placeTokenCertRequest($data)
    {
        $data['csr'] = $this->csr;
        $data['dv_auth_method'] = $this->getCertificateVerificationMethod();

        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->post('/order/place', $data);

        if (isset($request->error)) 
        {
            throw new Exception($request->error->message);
        } 
        else 
        {
            if($data['dv_auth_method'] == 'FILE') 
            {
                $content = $request->file_contents;
                $this->file->dv_auth_file_contents = $content;
                if(isset($request->file_name)) 
                {
                    $filename = $request->file_name;
                } 
                elseif(isset($request->dv_auth_file_name)) {
                    $filename = $request->dv_auth_file_name;
                } 
                else 
                {
                    $filename = '/.well-known/pki-validation/fileauth.txt';
                }
                
                $this->file->dv_auth_file_name = $filename;
                $this->installFile();
            } 
            else 
            {
                $dns_string = $request->dns_string;
                $this->dns->CNAME = false;
                $this->dns->dv_auth_dns_string = $dns_string;
                $this->installDNS();
            }
            
            $task = new MGCronTask(array('_tableName' => 'ServerTasticSSL_cron_tasks'));
            $task->reseller_order_id = $request->reseller_order_id;
            $task->userId = $this->userId;
            $task->domainId = $this->domain;
            $task->activateDate = '0000-00-00 00:00:00';
            $data['type'] = 'token';
            $this->data = $data;
            $task->params = json_encode(get_object_vars($this));
            $r = $task->getTaskByDomainAndUser();
            if (!empty($r)) {
                $task->id = $r[0]['id'];
                $task->update();
            } else {
                $task->create();
            }
        }
    }

    public function placeTokenCertRequestCron($data)
    {
        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->get('/order/review', array('order_token' => $data['order_token']));
        if($request->order_status != 'Completed') {
            $errorMessage = $request->order_status;
            if(isset($request->error->message)){
                $errorMessage = $request->error->message;
            }
            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Cron Place Token Order - '.$errorMessage, 0, '', '', null, $requ, $resp);
        } else {
            $this->reseller_order_id = $request->reseller_order_id;
            $this->certificate = $request->certificate;

            $ca_certs = array();
            if(isset($request->ca_certs->certificate_info))
            {
                foreach($request->ca_certs->certificate_info as $cert) {
                    $ca_certs[] = $cert->certificate;
                }
            }
            else
            {
                foreach($request->ca_certs as $cert) {
                    $ca_certs[] = $cert->certificate;
                }
            }
            $this->ca_certificate = implode("\n", $ca_certs);
            $this->orderToken = $data['order_token'];

            $this->installCertificate();

            $certParams = array(
                '_tableName'        => 'ServerTasticSSL_orders',
                'reseller_order_id' => $request->reseller_order_id,
                'product_code'      => $request->st_product_code,
                'userId'            => $this->userId,
                'domainId'          => $this->domain,
                'orderVoucher'      => $this->orderToken,
                'csr'               => $this->csr,
                'key'               => $this->key,
                'crt'               => $this->crt,
                'expiry_date'       => $request->expiry_date,
                'filename'          => json_encode($data),
                'filecontent'       => isset($request->file_contents)?$request->file_contents:'',
                'dns_string'        => isset($request->dns_string)?$request->dns_string:'',
                'status'            => 'Installed'
            );

            $certificate = new MGCertOrders($certParams);
            $certificate->create();
            return;
        }
    }
    
    public function placeFreeCertRequest($isCron = false)
    {

        $body = array(
            'st_product_code'           => 'EESecureSiteStarter-12',
            'end_customer_email'        => $this->certAdminContacts['admin_contact_email'],
            'reseller_unique_reference' => substr( time() . md5( rand( 0, 1000 ) ), 0, 35 ),
            'csr'                       => $this->csr,
            'domain_name'               => $this->domain,
            'ee_type'                   => strtoupper( ServerTasticSSLDriver::config()->verification_method )
        );

        $body= array_merge(
            $body,
            $this->certTechContacts,
            $this->certAdminContacts);

        
        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->post('/order/placeee',$body);

        if(isset($request->error)){
            //add to cron
            $task = new MGCronTask(array('_tableName' => 'ServerTasticSSL_cron_tasks'));
            $task->reseller_order_id = '-';
            $task->userId = $this->userId;
            $task->domainId = $this->domain;
            $task->activateDate = '0000-00-00 00:00:00';
            $task->params = json_encode(get_object_vars($this));
            $r = $task->getTaskByDomainAndUser();
            if(!empty($r)){
                $task->id = $r[0]['id'];
                $task->update();
            }
            elseif(!$isCron ) {
                $task->create();
            }
            //cron end

            $errorMessage = 'Error';
            if(isset($request->error->message)){
                $errorMessage = $request->error->message;
            }
            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Place Order - '.$errorMessage, 0, '', '', null, $requ, $resp);
        }else{
            $this->reseller_order_id = $request->reseller_order_id;
            $this->certificate = $request->certificate;
            $this->ca_certificate = $request->intermediate;
            $this->orderToken = $request->order_token;

            $this->installCertificate();

            $certParams = array(
                '_tableName'        => 'ServerTasticSSL_orders',
                'reseller_order_id' => $request->reseller_order_id,
                'product_code'      => 'EESecureSiteStarter-12',
                'userId'            => $this->userId,
                'domainId'          => $this->domain,
                'orderVoucher'      => $this->orderToken,
                'csr'               => $this->csr,
                'key'               => $this->key,
                'crt'               => $this->crt,
                'expiry_date'       => date("Y-m-d H:i:s", strtotime("+1 month", time())),
                'filename'          => isset($request->file_name)?$request->file_name:'',
                'filecontent'       => isset($request->file_contents)?$request->file_contents:'',
                'dns_string'        => isset($request->dns_string)?$request->dns_string:'',
                'status'            => 'Installed'
            );

            $certificate = new MGCertOrders($certParams);
            $certificate->create();
        }
    }

    public function getOrderInformation()
    {
        $key = array('order_token' => $this->orderToken);

        $order = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->get('/order/review', $key);

        if(isset($order->error)){
            $errorMessage = 'Error';
            if(isset($order->error->message)){
                $errorMessage = $order->error->message;
            }
            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Get Information - '.$errorMessage, 0, '', '', null, $requ, $resp);
        }

        $this->st_product_code = $order->st_product_code;

        $this->certAdminContacts['admin_contact_first_name'] = $order->admin_contact->first_name;
        $this->certAdminContacts['admin_contact_last_name'] = $order->admin_contact->last_name;
        $this->certAdminContacts['admin_contact_phone'] = $order->admin_contact->phone;
        $this->certAdminContacts['admin_contact_email'] = $order->admin_contact->email;
        $this->certAdminContacts['admin_contact_title'] = $order->admin_contact->title;

        $this->certAdminContacts['tech_contact_first_name'] = $order->tech_contact->first_name;
        $this->certAdminContacts['tech_contact_last_name'] = $order->tech_contact->last_name;
        $this->certAdminContacts['tech_contact_phone'] = $order->tech_contact->phone;
        $this->certAdminContacts['tech_contact_email'] = $order->tech_contact->email;
        $this->certAdminContacts['tech_contact_title'] = $order->tech_contact->title;
        
        $this->certificate      = $order->certificate;
        $this->pkcs7            = $order->pkcs7;
        $this->end_customer_email = $order->end_customer_email;

        return $order;
    }

    public function cancelTokenCert()
    {
        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->post('/order/cancel', array('order_token' => $this->orderToken));

        if(isset($request->error)){
            $errorMessage = 'Error';
            if(isset($request->error->message)){
                $errorMessage = $request->error->message;
            }
            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Cancel Certificate - '.$errorMessage, 0, '', '', null, $requ, $resp);
        }
    }

    public function cancelCert(){

        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->post('/order/cancel', array('order_token' => $this->orderToken));
        if(isset($request->error)){
            $errorMessage = 'Error';
            if(isset($request->error->message)){
                $errorMessage = $request->error->message;
            }
            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Cancel Certificate - '.$errorMessage, 0, '', '', null, $requ, $resp);
        }

        return $this->dns = $request;
    }

    public function renewTokenCert($data)
    {
        if (is_object($data)) {
            $data = (array)$data;
        }

        $old_id = $this->reseller_order_id;

        $data['renewal'] = 1;

        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->post('/order/place', $data);

        if ($request->error) {
            $errorMessage = $request->error->message;
            
            if (isset($request->error->message)) 
            {
                $errorMessage = $request->error->message;
            }
            
            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Place Renew Order - ' . $errorMessage, 0, '', '', null, $requ, $resp);
        } 
        else 
        {
            $this->reseller_order_id = $request->reseller_order_id;

            $this->orderToken = $data['order_token'];

            $voucherParams = $this->getOrderInformation();

            $ca_certs = array();

            foreach ($voucherParams->ca_certs->certificate_info as $cert) 
            {
                $ca_certs[] = $cert->certificate;
            }
            
            $this->ca_certificate = implode("\n", $ca_certs);

            if (isset($voucherParams->success)) {
     
                $message = 'Domain: ' . $voucherParams->domain_name . "\n";
                $message .= 'User: ' . $this->userId . "\n";
                $message .= 'Certificate: ' . $request->st_product_code . "\n";
                $message .= 'Expiry Date: ' . $voucherParams->expiry_date;

                $notification = new MGNotification();
                
                if($this->certificate && $this->ca_certificate)
                {
                    $this->installCertificate();
                    $renewMessage = 'Certificate has been installed';
                    $notification->adminSummary($renewMessage, $message);
                }
                else
                {
                    $renewMessage = 'Certificate is awaiting for verification';
                    $notification->adminSummary($renewMessage, $message);
                }

                $certParams = array(
                    '_tableName' => 'ServerTasticSSL_orders',
                    'reseller_order_id' => $request->reseller_order_id,
                    'product_code' => $voucherParams->st_product_code,//$request->st_product_code,
                    'userId' => $this->userId,
                    'domainId' => $voucherParams->domain_name,
                    'orderVoucher' => $this->orderToken,//$voucherParams->order_token,
                    'csr' => $this->csr,
                    'key' => $this->key,
                    'crt' => $request->certificate,
                    'expiry_date' => $voucherParams->expiry_date,
                    'filename' => json_encode($data),
                    'filecontent' => isset($request->file_contents) ? $request->file_contents : null,
                    'dns_string' => isset($request->dns_string) ? $request->dns_string : null,
                    'status' => $voucherParams->order_status == 'Completed' ? 'Installed' : $voucherParams->order_status
                );

                $certificate = new MGCertOrders($certParams);
                $certificate->create();
                
                $certificate->reseller_order_id = $old_id;
                $certificate->delete();

            }
            
            return $renewMessage;
        }
    }
    
    public function renewCert()
    {
        $old_id = $this->reseller_order_id;

        $body = array(
            'st_product_code'           => 'EESecureSiteStarter-12',
            'end_customer_email'        => $this->certAdminContacts['admin_contact_email'],
            'reseller_unique_reference' => substr( time() . md5( rand( 0, 1000 ) ), 0, 35 ),
            'csr'                       => $this->csr,
            'renewal'                   => 1,
            'domain_name'               => $this->domain,
            'ee_type'                   => strtoupper( ServerTasticSSLDriver::config()->verification_method )
        );

        $body= array_merge(
            $body,
            (array)$this->certTechContacts,
            (array)$this->certAdminContacts);      
        $request = ServerTasticSSLDriver::remoteAPI()->setDomain($this->domain)->post('/order/place',$body);

        if($request->error){
            $errorMessage = 'Error';
            if(isset($request->error->message)){
                $errorMessage = $request->error->message;
            }
            $requ = ServerTasticSSLDriver::remoteAPI()->lastRequest;
            $resp = ServerTasticSSLDriver::remoteAPI()->lastResponse;
            throw new SystemException('Place Renew Order - '.$errorMessage, 0, '', '', null, $requ, $resp);
        }else{
            $this->reseller_order_id = $request->reseller_order_id;
            $this->ca_certificate    = $request->intermediate;

            $voucherParams = $this->getOrderInformation();

            if(isset($voucherParams->success))
            {     
                $message  = 'Domain: '.$voucherParams->domain_name."\n";
                $message .= 'User: '.$this->userId."\n";
                $message .= 'Certificate: EESecureSiteStarter-12'."\n";
                $message .= 'Expiry Date: '.$voucherParams->expiry_date;
                
                $notification = new MGNotification();
                
                if($this->certificate && $this->ca_certificate)
                {
                    $this->installCertificate();
                    $renewMessage = 'Certificate has been installed';
                    $notification->adminSummary($renewMessage, $message);
                }
                else
                {
                    $renewMessage = 'Certificate is awaiting for verification';
                    $notification->adminSummary($renewMessage, $message);
                }
                
                $certParams = array(
                    '_tableName'        => 'ServerTasticSSL_orders',
                    'reseller_order_id' => $request->reseller_order_id,
                    'product_code'      => 'EESecureSiteStarter-12',
                    'userId'            => $this->userId,
                    'domainId'          => $voucherParams->domain_name,
                    'orderVoucher'      => $voucherParams->order_token,
                    'csr'               => $this->csr,
                    'key'               => $this->key,
                    'crt'               => $request->certificate,
                    'expiry_date'       => $voucherParams->expiry_date,
                    'filename'          => isset($request->file_name)?$request->file_name:null,
                    'filecontent'       => isset($request->file_contents)?$request->file_contents:null,
                    'dns_string'        => isset($request->dns_string)?$request->dns_string:null,
                    'status'            => $voucherParams->order_status == 'Completed' ? 'Installed' : $voucherParams->order_status
                );

                $certificate = new MGCertOrders($certParams);
                $certificate->create();
                $certificate->reseller_order_id = $old_id;
                $certificate->delete();

            }
            
            return $renewMessage;
        }
    }

    public function removeCert($user)
    {
        if(!$this->domainId){
            throw new Exception('Wrong Domain');
        }

        $result = ServerTasticSSLDriver::localAPI()->removeSSL($this->domainId, $user);

        return $result;
    }

    public function installCertificate()
    {
        $installCrt = ServerTasticSSLDriver::localAPI()->installCrt($this->userId,array(
            'crt'=>$this->certificate,
            'cabundle'=>$this->ca_certificate,
            'key'=>$this->key,
            'domain'=>$this->domain));   
        $certificate = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders', 'status'=>'COMPLETED', 'reseller_order_id'=>$this->reseller_order_id));
        $certificate->updateStatus();

        return $installCrt;
    }

    public static function getCountries()
    {
        return array(
            'AF' => 'Afghanistan',
            'AX' => 'Aland Islands',
            'AL' => 'Albania',
            'DZ' => 'Algeria',
            'AS' => 'American Samoa',
            'AD' => 'Andorra',
            'AO' => 'Angola',
            'AI' => 'Anguilla',
            'AQ' => 'Antarctica',
            'AG' => 'Antigua And Barbuda',
            'AR' => 'Argentina',
            'AM' => 'Armenia',
            'AW' => 'Aruba',
            'AU' => 'Australia',
            'AT' => 'Austria',
            'AZ' => 'Azerbaijan',
            'BS' => 'Bahamas',
            'BH' => 'Bahrain',
            'BD' => 'Bangladesh',
            'BB' => 'Barbados',
            'BY' => 'Belarus',
            'BE' => 'Belgium',
            'BZ' => 'Belize',
            'BJ' => 'Benin',
            'BM' => 'Bermuda',
            'BT' => 'Bhutan',
            'BO' => 'Bolivia',
            'BA' => 'Bosnia And Herzegovina',
            'BW' => 'Botswana',
            'BV' => 'Bouvet Island',
            'BR' => 'Brazil',
            'IO' => 'British Indian Ocean Territory',
            'BN' => 'Brunei Darussalam',
            'BG' => 'Bulgaria',
            'BF' => 'Burkina Faso',
            'BI' => 'Burundi',
            'KH' => 'Cambodia',
            'CM' => 'Cameroon',
            'CA' => 'Canada',
            'CV' => 'Cape Verde',
            'KY' => 'Cayman Islands',
            'CF' => 'Central African Republic',
            'TD' => 'Chad',
            'CL' => 'Chile',
            'CN' => 'China',
            'CX' => 'Christmas Island',
            'CC' => 'Cocos (Keeling) Islands',
            'CO' => 'Colombia',
            'KM' => 'Comoros',
            'CG' => 'Congo',
            'CD' => 'Congo, Democratic Republic',
            'CK' => 'Cook Islands',
            'CR' => 'Costa Rica',
            'CI' => 'Cote D\'Ivoire',
            'HR' => 'Croatia',
            'CU' => 'Cuba',
            'CY' => 'Cyprus',
            'CZ' => 'Czech Republic',
            'DK' => 'Denmark',
            'DJ' => 'Djibouti',
            'DM' => 'Dominica',
            'DO' => 'Dominican Republic',
            'EC' => 'Ecuador',
            'EG' => 'Egypt',
            'SV' => 'El Salvador',
            'GQ' => 'Equatorial Guinea',
            'ER' => 'Eritrea',
            'EE' => 'Estonia',
            'ET' => 'Ethiopia',
            'FK' => 'Falkland Islands (Malvinas)',
            'FO' => 'Faroe Islands',
            'FJ' => 'Fiji',
            'FI' => 'Finland',
            'FR' => 'France',
            'GF' => 'French Guiana',
            'PF' => 'French Polynesia',
            'TF' => 'French Southern Territories',
            'GA' => 'Gabon',
            'GM' => 'Gambia',
            'GE' => 'Georgia',
            'DE' => 'Germany',
            'GH' => 'Ghana',
            'GI' => 'Gibraltar',
            'GR' => 'Greece',
            'GL' => 'Greenland',
            'GD' => 'Grenada',
            'GP' => 'Guadeloupe',
            'GU' => 'Guam',
            'GT' => 'Guatemala',
            'GG' => 'Guernsey',
            'GN' => 'Guinea',
            'GW' => 'Guinea-Bissau',
            'GY' => 'Guyana',
            'HT' => 'Haiti',
            'HM' => 'Heard Island & Mcdonald Islands',
            'VA' => 'Holy See (Vatican City State)',
            'HN' => 'Honduras',
            'HK' => 'Hong Kong',
            'HU' => 'Hungary',
            'IS' => 'Iceland',
            'IN' => 'India',
            'ID' => 'Indonesia',
            'IR' => 'Iran, Islamic Republic Of',
            'IQ' => 'Iraq',
            'IE' => 'Ireland',
            'IM' => 'Isle Of Man',
            'IL' => 'Israel',
            'IT' => 'Italy',
            'JM' => 'Jamaica',
            'JP' => 'Japan',
            'JE' => 'Jersey',
            'JO' => 'Jordan',
            'KZ' => 'Kazakhstan',
            'KE' => 'Kenya',
            'KI' => 'Kiribati',
            'KR' => 'Korea',
            'KW' => 'Kuwait',
            'KG' => 'Kyrgyzstan',
            'LA' => 'Lao People\'s Democratic Republic',
            'LV' => 'Latvia',
            'LB' => 'Lebanon',
            'LS' => 'Lesotho',
            'LR' => 'Liberia',
            'LY' => 'Libyan Arab Jamahiriya',
            'LI' => 'Liechtenstein',
            'LT' => 'Lithuania',
            'LU' => 'Luxembourg',
            'MO' => 'Macao',
            'MK' => 'Macedonia',
            'MG' => 'Madagascar',
            'MW' => 'Malawi',
            'MY' => 'Malaysia',
            'MV' => 'Maldives',
            'ML' => 'Mali',
            'MT' => 'Malta',
            'MH' => 'Marshall Islands',
            'MQ' => 'Martinique',
            'MR' => 'Mauritania',
            'MU' => 'Mauritius',
            'YT' => 'Mayotte',
            'MX' => 'Mexico',
            'FM' => 'Micronesia, Federated States Of',
            'MD' => 'Moldova',
            'MC' => 'Monaco',
            'MN' => 'Mongolia',
            'ME' => 'Montenegro',
            'MS' => 'Montserrat',
            'MA' => 'Morocco',
            'MZ' => 'Mozambique',
            'MM' => 'Myanmar',
            'NA' => 'Namibia',
            'NR' => 'Nauru',
            'NP' => 'Nepal',
            'NL' => 'Netherlands',
            'AN' => 'Netherlands Antilles',
            'NC' => 'New Caledonia',
            'NZ' => 'New Zealand',
            'NI' => 'Nicaragua',
            'NE' => 'Niger',
            'NG' => 'Nigeria',
            'NU' => 'Niue',
            'NF' => 'Norfolk Island',
            'MP' => 'Northern Mariana Islands',
            'NO' => 'Norway',
            'OM' => 'Oman',
            'PK' => 'Pakistan',
            'PW' => 'Palau',
            'PS' => 'Palestinian Territory, Occupied',
            'PA' => 'Panama',
            'PG' => 'Papua New Guinea',
            'PY' => 'Paraguay',
            'PE' => 'Peru',
            'PH' => 'Philippines',
            'PN' => 'Pitcairn',
            'PL' => 'Poland',
            'PT' => 'Portugal',
            'PR' => 'Puerto Rico',
            'QA' => 'Qatar',
            'RE' => 'Reunion',
            'RO' => 'Romania',
            'RU' => 'Russian Federation',
            'RW' => 'Rwanda',
            'BL' => 'Saint Barthelemy',
            'SH' => 'Saint Helena',
            'KN' => 'Saint Kitts And Nevis',
            'LC' => 'Saint Lucia',
            'MF' => 'Saint Martin',
            'PM' => 'Saint Pierre And Miquelon',
            'VC' => 'Saint Vincent And Grenadines',
            'WS' => 'Samoa',
            'SM' => 'San Marino',
            'ST' => 'Sao Tome And Principe',
            'SA' => 'Saudi Arabia',
            'SN' => 'Senegal',
            'RS' => 'Serbia',
            'SC' => 'Seychelles',
            'SL' => 'Sierra Leone',
            'SG' => 'Singapore',
            'SK' => 'Slovakia',
            'SI' => 'Slovenia',
            'SB' => 'Solomon Islands',
            'SO' => 'Somalia',
            'ZA' => 'South Africa',
            'GS' => 'South Georgia And Sandwich Isl.',
            'ES' => 'Spain',
            'LK' => 'Sri Lanka',
            'SD' => 'Sudan',
            'SR' => 'Suriname',
            'SJ' => 'Svalbard And Jan Mayen',
            'SZ' => 'Swaziland',
            'SE' => 'Sweden',
            'CH' => 'Switzerland',
            'SY' => 'Syrian Arab Republic',
            'TW' => 'Taiwan',
            'TJ' => 'Tajikistan',
            'TZ' => 'Tanzania',
            'TH' => 'Thailand',
            'TL' => 'Timor-Leste',
            'TG' => 'Togo',
            'TK' => 'Tokelau',
            'TO' => 'Tonga',
            'TT' => 'Trinidad And Tobago',
            'TN' => 'Tunisia',
            'TR' => 'Turkey',
            'TM' => 'Turkmenistan',
            'TC' => 'Turks And Caicos Islands',
            'TV' => 'Tuvalu',
            'UG' => 'Uganda',
            'UA' => 'Ukraine',
            'AE' => 'United Arab Emirates',
            'GB' => 'United Kingdom',
            'US' => 'United States',
            'UM' => 'United States Outlying Islands',
            'UY' => 'Uruguay',
            'UZ' => 'Uzbekistan',
            'VU' => 'Vanuatu',
            'VE' => 'Venezuela',
            'VN' => 'Viet Nam',
            'VG' => 'Virgin Islands, British',
            'VI' => 'Virgin Islands, U.S.',
            'WF' => 'Wallis And Futuna',
            'EH' => 'Western Sahara',
            'YE' => 'Yemen',
            'ZM' => 'Zambia',
            'ZW' => 'Zimbabwe',
        );

    }

    public function parseContacts()
    {
        $errors = array();

        $requireFields = array(
            'contact_first_name',
            'contact_last_name',
            'contact_phone',
            'contact_email',
            'contact_title',
            'contact_organisation_name',
        );


        if(!empty($this->certOrgContacts))
        foreach ($requireFields as  $fieldName)
        {
            if(empty($this->certOrgContacts['org_'.$fieldName]))
            {
                $errors['cert_org_'.$fieldName] = true;
            }
            if(! empty($this->certOrgContacts['org_contact_email'])
                && !filter_var($this->certOrgContacts['org_contact_email'], FILTER_VALIDATE_EMAIL))
            {
                $errors['cert_org_contact_email'] = true;
            }
        }



        $requireFields = array(
            'contact_first_name',
            'contact_last_name',
            'contact_phone',
            'contact_email',
            'contact_title',
            'contact_organisation_name',
            'contact_address_city',
            'contact_address_region',
        );
        if(!empty($this->certAdminContacts))
        foreach ($requireFields as $fieldName)
        {
            if(empty($this->certAdminContacts['admin_'.$fieldName]))
            {
                $errors['cert_admin_'.$fieldName] = true;
            }
            if(!empty($this->certAdminContacts['admin_contact_email'])
                && !filter_var($this->certAdminContacts['admin_contact_email'], FILTER_VALIDATE_EMAIL))
            {
                $errors['cert_admin_contact_email'] = true;
            }
        }


        $requireFields = array(
            'contact_first_name',
            'contact_last_name',
            'contact_phone',
            'contact_email',
        );
        if(!empty($this->certTechContacts))
        foreach ($requireFields as $fieldName)
        {
            if(empty($this->certTechContacts['tech_'.$fieldName]))
            {
                $errors['cert_tech_'.$fieldName] = true;
            }
            if(!empty($this->certTechContacts['tech_contact_email'])
            && !filter_var($this->certTechContacts['tech_contact_email'], FILTER_VALIDATE_EMAIL))
            {
                $errors['cert_tech_contact_email'] = true;
            }
        }


        return $errors;
    }


}
