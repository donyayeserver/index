<?php

class ServerTasticSSLAccount extends abstractModel{
    public $name;
    public $nameID;
    public $mainDomain;
    private $domains = array();
    private $certs = array();

    public function __construct($name= null,$nameid = null, $data = array()) {
        $this->name = $name;
        $this->nameID = $nameid;
    }

    public function getDomains(){
        if(empty($this->domains))
        {
            foreach(ServerTasticSSLDriver::localAPI()->getUserDomains(null, null, $this->nameID) as $domain)
            {
                if(isset($domain['domainId'])){
                    $this->domains[] = new ServerTasticSSLDomain($domain['domain'],$domain['domainId']);
                }else{
                    $this->domains[] = new ServerTasticSSLDomain($domain['domain']);
                }

            }
        }
        return $this->domains;
    }

    public function getCerts(){
        if(empty($this->certs))
        {
            $domains = ServerTasticSSLDriver::localAPI()->getUserDomains($this->name);
            $certs = ServerTasticSSLDriver::localAPI()->getUserCerts($this->name);

            $certOrder = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders'));
            $certOrder->userId  = $this->nameID;
            $vouchersList = $certOrder->getUserVouchers();
            $certList = array();
            $task = new MGCronTask(array('_tableName' => 'ServerTasticSSL_cron_tasks', 'userId' => $this->nameID));

            $certsDomains = array();
            foreach($certs as $cert){
                $certsDomains = array_merge($certsDomains, $cert['domains']);
            }

            foreach($domains as $domain){
                $task->domainId=  $domain['domain'];
                $info = $task->getSingleTaskStatusByDomainAndUser();
                $cert = array(
                    'reseller_order_id'=>'',
                    'domainId'=>$domain['domain'],
                    'status'=> $info['status'] == '' ? '-' : $info['status'],
                    'ssltype'=>'-',
                    'expiry_date'=>'-',
                    'actions'=>'');

                if(in_array($domain['domain'], $certsDomains)){
                    $cert['actions'] = 'ssl';
                }

                foreach($vouchersList as $voucher){
                    if($voucher['domainId'] == $domain['domain']){
                        $cert['reseller_order_id'] = $voucher['reseller_order_id'];
                        $cert['orderVoucher']   = $voucher['orderVoucher'];
                        $cert['status']  = $voucher['status'];
                        $cert['expiry_date']  = $voucher['expiry_date'];
                        $cert['ssltype'] = $voucher['product_code'];
                        $cert['actions'] = 'sslTastic';
                        break;
                    }
                }

                $certList[] = $cert;
            }

            $this->certs = $certList;
        }

        return $this->certs;
    }

    public function getAllDomainsAndCerts(){
        $domains = json_decode(ServerTasticSSLDriver::localAPI()->getDomainsList(), true);

        if(empty($domains))
        {
            return array();
        }
 
        $certOrder = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders'));
        $vouchersList = $certOrder->getAllCertsOrders();
        $certList = array();

        foreach($domains as $domain => $val){
            $cert = array(
                'reseller_order_id'=> '',
                'domainId'=>$domain,
                'status'=>'-',
                'ssltype'=>'-',
                'expiry_date'=>'-',
                'error'=>'',
                'actions'=>'');

            foreach($vouchersList as $voucher){
                if($voucher['domainId'] == $domain){

                    $cert['reseller_order_id'] = $voucher['reseller_order_id'];
                    $cert['status'] = $voucher['status'];
                    $cert['ssltype'] = $voucher['product_code'];
                    $cert['expiry_date'] = $voucher['expiry_date'];
                    $cert['actions'] = 'sslTastic';
                    break;
                }
            }

            //find error
            $errors = MGExceptionLogger::listErrorByDomain($domain, array(), 1);
            if(!empty($errors)){
                $cert['error'] = $domain;
            }

            $certList[] = $cert;
        }
        
        $this->certs = $certList;

        return $this->certs;
    }
}
