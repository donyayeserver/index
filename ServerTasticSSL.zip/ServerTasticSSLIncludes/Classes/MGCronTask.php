<?php

/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

class MGCronTask
{

    public $id;
    public $userId;
    public $reseller_order_id;
    public $domainId;
    public $createDate;
    public $activateDate;
    public $locked = 0;
    public $finished = 0;
    public $status = 'Not installed';
    public $params = '';
    private $_tableName;

    function __construct(array $params = array())
    {
        $this->load($params);

        if (empty($this->createDate)) {
            $this->createDate = date('Y-m-d H:i:s');
        }
    }

    function load(array $params)
    {
        foreach ($params as $propertyName => $propertyValue) {
            if (property_exists($this, $propertyName)) {
                $this->{$propertyName} = $propertyValue;
            }
        }
    }

    function create()
    {
        $toSave = clone $this;

        MGMySQL::insert($this->_tableName, array(
            'userId' => $toSave->userId
            , 'reseller_order_id' => $toSave->reseller_order_id
            , 'domainId' => $toSave->domainId
            , 'create_date' => $toSave->createDate
            , 'activate_date' => '0000-00-00 00:00:00' 
            , 'last_try_date' => $toSave->createDate
            , 'admin_failnotify_date' => '0000-00-00 00:00:00' 
            , 'locked' => $toSave->locked
            , 'finished' => $toSave->finished
            , 'status' => $toSave->status
            , 'params' => $toSave->params
        ));
    }

    function update()
    {
        $toSave = clone $this;

        MGMySQL::update($this->_tableName, array(
            'userId' => $toSave->userId
            , 'domainId' => $toSave->domainId
            , 'activate_date' => $toSave->activateDate
            , 'last_try_date' => date('Y-m-d H:i:s')
            , 'locked' => $toSave->locked
            , 'finished' => $toSave->finished
            , 'status' => $toSave->status
            , 'params' => $toSave->params
                ), array(
            'id' => $toSave->id
        ));
    }
    
    function updateAdminNotifyDate()
    {
        $toSave = clone $this;
        MGMySQL::update($this->_tableName, array('admin_failnotify_date' => date('Y-m-d H:i:s')), array('id' => $toSave->id));
        $this->updateLastTry();
    }
    
    function updateLastTry(){
        $toSave = clone $this;
        MGMySQL::update($this->_tableName, array('last_try_date' => date('Y-m-d H:i:s')), array('id' => $toSave->id));
    }

    function delete()
    {
        if (empty($this->id)) {
            return false;
        }

        MGMySQL::delete($this->_tableName, array(
            'id' => $this->id
        ));
    }
    
    function deleteByDomainID()
    {
        if (empty($this->domainId)) {
            return false;
        }
        
        MGMySQL::delete($this->_tableName, array(
            'domainId' => $this->domainId
        ));
    }

    function setFinished($status = null)
    {
        if($status){
            $this->status = $status;
        }
        $this->finished = 1;
        $this->update();
    }

    function lock()
    {
        $this->locked = 1;
        $this->update();
    }

    function unlock()
    {
        $this->locked = 0;
        $this->update();
    }
    
    function getAllTasks(){
        $q = MGMySQL::query("
            SELECT 
                * 
            FROM 
                ".$this->_tableName
        )->fetchAll();
       
        return $q; 
    }

    function getTask($id){
        $q = MGMySQL::query("
            SELECT 
                * 
            FROM 
                ".$this->_tableName. "
            WHERE
                id = ". $id
        )->fetch();

        $this->load($q);
        return $q;
    }


    /**
     * @return MGCronTask[]
     * @throws SystemException
     */
    public function getActiveTasks(){
        $q = MGMySQL::query("
            SELECT 
                * 
            FROM 
                ".$this->_tableName."
            WHERE `finished` <> 1"
        )->fetchAll();

        $ret = array();
        foreach($q as $t){
            $t['_tableName'] = $this->_tableName;
            $ret[] = new MGCronTask($t);
        }
        return $ret;
    }
    
    function getTaskByRessellerOrderId($orderId)
    {
        $q = MGMySQL::query("
            SELECT 
                *
            FROM 
                `".$this->_tableName."` 
            WHERE 
                `reseller_order_id` = '".$orderId."'
        ")->fetchAll();
        
        return $q;
    }

    function getTaskByDomainAndUser()
    {
        $q = MGMySQL::query("
            SELECT 
                *
            FROM 
                `".$this->_tableName."` 
            WHERE 
                `userId` = '".$this->userId."'
                AND `domainId` = '".$this->domainId."'
        ")->fetchAll();

        return $q;
    }
    
     function getSingleTaskStatusByDomainAndUser()
    {
        $q = MGMySQL::query("
            SELECT 
                status
            FROM 
                `".$this->_tableName."` 
            WHERE 
                `userId` = '".$this->userId."'
                AND `domainId` = '".$this->domainId."'
        ")->fetch();

        return $q;
    }
    

    function passDaysFromLastNotify($days)
    {
        $q = MGMySQL::query("
            SELECT 
                *
            FROM 
                `".$this->_tableName."` 
            WHERE 
                `admin_failnotify_date` <= DATE_ADD(CURDATE(), INTERVAL -".(int)$days." DAY)
            OR
                `admin_failnotify_date` = '0000-00-00 00:00:00'
            AND 
            `id` = '".$this->id."'
        ")->fetch();
        
        return $q;
    }
    
    function setTest($test){
        $toSave = clone $this;

        MGMySQL::insert($this->_tableName, array(
            'userId' => $test
            , 'reseller_order_id' => 'asdasdasd'//$toSave->orderVoucher
            , 'domainId' => $test//$toSave->domainId
            , 'create_date' => date('Y-m-d H:i:s')//$toSave->createDate
            , 'activate_date' => '0000-00-00 00:00:00' //$toSave->activateDate ////0000-00-00 00:00:00
            , 'last_try_date' => date('Y-m-d H:i:s')//$toSave->createDate
            , 'admin_failnotify_date' => '0000-00-00 00:00:00' //$toSave->activateDate ////0000-00-00 00:00:00
            , 'locked' => 0//$toSave->locked
            , 'finished' =>0 //$toSave->finished
            , 'params' =>'' //$toSave->params
        ));
    }

}
