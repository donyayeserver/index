<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

class MGCertOrders
{
    public $reseller_order_id;
    public $product_code;
    public $userId;
    public $domainId;
    public $orderVoucher;
    public $csr;
    public $key;
    public $crt;
    public $expiry_date;
    public $filename;
    public $filecontent;
    public $dns_string;
    public $status;
    public $createDate;
    private $_tableName = 'ServerTasticSSL_orders';

    public function __construct(array $params = array())
    {
        $this->load($params);

        if (empty($this->createDate)) {
            $this->createDate = date('Y-m-d H:i:s');
        }
    }

    public function load(array $params)
    {
        foreach ($params as $propertyName => $propertyValue) {
            if (property_exists($this, $propertyName)) {
                $this->{$propertyName} = $propertyValue;
            }
        }
    }
    
    function create()
    {
        $toSave = clone $this;

        $params = array(
            'reseller_order_id'    => $toSave->reseller_order_id,
            'product_code'         => $toSave->product_code,
            'userId'               => $toSave->userId,
            'domainId'             => $toSave->domainId,
            'orderVoucher'         => $toSave->orderVoucher,
            'csr'                  => $toSave->csr,
            'key'                  => $toSave->key,
            'crt'                  => $toSave->crt,
            'expiry_date'          => $toSave->expiry_date,
            'filename'             => $toSave->filename,
            'filecontent'          => $toSave->filecontent,
            'dns_string'           => $toSave->dns_string,
            'status'               => $toSave->status,
            'createDate'           => $toSave->createDate
        );

        MGMySQL::insert($this->_tableName, array_filter($params));
    }

    function update()
    {
        $toSave = clone $this;

        MGMySQL::update($this->_tableName, array(
            'reseller_order_id'    => $toSave->reseller_order_id,
            'product_code'         => $toSave->product_code,
            'userId'               => $toSave->userId,
            'domainId'             => $toSave->domainId,
            'orderVoucher'         => $toSave->orderVoucher,
            'csr'                  => $toSave->csr,
            'key'                  => $toSave->key,
            'crt'                  => $toSave->crt,
            'expiry_date'          => $toSave->expiry_date,
            'filename'             => $toSave->filename,
            'filecontent'          => $toSave->filecontent,
            'dns_string'           => $toSave->dns_string,
            'status'               => $toSave->status,
            'createDate'           => $toSave->createDate
                ), array(
            'reseller_order_id' => $toSave->reseller_order_id
        ));
    }
    
    function updateReissue()
    {
        $toSave = clone $this;

        MGMySQL::update($this->_tableName, array(
            'reseller_order_id'    => $toSave->reseller_order_id,
            'userId'               => $toSave->userId,
            'domainId'             => $toSave->domainId,
            'orderVoucher'         => $toSave->orderVoucher,
            'csr'                  => $toSave->csr,
            'key'                  => $toSave->key,
            ), array(
                'reseller_order_id' => $toSave->reseller_order_id
            )
        );
    }
    
    function updateCRT(){
        $toSave = clone $this;

        MGMySQL::update($this->_tableName, array(
            'crt'     => $toSave->crt,
            ), array(
                'reseller_order_id' => $toSave->reseller_order_id
            )
        );
    }
    
    function updateStatus()
    {
        $toSave = clone $this;

        MGMySQL::update($this->_tableName, array(
            'status'        => $toSave->status
                ), array(
            'reseller_order_id' => $toSave->reseller_order_id
        ));
        

    }

    function delete()
    {
        if (empty($this->reseller_order_id)) {
            return false;
        }

        MGMySQL::delete($this->_tableName, array(
            'reseller_order_id' => $this->reseller_order_id
        ));
    }
    
    function getCertOrderByResselerOrderId(){

        $q = MGMySQL::query("
            SELECT 
                *
            FROM
                `".$this->_tableName."`
            WHERE 
                `reseller_order_id` = '".$this->reseller_order_id."'
        ")->fetch();
        
        return $q;
    }
    
    function getAllCertsOrders()
    {
       $q = MGMySQL::query("
            SELECT 
                * 
            FROM 
                `".$this->_tableName."`
        ")->fetchAll();
       
        return $q; 
    }
    
 
    function getDomain()
    {
        
        $q = MGMySQL::query("
            SELECT 
                *
            FROM
                `".$this->_tableName."`
            WHERE 
                domainId = '".$this->domainId."'"
        )->fetchAll();
        
        return $q;
    }

    function getUserVouchers()
    {
        $vouchersList = array();
        
        $q = MGMySQL::query("
            SELECT 
                *
            FROM
                `".$this->_tableName."`
            WHERE 
                userId = '".$this->userId."'
            ORDER BY
                id ASC  
        ")->fetchAll();

        foreach($q as $r)
        {
            $vouchersList[] = array(
                'reseller_order_id' => $r['reseller_order_id']
                ,'product_code'     => $r['product_code']
                ,'userId'           => $r['userId']
                ,'domainId'         => $r['domainId']
                ,'orderVoucher'     => $r['orderVoucher']
                ,'expiry_date'      => $r['expiry_date']
                ,'createDate'       => $r['createDate']
                ,'status'           => $r['status']
            );  
        }
        return $vouchersList;
    }

    function getOrdersByDate($date){
        $vouchersList = array();

        $q = MGMySQL::query("
            SELECT 
                *
            FROM
                `".$this->_tableName."`
            WHERE 
                expiry_date <= '".$date."'
            ORDER BY
                id ASC  
        ")->fetchAll();

        foreach($q as $r)
        {
            $vouchersList[] = array(
            'reseller_order_id' => $r['reseller_order_id']
            ,'product_code'     => $r['product_code']
            ,'userId'           => $r['userId']
            ,'domainId'         => $r['domainId']
            ,'orderVoucher'     => $r['orderVoucher']
            ,'expiry_date'      => $r['expiry_date']
            ,'createDate'       => $r['createDate']
            ,'status'           => $r['status']
            ,'csr'              => $r['csr']
            ,'key'              => $r['key']
            );
        }
        return $vouchersList;
    }
}
