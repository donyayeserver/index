<?php


class ServerTasticSSLAPI
{
    private $apiUrl = 'https://api2.servertastic.com';
    private $apiTestUrl = 'https://test-api2.servertastic.com';
    private $testMode = 1;
    private $apiKey = '';

    public $curl;
    public $timeout = 10;
    public $lastRequest;
    public $lastRequestHeader;
    public $lastResponse;
    public $lastResponseHeader;
    public $domain;

    public function __construct()
    {
        $this->curl = curl_init();
        curl_setopt($this->curl, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($this->curl, CURLOPT_HEADER, true);
        curl_setopt($this->curl, CURLINFO_HEADER_OUT, true);

        $this->refreshCredentials();
    }

    public function refreshCredentials(){

        $this->testMode = ServerTasticSSLDriver::config()->testmode;
        $this->apiKey = trim(ServerTasticSSLDriver::config()->apikey);
    }

    public function __destruct()
    {
        curl_close($this->curl);
    }

    private function resetLastCall()
    {
        $this->lastRequest = false;
        $this->lastRequestHeader = false;
        $this->lastResponse = false;
        $this->lastResponseHeader = false;
    }

    public function getLastRequest()
    {
        return array(
            'header' => $this->lastRequestHeader,
            'content' => $this->lastRequest,
        );
    }

    public function getLastResponse()
    {
        return array(
            'header' => $this->lastResponseHeader,
            'content' => $this->lastResponse,
        );
    }
    
    public function setDomain($domain)
    {
        $this->domain = $domain;
        return $this;
    }

    public function get($endpoint, $request = array())
    {
        return $this->call($endpoint, 'GET', $request);
    }

    public function post($endpoint, $request = array())
    {
        return $this->call($endpoint, 'POST', $request);
    }

    /**
     * FUNCTION call
     * Connection function
     * @param    string $endpoint endpoint
     * @param    string $method HTTP request method (get/post/put/delete)
     * @param    string|array $request HTTP request body
     * @param    string $content_type HTTP request content type
     * @param    array $file file to sent (array from $_FILES)
     * @throws   Exception
     * @return   string
     */
    public function call($endpoint, $method = 'GET', $request = array(), $type = '.json')
    {
        $this->resetLastCall();

        $url = $this->testMode?$this->apiTestUrl:$this->apiUrl;
        $url .= $endpoint.$type;

        $headers = array();
        $this->lastRequest = print_r($request, true);

        if (is_array($request) && !empty($request) && $method == 'GET') 
        {
            $url .= '?'. http_build_query($request);
        }

        curl_setopt($this->curl, CURLOPT_URL, $url);
        curl_setopt($this->curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($this->curl, CURLOPT_TIMEOUT, 60);

        if($method == 'POST')
        {
            curl_setopt($this->curl, CURLOPT_POST, 1);
            curl_setopt($this->curl, CURLOPT_POSTFIELDS, http_build_query($request));
        }

        $rawResponse = curl_exec($this->curl);

        $ci = curl_getinfo($this->curl);

        $this->lastRequestHeader = $ci['request_header'];

        $headerSize = curl_getinfo($this->curl, CURLINFO_HEADER_SIZE);
        $header = substr($rawResponse, 0, $headerSize);
        $output = trim(substr($rawResponse, $headerSize));

        $this->lastResponse = $output;
        $this->lastResponseHeader = $header;

        // IF Logs On
        if (ServerTasticSSLDriver::config()->apilogsEnabled) {
            $requestContent = $this->lastRequestHeader . $this->lastRequest;
            $responseContent = $this->lastResponseHeader . $this->lastResponse;
            MGExceptionLogger::addLog(new SystemException('API LOG: '.$endpoint), $requestContent, $responseContent, $this->domain);
        }

        return $this->handleResponse();

    }

    private function handleResponse()
    {

        try {
            $headers = $this->parseHeaders($this->lastResponseHeader);
            if ($headers['Content-Type'] == 'application/xml') {
                return new SimpleXmlElement($this->lastResponse);
            }
            if($headers['Content-Type'] == 'application/json'){
                return json_decode($this->lastResponse);
            }
        } catch (Exception $e) {
            MGExceptionLogger::addLog($e->getMessage(), $this->lastRequest, $this->lastResponse);
            return false;
        }

        return $this->lastResponse;
    }

    private function parseHeaders($header)
    {
        $headers = array();
        foreach (explode("\r\n", $header) as $i => $line) {
            if ($line != "") {
                if ($i === 0) {
                    $headers['http_code'] = $line;
                } else {
                    if (strpos($line, ": ") !== false) {
                        list ($key, $value) = explode(': ', $line);
                        $headers[$key] = $value;
                    }
                }
            }
        }
        return $headers;
    }

}