<?php

class MGExceptionLogger{
    static public function addLog($ex, $request = '', $response = '', $domain = '')
    {
        $token = null;
        $code  = 0;
        $request = $request?$request:'';
        $response = $response?$response:'';

        if(is_a($ex, '\Exception') || is_subclass_of($ex, '\Exception'))
        {
            $message  = $ex->getMessage();
            $code     = $ex->getCode();
            $type     = get_class($ex);
            
            if(method_exists($ex, 'getToken'))
            {
                $token = $ex->getToken();
            }
        }
        elseif(is_string($ex))
        {
            $message  = $ex;
            $type     = 'string';
        }
        else
        {
            $message  = print_r($ex,true);
            $type     = 'other';
        }

        try{
            if(!empty($token)){
                MGMySQL::insert('ServerTasticSSL_error_logs', array(
                   'token'      => $token
                   ,'date'      => date('Y-m-d H:i:s')
                   ,'message'   => $message
                   ,'debug'     => print_r($ex,true)
                   ,'code'      => $code
                   ,'type'      => $type
                   ,'request'   => $request
                   ,'response'  => $response
                   ,'domain'    => $domain
                ));
            }
        } catch (\Exception $exDB) {
            openlog("CPanel", LOG_PID | LOG_PERROR, LOG_LOCAL0);
            syslog(LOG_ERR, $ex->getMessage().(($token)?" Token:".$token:''));
        }
    }
    
    static public function getErrorByToken($token = false)
    {
        $result = MGMySQL::select(array(
           'token'    
           ,'date'      
           ,'message'   
           ,'debug'     
           ,'code'
           ,'type'
           ,'request'
           ,'response'
        )
        ,'ServerTasticSSL_error_logs'
        ,array(
            'token' => $token
        ));
        
        if($result)
        {
            return $result->fetch();
        }
    }

    static public function listErrorByDomain($domain, $sortby = array(), $limit = null)
    {
        $result = MGMySQL::select(array(
            'token'
            ,'message'
            ,'date'
            ,'domain'
            )
            ,'ServerTasticSSL_error_logs'
            ,array(
                'domain' => $domain
            ),
            $sortby,
            $limit);

        $data = array();

        while($row = $result->fetch())
        {
            $data[] = $row;
        }

        return $data;
    }
    
    static public function listErrorTokens($sortby = array()){
        $result = MGMySQL::select(array(
           'token'    
            ,'message'
            ,'date'
            ,'domain'
        )
        ,'ServerTasticSSL_error_logs', array(), $sortby);
        
        $data = array();
        
        while($row = $result->fetch())
        {
            $data[] = $row;
        }
        
        return $data;
    }

    static public function cleanAllLogs()
    {
        MGMySQL::query("TRUNCATE TABLE ServerTasticSSL_error_logs");
    }
}
