<?php

class MGApiLogger{
    static function addLog($request,$response, $ex = null)
    {
        if(!empty($request) && !empty($response)){
            MGMySQL::insert('ServerTasticSSL_api_logs', array(
                'date'           => date('Y-m-d H:i:s')
            ,'request'       => $request
            ,'response'      => $response
            ,'module_error'  => $ex
            ));
        }

    }

    static function cleanAllLogs()
    {
        MGMySQL::query("TRUNCATE TABLE ServerTasticSSL_api_logs");
    }

    static function getErrorById($id)
    {
        $result = MGMySQL::select(array(
                'date'
            ,'request'
            ,'response'
            )
            ,'ServerTasticSSL_api_logs'
            ,array(
                'token' => $id
            ));

        if($result)
        {
            return $result->fetch();
        }
    }

    static function listErrorTokens($sortby = array(), $limit = null)
    {
        $result = MGMySQL::select(array(
                'id'
            ,'date'
            ,'request'
            ,'response'
            )
            ,'ServerTasticSSL_api_logs', array(), $sortby,$limit);

        $apiData = array();

        while($row = $result->fetch())
        {
            $apiData[] = $row;
        }
        return $apiData;
    }
}
