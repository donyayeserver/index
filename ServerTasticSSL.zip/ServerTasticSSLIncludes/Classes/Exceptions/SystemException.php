<?php

class SystemException extends Exception{
    private $userMessage;
    private $details;
    private $token;
    
    private $request;
    private $response;

    function __construct($message, $code = 0, $userMessage = '', $details = '',$previous = null, $request = null, $response = null) {

        $this->request = $request;
        $this->response = $response;

        parent::__construct($message, $code, $previous);
        $this->userMessage = $userMessage;
        $this->details = $details;
        $this->token = time().md5(rand(0,1000));
        }
    
    function getUserMessage(){
        return $this->userMessage;
    }
    
    function getDetails(){
        return $this->details;
    }
    
    function getToken(){
        return $this->token;
    }

    /**
     * @return null
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * @return null
     */
    public function getRequest()
    {
        return $this->request;
    }
}

