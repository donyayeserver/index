-- cPanelWHMFramework --
-- PLEASE DO NOT REMOVE THIS SQL COMMANDS --
-- REQUIRED FOR FRAMEWORK INTERNAL PROCESSES --

CREATE TABLE IF NOT EXISTS `ServerTasticSSL_configuration` (
  `name` varchar(40) NOT NULL,
  `value` text NULL,  
  PRIMARY KEY (name)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `ServerTasticSSL_error_logs` (
  `token` varchar(50) DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` varchar(360) NOT NULL,
  `debug` MEDIUMTEXT NOT NULL,
  `code` int(11) NOT NULL,
  `type` varchar(250) DEFAULT NULL,
  `request` text,
  `response` text,
  `domain` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- cPanelWHMFramework --

-- PLEASE INSERT BELOW YOUR CUSTOM SQL COMMANDS --

CREATE TABLE IF NOT EXISTS `ServerTasticSSL_cron_tasks` (
      `id` int NOT NULL AUTO_INCREMENT,
      `userId` varchar(40) DEFAULT NULL,
      `reseller_order_id` varchar(50) NOT NULL,
      `domainId` varchar(120) DEFAULT NULL,
      `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `activate_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `last_try_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `admin_failnotify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `locked` tinyint(1) NOT NULL DEFAULT 0,
      `finished` tinyint(1) NOT NULL DEFAULT 0,
      `status` varchar(40) DEFAULT NULL,
      `params` text DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `ServerTasticSSL_orders` (
      `id` int NOT NULL AUTO_INCREMENT,
      `reseller_order_id` varchar(50) NOT NULL,
      `product_code` varchar(50) NOT NULL,
      `userId` varchar(120) NOT NULL,
      `domainId` varchar(120) NOT NULL,
      `orderVoucher` varchar(60) NULL,
      `csr` text NOT NULL,
      `key` text NOT NULL,
      `crt` text DEFAULT NULL,
      `expiry_date` datetime NOT NULL,
      `filename` text DEFAULT NULL,
      `filecontent`  text DEFAULT NULL,
      `dns_string` text DEFAULT NULL,
      `status` varchar(50) NOT NULL,
      `createDate` datetime NOT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
