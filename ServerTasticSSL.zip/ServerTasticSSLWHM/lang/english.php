<?php

// MODULE LANGS! Do not remove/replace them
// Error Messages
$_LANG['errorMessages']['errorID'] = '. Error ID:';
$_LANG['Configuration']['errorMessages']['general'] = 'Something went wrong. Please check logs.';

//Container Lang
$_LANG['Container']['header'] = 'Servertastic SSL';
$_LANG['Container']['pages']['Configuration']   = 'Configuration';
$_LANG['Container']['pages']['CronTasks']       = 'Cron';
$_LANG['Container']['pages']['ErrorList']       = 'Logs';
$_LANG['Container']['pages']['SSLList']       = 'Domains';

//Configuration Responses
$_LANG['Configuration']['testSaveSuccess'] = 'Configuration has been saved and API connection works properly';
$_LANG['Configuration']['testSaveError'] = 'API connection is not working properly.';

//Configuration Page Form
$_LANG['Configuration']['sys']['header'] = 'Configuration';
$_LANG['Configuration']['sys']['apikey']['label'] = 'API Key';
$_LANG['Configuration']['sys']['testmode']['label'] = 'Test Mode';
$_LANG['Configuration']['sys']['apilogsEnabled']['label'] = 'API Logs';
$_LANG['Configuration']['sys']['apilogsLimit']['label'] = 'Activity Log Limit';
$_LANG['Configuration']['sys']['apilogsLimit']['description'] = 'The number of activity log entries you wish to keep';
$_LANG['Configuration']['sys']['submitTestSave']['label'] = 'Test And Save Configuration';
$_LANG['Configuration']['sys']['cronRetryLimit']['label'] = 'Cron Retry Limit';
$_LANG['Configuration']['sys']['admin_notifications_email']['label']    = 'Notifications Email';
$_LANG['Configuration']['sys']['autoRenewEnabled']['label'] = 'Auto Renew';
$_LANG['Configuration']['sys']['verification_method']['label'] = 'Verification Method';

//ErrorList Page
$_LANG['ErrorList']['errorList'] = 'Errors List';
$_LANG['ErrorList']['unableToFindError'] = 'Unable to find provided error';

// YOU CAN ADD YOUR LANGS BELOW:

$_LANG['SSLList']['thead']['domain'] = 'Domain';
$_LANG['SSLList']['thead']['status'] = 'Status';
$_LANG['SSLList']['thead']['ssltype'] = 'Certificate Type';
$_LANG['SSLList']['thead']['expiry_date'] = 'Expiration Date';
$_LANG['SSLList']['thead']['error'] = 'Error';
$_LANG['SSLList']['thead']['actions'] = 'Actions';
$_LANG['SSLList']['actions']['remove'] = 'Remove';
$_LANG['SSLList']['actions']['renew'] = 'Renew';
$_LANG['SSLList']['actions']['error'] = 'Error';

$_LANG['SSLList']['errorMessages']['general'] = 'Error';
