<?php

class WHMConfigurationController extends AbstractControler{
    public function __construct($params,$options) { 
        parent::__construct($params,$options);
    }

    public function MainHTMLAction($input,$data = array()) {

        $form = new FormCreator('sys',$this,array(
            'url'    => $this->getCurrentAction()
        ));

        $form->addField('Text', array(
            'name'   => 'apikey'
            ,'value' => isset($input['sys_apikey'])?$input['sys_apikey']: ServerTasticSSLDriver::config()->apikey
        ));

       $form->addField('CheckBox', array(
            'name'   => 'testmode'
           ,'value' => isset($input['sys_testmode'])?$input['sys_testmode']: ServerTasticSSLDriver::config()->testmode
       ));

        $form->addField('CheckBox', array(
            'name'   => 'apilogsEnabled'
        ,'value' => isset($input['sys_apilogsEnabled'])?$input['sys_apilogsEnabled']: ServerTasticSSLDriver::config()->apilogsEnabled
        ));

//        $form->addField('Text', array(
//            'name'   => 'apilogsLimit'
//        ,'value' => isset($input['sys_apilogsLimit'])?$input['sys_apilogsLimit']: ServerTasticSSLDriver::config()->apilogsLimit
//        ,'enableDescription'    => true
//        ));

        $form->addField('Text', array(
            'name'   => 'cronRetryLimit'
        ,'value' => isset($input['sys_cronRetryLimit'])?$input['sys_cronRetryLimit']: ServerTasticSSLDriver::config()->cronRetryLimit
        ,'enableDescription'    => false
        ));
        
        $form->addField('Text', array(
            'name'      => 'admin_notifications_email',
            'value'     => isset($input['sys_admin_notifications_email'])?$input['sys_admin_notifications_email']: ServerTasticSSLDriver::config()->admin_notifications_email
        ));
        
        #added by Vitalii Aloksa
        $form->addField( 'Select', array(
            'name'    => 'verification_method',
            'options' => array(
                array('value' => 'file', 'name' => 'File'),
                array('value' => 'dns', 'name' => 'DNS'),
            ),
            'value'   => isset( $input['sys_verification_method'] ) ? $input['sys_verification_method'] : ServerTasticSSLDriver::config()->verification_method
        ) );

        /*$form->addField('CheckBox', array(
            'name'  => 'autoRenewEnabled',
            'value' => isset($input['sys_autoRenewEnabled'])?$input['sys_autoRenewEnabled']: ServerTasticSSLDriver::config()->autoRenewEnabled
        ));*/

       $form->addField('Submit', array(
           'name'           => 'action'
           ,'value'         => 'testAndSave'
           ,'frendlyName'   => 'submitTestSave'
       ));
       
        $data['formAPI'] = $form->getHTML();
        
        return array(
            'template'   => 'Configuration'
            ,'vars'      => $data
        );
    }

    public function testAndSaveHTMLAction($input,$data = array()){

        if(empty($input['sys_testmode'])) $input['sys_testmode'] = 0;
        if(empty($input['sys_apilogsEnabled'])) $input['sys_apilogsEnabled'] = 0;
        if(!is_numeric($input['sys_cronRetryLimit']) || $input['sys_cronRetryLimit'] < 0) $input['sys_cronRetryLimit'] = 0;

        ServerTasticSSLDriver::config()->apikey = $input['sys_apikey'];
        ServerTasticSSLDriver::config()->testmode = $input['sys_testmode'];
        ServerTasticSSLDriver::config()->apilogsEnabled = $input['sys_apilogsEnabled'];
//        ServerTasticSSLDriver::config()->apilogsLimit = $input['sys_apilogsLimit'];
        ServerTasticSSLDriver::config()->cronRetryLimit   = $input['sys_cronRetryLimit'];
        ServerTasticSSLDriver::config()->admin_notifications_email      = $input['sys_admin_notifications_email'];
        ServerTasticSSLDriver::config()->autoRenewEnabled = $input['sys_autoRenewEnabled'];
        ServerTasticSSLDriver::config()->verification_method = $input['sys_verification_method'];
        

        ServerTasticSSLDriver::remoteAPI()->refreshCredentials();

        $products = new ServerTasticSSLCertificate();
        try{
            $result = $products->getApproverList();

            if(!$result){
                $data['error'] = MGLang::T('testSaveError');
            }
            else{
                $data['success'] = MGLang::T('testSaveSuccess');
            }
        }
        catch(SystemException $ex){
            $data['error'] = MGLang::T('testSaveError');
        }

        return $this->MainHTMLAction($input,$data);
    }
}