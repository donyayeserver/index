<?php

class WHMSSLListController extends AbstractControler
{

    public function MainHTMLAction($input, $vars = array()) {
        $account = new ServerTasticSSLAccount();

        $vars['certs'] = $account->getAllDomainsAndCerts();

        return array(
            'template'      => 'SSLList'
            ,'vars'         => $vars
        );
    }

    public function certRenewHTMLAction($input, $vars = array()) 
    {
        $certOrder = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders'));
        $vouchersList = $certOrder->domainId = $input['cert_domain'];
        $vouchersList = $certOrder->getDomain();

        if(empty($vouchersList))
        {
            $vars['error'] = 'Error with certificate renewal';
        }
        
        try{
            $certificate = new ServerTasticSSLCertificate();
            $certificate->reseller_order_id = $vouchersList[0]['reseller_order_id'];//$input['order_id'];
            $certificate->orderToken        = $vouchersList[0]['orderVoucher'];
            $certificate->csr               = $vouchersList[0]['csr'];
            $certificate->userId            = $vouchersList[0]['userId'];
            $certificate->key               = $vouchersList[0]['key']; 
            $certificate->domain            = $certOrder->domainId;

            $orderInfo =   $certificate->getOrderInformation();

            $userAccountData = ServerTasticSSLDriver::localAPI()->getAccountSummary($input['cert_domain']);

            $generateTokenData = [
                "st_product_code" => $orderInfo->st_product_code, 
                "reseller_unique_reference" => substr( time() . md5( rand( 0, 1000 ) ), 0, 35 ),
                "api_key" => trim(ServerTasticSSLDriver::config()->apikey),
                "end_customer_email" => $userAccountData[0]['email']
            ];

            $result = ServerTasticSSLDriver::remoteAPI()->get('/order/generatetoken', $generateTokenData);

            if (property_exists($result, "status") && $result->status == "ERROR")
            {
                throw new \Exception($result["response"]["message"]);
            }

            if ($result->success == "Order placed" || $result->success == "Invite sent") 
            {
                $orderToken = $result->order_token;
            }

            if(isset($vouchersList[0]['filename']) && ($data = json_decode($vouchersList[0]['filename']))) 
            {
                $data->order_token = $orderToken;
                $renewMessage = $certificate->renewTokenCert($data);
            } 
            else 
            {
                $certificate->orderToken = $orderToken;
                $renewMessage = $certificate->renewCert($vouchersList[0]['reseller_order_id']);
            }
            
            $vars['success'] = $renewMessage;
        }
        catch (Exception $ex) {
            $vars['errors'][] = 'ERROR: ' . $ex->getMessage();
        }

        return $this->MainHTMLAction($input, $vars);
    }

    public function certRemoveHTMLAction($input, $vars = array()) {

        $certificate = new ServerTasticSSLCertificate();

        try{
            $certOrder = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders'));
            $certOrder->reseller_order_id = $input['order_id'];
            $order = $certOrder->getCertOrderByResselerOrderId();

            $certificate->domainId = $input['cert_domain'];
            $certificate->removeCert($order['userId']);

            $certOrder->delete();

            $vars['success'] = 'Success';
        }
        catch (Exception $ex) {
            $vars['errors'][] = $ex->getMessage();
        }

        return $this->MainHTMLAction($input, $vars);
    }

}