<?php

class WHMErrorListController extends AbstractControler{
    
    public function MainHTMLAction($input, $vars = array()) {

        if(ServerTasticSSLDriver::config()->apilogsEnabled){
            $vars['logs_status_value'] = 'on';
        }else{
            $vars['logs_status_value'] = 'off';
        }
        $vars['logs_status'] = $vars['logs_status_value'];

        $vars['tokenList'] = array();
        foreach(MGExceptionLogger::listErrorTokens(array('date' => 'DESC')) as $error)
        {
            $error['message'] = (strlen($error['message'])>45)?(substr($error['message'], 0,45).'...'):$error['message'];
            $vars['tokenList'][] = $error;
        }

        return array(
            'template'      => 'ErrorList'
            ,'vars'         => $vars
        );
    }

    public function listByDomainHTMLAction($input, $vars = array()) {

        if(ServerTasticSSLDriver::config()->apilogsEnabled){
            $vars['logs_status_value'] = 'on';
        }else{
            $vars['logs_status_value'] = 'off';
        }
        $vars['logs_status'] = $vars['logs_status_value'];

        $vars['tokenList'] = array();
        foreach(MGExceptionLogger::listErrorByDomain($input['domain'],array('date' => 'DESC')) as $error)
        {
            $error['message'] = (strlen($error['message'])>45)?(substr($error['message'], 0,45).'...'):$error['message'];
            $vars['tokenList'][] = $error;
        }

        return array(
            'template'      => 'ErrorList'
            ,'vars'         => $vars
        );
    }
    
    public function SearchTokenHTMLAction($input, $vars = array()){
        
        $token = trim($input['tokenID']);

        $error = MGExceptionLogger::getErrorByToken($token);
        
        $vars['tokenID'] = $token;
        
        if($error)
        {
            if($error['request'] && $error['response']){
                unset($error['debug']);
            }
            $vars['showError'] = $error;
        }
        else
        {
            $vars['error'] = MGLang::T('unableToFindError');
        }

        return $this->MainHTMLAction($input, $vars);
    }

    public function clearHTMLAction($input, $vars = array()) {
        MGExceptionLogger::cleanAllLogs();
        $vars['success'] = 'All log entries deleted successfully';

        return $this->MainHTMLAction($input, $vars);
    }

    public function changeHTMLAction($input, $vars = array()) {
        if(ServerTasticSSLDriver::config()->apilogsEnabled){
            $vars['success'] = 'API Logs turned OFF';
            ServerTasticSSLDriver::config()->apilogsEnabled = 0;
        }else{
            $vars['success'] = 'API Logs turned ON';
            ServerTasticSSLDriver::config()->apilogsEnabled = 1;
        }

        return $this->MainHTMLAction($input, $vars);
    }
}