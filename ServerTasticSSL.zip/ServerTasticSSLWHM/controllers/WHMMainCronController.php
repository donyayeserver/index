<?php

class WHMMainCronController extends AbstractControler{
    public function MainHTMLAction()
    {
        return $this->recentlyCronAction();
    }
    
    public function installRenewedCertificatesCronAction()
    { 
        $cronTask = new MGCronTask(array('_tableName' => 'ServerTasticSSL_cron_tasks'));
        $tasks = $cronTask->getActiveTasks();
        
        $certOrders = new MGCertOrders(array('_tableName' => 'ServerTasticSSL_orders'));
        $allOrders = $certOrders->getAllCertsOrders();
        
        foreach($allOrders as $certOrder)
        {
            try
            {
                $certOrderInCronTask = false;
                
                foreach($tasks as $task)
                {
                    if($task->domainId == $certOrder['domainId'])
                    {
                        $certOrderInCronTask = true;
                    }
                }
                
                if($certOrderInCronTask)
                {
                    continue;
                }

                $uncheckedStatuses = ["Completed", "Cancelled"];
                if(in_array($certOrder['status'], $uncheckedStatuses))
                {
                    continue; 
                }

                $result = ServerTasticSSLDriver::remoteAPI()->get('/order/review', ['order_token' => $certOrder['orderVoucher']]);
               
                $update = [
                    "status" => $result->order_status,
                    "crt" => $result->certificate
                ];
                
                MGMySQL::update("ServerTasticSSL_orders", $update, ['reseller_order_id' => $certOrder['reseller_order_id']]);

                if($result->order_status == "Completed")
                {
                    if(isset($result->ca_certs->certificate_info))
                    {
                        foreach ($result->ca_certs->certificate_info as $cert) 
                        {
                            $ca_certs[] = $cert->certificate;
                        }                     
                    }
                    else
                    {
                        foreach($request->ca_certs as $cert) {
                            $ca_certs[] = $cert->certificate;
                        }
                    }
                    
                    $ca_certificate = implode("\n", $ca_certs);
                
                    $certificate = new ServerTasticSSLCertificate();
                    $certificate->reseller_order_id = $certOrder['reseller_order_id'];
                    $certificate->orderToken        = $certOrder['orderVoucher'];
                    $certificate->csr               = $certOrder['csr'];
                    $certificate->userId            = $certOrder['userId'];
                    $certificate->key               = $certOrder['key']; 
                    $certificate->domain            = $certOrder['domainId'];
                    $certificate->ca_certificate = $ca_certificate;
                    $certificate->certificate = $result->certificate;
                    $certificate->installCertificate();
                }
            }
            catch (\Exception $ex)
            {
                MGExceptionLogger::addLog($ex, $ex->getRequest(), $ex->getResponse(), $certOrder['domainId']);
            }
            catch (SystemException $ex)
            {
                MGExceptionLogger::addLog($ex, $ex->getRequest(), $ex->getResponse(), $certOrder['domainId']);
            }
        }
    }

    public function recentlyCronAction()
    {
        $retryLimit = ServerTasticSSLDriver::config()->cronRetryLimit;

        $cronTask = new MGCronTask(array('_tableName' => 'ServerTasticSSL_cron_tasks'));
        $tasks = $cronTask->getActiveTasks();

        foreach($tasks as $task){

            //only free ssl
            if(empty($task->params)){
                $task->setFinished('Error');
            }
            $task->updateLastTry();
            $params = json_decode($task->params, true);
            $certificate = new ServerTasticSSLCertificate($params);
            try{
                if(isset($certificate->data)) {
                    $certificate->placeTokenCertRequestCron($certificate->data);
                } else {
                    $certificate->placeFreeCertRequest(true);
                }
                $task->setFinished('Installed');
            }
            catch(SystemException $ex){
                MGExceptionLogger::addLog($ex, $ex->getRequest(), $ex->getResponse(), $params['domain']);
                $params['retryLimit'] = isset($params['retryLimit'])?$params['retryLimit']+1:1;

                $task->params = json_encode($params);
                $task->update();

                if($retryLimit > 0 && $params['retryLimit'] > $retryLimit){
                    $task->setFinished('Exceed retry limit');
                }
            }
        }

        var_dump('Complete');
    }

    public function dailyCronAction(){

        $autorenew = ServerTasticSSLDriver::config()->autoRenewEnabled;
        if($autorenew == 'on')
        {
            $orders = new MGCertOrders();
            $ord = $orders->getOrdersByDate(date("Y-m-d H:i:s", strtotime("+30 days")));
            foreach($ord as $o){
                $certificate = new ServerTasticSSLCertificate($o);
                try{
                    $certificate->getOrderInformation();
                    $certificate->csr = $o['csr'];
                    if(isset($o['filename']) && ($data = json_decode($o['filename']))) {
                        $certificate->renewTokenCert($data);
                    } else {
                        $certificate->renewCert();
                    }
                }
                catch(Exception $ex){
                    MGExceptionLogger::addLog($ex, '', '', $o['domainId']);
                }
            }
        }
        
        var_dump('Complete');

    }
}