<?php

class WHMCronTasksController extends AbstractControler
{
    public function MainHTMLAction($input, $vars = array()) {
        
        $data = array(); 
        $task = new MGCronTask(array('_tableName' => 'ServerTasticSSL_cron_tasks'));
        

        $userAccounts = ServerTasticSSLDriver::localAPI()->getAccounts();
        foreach($task->getAllTasks() as $cronTask){

            $userEmail = '';

            
            foreach($userAccounts as $userAccount){
                 
                if($userAccount['name'] ==  $cronTask['userId']){
                    $userEmail = $userAccount['email'];
                }
            }

            if($cronTask['status'] == 'Not installed'){
                $cronTask['activate_date'] = '';
            }

           $data[] = array(
               'id' => $cronTask['id'],
               'user' => $cronTask['userId'],
               'email' => $userEmail,
               'domain' => $cronTask['domainId'],
               'create_date' => $cronTask['create_date'],
               'last_try_date' => $cronTask['last_try_date'],
               'activate_date' => $cronTask['activate_date'],
               'status'        => $cronTask['status'],
           );
        }

        $vars['cronTasks'] = $data;
 
        return array(
            'template'      => 'CronList'
            ,'vars'         => $vars
        );
    }

    public function retryActionHTMLAction($input, $vars = array()){

        $cronTask = new MGCronTask(array('_tableName' => 'ServerTasticSSL_cron_tasks'));
        $cronTask->getTask($input['id']);

        $cronTask->updateLastTry();
        $params = json_decode($cronTask->params, true);
        $certificate = new ServerTasticSSLCertificate($params);
        try{
            if(isset($certificate->data)) {
                $certificate->placeTokenCertRequestCron($certificate->data);
            } else {
                $certificate->placeFreeCertRequest(true);
            }
            $cronTask->setFinished('Installed');
        }
        catch(SystemException $ex){
            MGExceptionLogger::addLog($ex, '', '', $params['domain']);

            $vars['errors'][] = $ex->getMessage();
            $cronTask->params = json_encode($params);
            $cronTask->update();
        }


        return $this->MainHTMLAction($input, $vars);
    }
}
