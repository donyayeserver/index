#!/usr/local/bin/php
<?php


if(file_exists(dirname(__FILE__).DIRECTORY_SEPARATOR.'pid.php') && filemtime(dirname(__FILE__).DIRECTORY_SEPARATOR.'pid.php') > time() - 600)
{
    echo "Cron is already running";
    exit;
}

$pidFile = file_put_contents(dirname(__FILE__).DIRECTORY_SEPARATOR.'pid.php', '<?php die(); '.getmypid());
if(!$pidFile)
{
    echo "Unable to create pid file...";
}

define("DS",DIRECTORY_SEPARATOR);

define("ServerTasticSSL_INCLUDES",'/usr/local/cpanel/share/ServerTasticSSL/');

require_once ServerTasticSSL_INCLUDES.'ServerTasticSSLLoader.php';

#$exSupport = new ExceptionHandler();
#$exSupport->register();

$Main = new ServerTasticSSLMainController('WHM',__DIR__);

if($result =  $Main->runCron('MainCron', 'daily'))
{
    echo "\n$result\n";
} 

if(file_exists(dirname(__FILE__).DIRECTORY_SEPARATOR.'pid.php'))
{
    unlink(dirname(__FILE__).DIRECTORY_SEPARATOR.'pid.php');
}

