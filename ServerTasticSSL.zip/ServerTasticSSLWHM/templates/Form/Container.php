<form class="form-horizontal" action="<?php echo $url; ?>" method="post" <?php echo isset($enctype) && !empty($enctype) ? 'enctype="'.$enctype.'"' : ''; ?> >
    <div class="col-lg-12">
        <legend><?php echo MGLang::T('header'); ?></legend>
    </div>
    <?php foreach($htmlFields as $field):?>
          <div class="form-group">
              <?php echo $field; ?>
          </div>
    <?php endforeach; ?>
</form>