<?php if ( $enableLabel ): ?>
    <label for="<?php echo $formName . '_' . $name; ?>" class="col-sm-2 control-label"><?php echo MGLang::T( 'label' ); ?></label>
<?php endif; ?>
<div class="col-sm-4">
    <label>

        <select name="<?php echo $formName . '_' . $name; ?>" type="" class="form-control"   id="<?php echo $formName . '_' . $name; ?>" >
            
            <?php foreach ($options as $option): ?>
                    <option class="" 
                            <?php if ( $value == $option['value'] ): ?>selected="selected"<?php endif; ?>
                            value="<?php echo $option['value']; ?>"><?php echo $option['name']; ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ( $enableDescription ): ?>
            <span class="help-block"><?php echo MGLang::T( 'label' ); ?></span>
        <?php endif; ?>
    </label>
</div>