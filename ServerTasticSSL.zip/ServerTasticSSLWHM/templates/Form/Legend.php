<div class="col-lg-12"><div class="col-lg-12">
    <legend><?php echo MGLang::T('label'); ?></label>
    </div></div>