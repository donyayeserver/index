<?php if(!empty($errors) && is_array($errors)): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo implode('<br/>', $errors) ?>
    </div>
<?php endif ?>
<script>
    $(document).ready(function() {
        $('#accountList').DataTable({
            "ordering": true,
            "info":     true,
            "pageLength": 25
        });
    } );
</script>
<style type="text/css">
    #accountList tbody tr 
    {
        height:51px;
    }
    #accountList_paginate
    {
        float:right;
    }
</style>
<div class="col-sm-12">
    <table class="table" id="accountList">
        <thead>
            <tr>
                <th>#</th>
                <th>User</th>
                <th>User Email</th>
                <th>User Domain</th>
                <th>Created</th>
                <th>Last Try</th>
                <th>Certificate Activation Date</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($cronTasks as $key => $task): ?>
                <tr>
                    <td><?php echo $key + 1; ?></td>
                    <td><?php echo $task['user']; ?></td>
                    <td><?php echo $task['email']; ?></td>
                    <td><?php echo $task['domain']; ?></td>
                    <td><?php echo $task['create_date']; ?></td>
                    <td><?php echo $task['last_try_date']; ?></td>
                    <td><?php echo $task['activate_date']; ?></td>
                    <td><?php echo $task['status']; ?></td>
                    <th>
                        <?php if($task['status'] != 'Installed'):?>
                        <a style="float:right;" href="?page=CronTasks&amp;action=retryAction&amp;id=<?php echo $task['id']; ?>" class="btn btn-default">
                            Retry Action
                        </a>
                        <?php endif; ?>
                    </th>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

