<div class="col-lg-12">
    <?php if(!empty($error)): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    <?php if(!empty($success)): ?>
        <div class="alert alert-success">
            <?php echo $success; ?>
        </div>
    <?php endif; ?>
</div>
<?php echo $formAPI; ?>

<script type="text/javascript">
    jQuery(document).ready(function(){
        if(jQuery('#options_is_reseller').is(':checked')){
            jQuery('#options_affiliate_id').parent().parent().hide();
            jQuery('#options_custom_url').parent().parent().show();
        } else {
            jQuery('#options_custom_url').parent().parent().hide();
            jQuery('#options_affiliate_id').parent().parent().show();
        }
        
        jQuery('#options_is_reseller').click(function () {
            if(jQuery(this).is(':checked')){
                jQuery('#options_affiliate_id').parent().parent().hide();
                jQuery('#options_custom_url').parent().parent().show();
            } else {
                jQuery('#options_custom_url').parent().parent().hide();
                jQuery('#options_affiliate_id').parent().parent().show();
            }
        });     
    });
</script>