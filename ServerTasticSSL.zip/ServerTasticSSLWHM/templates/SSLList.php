<div class="col-sm-12">
    <?php if(!empty($success)): ?>
        <div class="alert alert-success" role="alert">
            <?php echo $success ?>
        </div>
    <?php endif ?>
    <?php if(!empty($errors) && is_array($errors)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo implode('<br/>', $errors) ?>
        </div>
    <?php endif ?>


</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('#domainsTable').DataTable();
    });
</script>

<style type="text/css">
    #domainsTable tbody tr 
    {
        height:36px;
    }
    #domainsTable_paginate
    {
        float:right;
    }
</style>

<div>
    <table class="table table-hover" id="domainsTable">
        <thead>
        <tr>
            <th><?php echo MGLang::T('thead','domain'); ?></th>
            <th><?php echo MGLang::T('thead','status'); ?></th>
            <th><?php echo MGLang::T('thead','ssltype'); ?></th>
            <th><?php echo MGLang::T('thead','expiry_date'); ?></th>
            <th><?php echo MGLang::T('thead','error'); ?></th>
            <th><?php echo MGLang::T('thead','actions'); ?></th>
        </tr>
        </thead>
        <tbody>

        <?php if(!empty($certs)): ?>
            <?php foreach($certs as $cert): ?>
                <tr>
                    <td><?php echo $cert['domainId']; ?></td>
                    <td><?php echo $cert['status']; ?></td>
                    <td><?php echo $cert['ssltype']; ?></td>
                    <td><?php echo $cert['expiry_date']; ?></td>
                    <td>
                        <?php if($cert['error']): ?>
                        <form method="post" style="margin-right:3px;">
                            <input type="hidden" name="page" value="ErrorList">
                            <input type="hidden" name="domain" value="<?php echo $cert['domainId']; ?>">
                            <button style="margin-bottom:3px;float:left;margin-right: 3px;" type="submit" class="btn btn-info btn-xs" name="action" value="listByDomain" ><?php echo MGLang::T('actions','error'); ?></button>
                        </form>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(!empty($cert['actions']) && $cert['actions'] == 'sslTastic'): ?>
                        <form method="post" style="margin-right:3px;">
                            <input type="hidden" name="order_id" value="<?php echo $cert['reseller_order_id']; ?>">
                            <input type="hidden" name="cert_domain" value="<?php echo $cert['domainId']; ?>">
                            <button style="margin-bottom:3px;float:left;margin-right: 3px;" type="submit" class="btn btn-info btn-xs confirm" name="action" value="certRenew" ><?php echo MGLang::T('actions','renew'); ?></button>
                            <button style="margin-bottom:3px;float:left;margin-right: 3px;" type="submit" class="btn btn-info btn-xs confirm" name="action" value="certRemove" ><?php echo MGLang::T('actions','remove'); ?></button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
    $(document).ready(function() {
        $('#accountList').DataTable({
            "dom": 't<"pull-right mg_pagination" p>',
            "ordering": false,
            "info":     false,
            "pageLength": 25});

        $('.btn').click(function(){
            if($(this).hasClass('confirm')){
                return confirm("Are you sure?");
            }
        });
    } );
</script>