<div class="col-sm-12">
    <?php if(!empty($success)): ?>
        <div class="alert alert-success" role="alert">
            <?php echo $success ?>
        </div>
    <?php endif ?>
    <?php if(!empty($errors) && is_array($errors)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo implode('<br/>', $errors) ?>
        </div>
    <?php endif ?>
    <?php
    if($logs_status == 'off'):
        $btnStatus = 'danger' ;
    else:
        $btnStatus = 'success' ;
    endif;
    ?>
    Currently API logs are <a name="apilogs_change_status" href="?page=ErrorList&action=change" class="btn btn-<?php echo $btnStatus; ?>" id="apilogs_change_status"><?php echo strtoupper($logs_status); ?></a>
    <a style="float:right;" href='?page=ErrorList&action=clear' class='btn btn-danger'>
        Clear Logs
    </a>
    <hr/>

    <?php if(!empty($error)): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
            <?php if(!empty($errorID)): ?>
                <strong>
                    <?php echo MGLang::T('errorID'); ?> <?php echo $errorID; ?>
                </strong>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <!--
    <div class="appsListFilters errorFinder">
        <form action="" method="post" class="form-inline">
            <div class="form-group col-sm-4">
                <div class="input-group" >
                      <input id="tokenID" name="tokenID" type="text" class="form-control" value="<?php if(!empty($tokenID)) echo $tokenID; ?>">
                      <span class="input-group-btn">
                          <button class="btn btn-info" type="submit" name="action" value="SearchToken" placeholder="<?php echo MGLang::T('findByToken'); ?>"><i class="glyphicon glyphicon-search"></i></button>
                      </span>
                </div>
            </div>
        </form>
    </div>
    -->
    <div class="clearfix" style="margin-bottom:10px;"></div>
    <?php if(!empty($showError)): ?>
            <?php
            if(is_array($showError)){
                foreach($showError as $k=>$v){
                    if(empty($v)) continue;
                    echo '<label>'.ucfirst($k).':</label>';
                    echo '<div><pre>'.$v.'</pre></div>';
                }
            }
            ?>
    <?php endif; ?>
    <?php if(!empty($tokenList)): ?>
        <h3><?php echo MGLang::T('errorList'); ?></h3>
        <table id="errorList" class="display" cellspacing="0">
            <thead><tr><td>Error</td><td>Domain</td><td>Time</td></tr></thead>
            <?php foreach($tokenList as $data): ?>
            <tr class="error-list">
                <td><a href="index.php?page=ErrorList&action=SearchToken&tokenID=<?php echo $data['token']; ?>">#<?php echo $data['token']; ?></a> <?php echo $data['message']; ?> </td>
                <td style="text-align: center;"><?php echo $data['domain']?:"WHM"; ?></td>
                <td><span class="label label-primary pull-right"><?php echo $data['date']; ?></span></td>
            </tr>
            <?php endforeach; ?>
        </table>    
    <?php endif; ?>
</div>
<div>&nbsp;</div>

<script>
    $(document).ready(function() {
        $('#errorList').DataTable({
            "ordering": false,
            "info":     false,
            "pageLength": 25
        });
    } );
</script>
<style type="text/css">
    #errorList_paginate
    {
        float:right;
    }
</style>